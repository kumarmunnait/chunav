<?php
include_once 'lib/session.php';
include_once 'lib/database.php';
include_once 'lib/db_config.php';
$db = new database();

  $User_id=$_SESSION['userid'];
  $form_id = base64_decode($_GET["id"]);
  $form_id_name = base64_decode($_GET["formid"]);
  $query ="select * from tbl_forms where user_id='$User_id' AND id='$form_id'";
  $formdata  = $db->execute_query($query);
  if($formdata) {
      $row = $formdata->fetch_assoc();
      $form_name = $row['name'];
      $form_html = $row['form_html'];
      $form_fields = $row['form_fields'];
      $form_field= explode(",",$form_fields);
      $filed = count($form_field);
      $form_html = str_replace("Delete"," ", $form_html);
      $html = str_replace('contenteditable="true"'," ", $form_html);

 }


 if(isset($_POST['senddata'])) {

  $form_post_data=""; 

 for($i=0;$i<$filed;$i++){
 $var ="'".$form_field[$i]."'";

 
      $form_post_data .= "'".$_POST[$form_field[$i]]."',";

  }



   $form_post_data=substr($form_post_data, 0, -1);
  

   $insert_form_data ="INSERT INTO $form_id_name ($form_fields)
  VALUES ($form_post_data);";


       $insert_form_data = $db->insert($insert_form_data);
      if($insert_form_data){
        echo "<script>alert('Record Inserted')</script>";
      } 
      else{
        echo "<script>alert('Error in Record Insertedd')</script>";
      }


  }


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Coupon Form Dashboard</title>
    <?php include_once 'inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once 'inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once 'inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->

            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800"> Form   </h1> <a href="create-server-form" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">Create New Form </a>
             
            </div>

          <div class="row">

          

            <div class="col-lg-12">

              <!-- Dropdown Card Example -->
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary"><?php echo $form_name  ;?></h6>
                
                </div>
                <!-- Card Body -->
                <div id="form-create" class="card-body">
                      <!-- Card Header - Accordion -->
                <form id="chunavform" action="" method="post" name="chunav">

                  <?php echo $html  ;?>



                  <input  class="btn btn-primary btn-user btn-block"  value="Send Data" name="senddata" type="submit" name="">
 
      
                </form>




              </div>


              </div>


            </div>

          </div>
           
           
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once 'inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
    
      </body>
    </html>