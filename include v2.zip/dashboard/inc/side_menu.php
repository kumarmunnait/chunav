<?php $active = $_SERVER["PHP_SELF"]; ?>
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
<!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo $baseurl?>dashboard/home">
  
    <div class="sidebar-brand-text mx-3"><img src="<?php echo $baseurl?>dashboard/img/logo-white.png"></div>
    </a>
    <!-- Divider -->
    <hr class="sidebar-divider my-0">
<!-- Nav Item - Dashboard -->

    <li <?php if (strpos($active, 'home.php') !== false){echo 'class="nav-item active"';}else {
      echo 'class="nav-item"';}?>> 
    <a class="nav-link" href="<?php echo $baseurl?>dashboard/home">
    <i class="fas fa-fw fa-tachometer-alt"></i>
    <span>Dashboard</span></a>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
    FORM
    </div>
    <!-- Nav Item - Pages Collapse Menu -->
    <li <?php if (strpos($active, 'create-form.php') !== false or strpos($active, 'form-list.php') !== false ){echo 'class="nav-item active"';} else {
      echo 'class="nav-item"';

    }?>>
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
    <i class="fas fa-fw fa-folder"></i>
    <span>Manage Form</span>
    </a>
    <div id="collapsePages" <?php if (strpos($active, 'create-form.php') !== false or strpos($active, 'form-list.php') !== false){echo 'class="collapse show"';} else {
      echo 'class="collapse"';

    }?> aria-labelledby="headingPages" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <!--<h6 class="collapse-header">Create Form</h6>-->
      <a class="collapse-item" href="<?php echo $baseurl?>dashboard/create-form">Create Form</a>
      <a class="collapse-item" href="<?php echo $baseurl?>dashboard/form-list">List Form</a>
    </div>
    </div>
    </li>
    <!-- Nav Item - Pages Collapse Menu -->
   
  <!-- Divider -->
  <!--   <hr class="sidebar-divider d-none d-md-block">
    <div class="sidebar-heading">
     Send SMS 
    </div>
    <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages2" aria-expanded="true" aria-controls="collapsePages2">
        <i class="fas fa-fw fa-folder"></i>
        <span>SMS Setting</span>
      </a>
      <div id="collapsePages2" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
          <h6 class="collapse-header"> SMS Setting / Trigger </h6>
          <a class="collapse-item" href="add-server"> SMS Trigger </a>
          <a class="collapse-item" href="edit-agent"> Send Bulk SMS </a>
          <a class="collapse-item" href="edit-agent"> Add More Phone </a>
          
        </div>
      </li> -->
       <!-- Divider -->


    <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
    My Account
    </div>
    <!-- Nav Item - Pages Collapse Menu -->
    <li <?php if (strpos($active, 'profile-details.php') !== false or strpos($active, 'change-password.php') !== false ){echo 'class="nav-item active"';} else {
      echo 'class="nav-item"';

    }?>>
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse4" aria-expanded="true" aria-controls="collapse4">
    <i class="fas fa-fw fa-folder"></i>
    <span>Account Setting</span>
    </a>
    <div id="collapse4" <?php if (strpos($active, 'profile-details.php') !== false or strpos($active, 'change-password.php') !== false){echo 'class="collapse show"';} else {
      echo 'class="collapse"';

    }?> aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
        
             <a class="collapse-item" href="<?php echo $baseurl?>dashboard/profile-details">Profile Details </a>  
                  <a class="collapse-item" href="<?php echo $baseurl?>dashboard/change-password">Change Password </a>  
            </div>
    </div>
    </li>
    <!-- Nav Item - Pages Collapse Menu -->
  
     <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
    Manage User
    </div>
    <!-- Nav Item - Pages Collapse Menu -->
    <li <?php if (strpos($active, 'profile-details.php') !== false or strpos($active, 'change-password.php') !== false ){echo 'class="nav-item active"';} else {
      echo 'class="nav-item"';

    }?>>
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse5" aria-expanded="true" aria-controls="collapse4">
    <i class="fas fa-fw fa-folder"></i>
    <span>Manage User</span>
    </a>
    <div id="collapse5" <?php if (strpos($active, 'profile-details.php') !== false or strpos($active, 'change-password.php') !== false){echo 'class="collapse show"';} else {
      echo 'class="collapse"';

    }?> aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              
             <a class="collapse-item" href="<?php echo $baseurl?>dashboard/user/add-user">Add User</a>  
                  <a class="collapse-item" href="<?php echo $baseurl?>dashboard/user/list-user">List User</a>  
            </div>
    </div>
    </li>
  
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">
      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>
</ul>