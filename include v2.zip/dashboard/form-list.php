<?php
include_once 'lib/session.php';
include_once 'lib/database.php';
include_once 'lib/db_config.php';
$db = new database();
$User_id=$_SESSION['userid'];
$query ="select * from tbl_forms where user_id=$User_id order by id DESC";
$form_list = $db->execute_query($query);
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Coupon Dashboard</title>
    <?php include_once 'inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once 'inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once 'inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->

            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800"> All Form List   </h1> 
             
            </div>

          <div class="row">

          

            <div class="col-lg-12">

      


              <!-- Progress Small -->
              <div class="card mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">List Of Form</h6>
                </div>
                <div class="card-body">


              <?php

              if($form_list== false){
                       echo "<div class='text-center alert alert-danger'> No Record </div>";
                      }
                      else{
                        
                     

               while($row = $form_list->fetch_array()): ?>



                          <div class="row">
                      <div class="col-md-8">
                         
                  

                    <h4 class="small font-weight-bold"> <?php echo $row['name'];?> <span class="float-right"><?php echo $row['created_date'];?></span></h4>
                    <div class="progress text-left mb-4">
                      <div class="progress-bar bg-primary" role="progressbar" style="width: 100%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100">  </div>
                    </div>
                   
                 
                      </div>                    
                      <div class="col-md-2">
                        <a href="form-view.php?id=<?php echo base64_encode($row['id']);  ?>&&formid=<?php echo base64_encode($row['form_table_name']);?>" class="btn mt-3 btn-info btn-block btn-icon-split btn-sm">
                   
                    <span class="text">View Form</span>
                  </a>
                      </div>  

                           <div class="col-md-2">
                        <a href="data-collected.php?id=<?php echo base64_encode($row['id']);  ?>&&formid=<?php echo base64_encode($row['form_table_name']);?>" class="btn mt-3 btn-success btn-block btn-icon-split btn-sm">
                   
                    <span class="text">View Data</span>
                  </a>
                      </div>                   
                    
                  </div>
                  <hr>

                   <?php endwhile;  } ?>       

                </div>
              </div>


            </div>


         

          </div>
           
           
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once 'inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
    
      </body>
    </html>