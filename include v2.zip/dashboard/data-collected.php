<?php
include_once 'lib/session.php';
include_once 'lib/database.php';
include_once 'lib/db_config.php';
error_reporting(0);

$db = new database();
$User_id=$_SESSION['userid'];

$form_id = base64_decode($_GET["id"]);
$form_id_name = base64_decode($_GET["formid"]);

$query ="select * from tbl_forms where user_id=$User_id AND id=$form_id";
$table_name = $db->execute_query($query);

     $table_name = $table_name->fetch_assoc();
     //print_r($table_name);
   $table_data_name = $table_name['form_table_name'];
     $form_name = $table_name['name'];

  $table_title_name = explode(",",$table_name['form_fields']);

    $no_of_table_name = count( $table_title_name);
 



$form_post_data="";

for($i=0;$i<$no_of_table_name;$i++){

      $form_post_data .= "<th>". $table_title_name[$i]."</th>";

  } 

  $form_post_data .= "<th>Created Date </th>";
  
?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Coupon Dashboard</title>
    <?php include_once 'inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once 'inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once 'inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->

            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">Collected data</h1>
              <a href="#" onclick="formToggle('importFrm');" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Downlaod Data </a>
            </div>

          
          
         
            <div class="row">
              <!-- DataTales Example -->
              <div class="col-md-12" >
                <div class="card shadow mb-4">
                  <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo $form_name ?></h6>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <?php echo  $form_post_data; ?>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <?php echo  $form_post_data; ?>
                    </tr>
                  </tfoot>
                  <tbody>
  

            <?php
        $result = array();
 $query ="select * from  $table_data_name";
  $table_details = $db->execute_query($query);
    
  
      while ($table_details1 = $table_details->fetch_array()):
         $result[] = $table_details1;
      endwhile; 
      //print_r($result);
  $no =count($result);
     // $new_table_details = implode(" ",$table_details);
  

for($j=0;$j<$no; $j++){
echo "<tr>";
  for($k=0;$k<$no_of_table_name;$k++){

      echo $form_post_data = "<td>".$result[$j][$table_title_name[$k]]."</td>";

  }

 echo $form_post_data = "<td>".$result[$j][created_date]."</td>";
          
  echo "</tr>";  
}

   ?>
                  
                   
                  </tbody>
                </table>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.container-fluid -->
            </div>
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once 'inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
    
      </body>
    </html>