<?php
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
include_once '../lib/user.php';
$db = new user();
$User_id=$_SESSION['userid'];
$old_password=$_POST['old_password'];
$new_password=$_POST['new_password'];
$confirm_password=$_POST['confirm_password'];
$date = date('Y-m-d H:i:s');

	$update_password="select `password` from users where id=$User_id";
	$result = $db->execute_query($update_password);

	$old_password_db = $result->fetch_assoc();

 	$old_password_db= $old_password_db['password'];

	if($old_password_db!=$old_password) {
		echo 2;
	}

	else if($new_password!=$confirm_password) {
		echo 3;
	}

	else {
		$password_updated=" UPDATE users SET password='$confirm_password' WHERE id=$User_id";
		$db->execute_query($password_updated);

		

	}

?>