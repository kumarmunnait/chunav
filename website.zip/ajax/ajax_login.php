<?php 
session_start();
include_once '../dashboard/lib/database.php';
include_once '../dashboard/lib/db_config.php';
 
//get the posted val
$user_name=htmlspecialchars($_POST['user_name'],ENT_QUOTES);
$dt=date('y-m-d H:i:s');
$pass=$_POST['password'];
function getRealIpAddr($ip)
 {
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    { 
     $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }

   else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
 }
$ip=getRealIpAddr(0);
//now validating the username and password


$db = new database();

$sql="SELECT * FROM users WHERE username='".$user_name."' and status='1' and password='$pass'";
$result=$db->execute_query($sql);
$numrows=$result->num_rows;
 //if username exists
if($numrows>0){
	$row=$result->fetch_assoc();
    $isotp=$row['isOtp'];
     if($row['status']!=1){
		echo 'Please verify your email id to click on given link on your email';		
	}else{
	//compare the password
	if(strcmp($row['password'],$pass)==0){
		 if($isotp==1)
		 {
		    echo "yes";
		    $id=$row['id'];
			$phone_number=$row['mobile'];
			$otp=randomString();
 			$_SESSION['phone']=$phone_number;
			$userid = $row['id'];
			$_SESSION['profile_group_id'] = $row['profile_group_id'];
			$_SESSION['userid']=$userid;
 			$_SESSION['otp']=$otp;
			$_SESSION['uid']=$id;
			$_SESSION['psw']=md5($pass);
			$_SESSION['islogin']=1;
			//$msg="Your OTP For Login is: ".$otp;
			$msg="Use ".$otp." as your OTP to access your username ".$user_name.". Never share your OTP with any unauthorized person. OTP is confidential and valid for 5 mins";
			$message1 = urlencode($msg);
			$result = SendSMStanla($phone_number,$message1); 
			//$log = '/opt/bitnami/nginx/html/sendotp_log_loginotp_'.date('ymd').'.log';
			//file_put_contents($log, "response: " .$result . "  \n", FILE_APPEND);
			$update=$db->update("update users set otp='$otp' where id = '$id'");
			$query="insert into login_otp_history(user_id,ip,otp,login_date)values('$id','$ip','$otp','$dt')";
			$sql_insert=$db->insert($query);	
		 }else{
			 
				$profile_group_id = $row['profile_group_id'];
				echo "yes1";
				//now set the session from here if needed
				$_SESSION['userid']=$row['id']; 
				$userid=$row['id'];
				$_SESSION['psw']=md5($pass);
				$_SESSION['auser_name']=$row['username'];
				$_SESSION['otp']='';
				$user_name=$row['username'];
				$_SESSION['name']=$row['name']; 
				$_SESSION['email']=$row['email'];
				$_SESSION['phone']=$row['mobile'];
 				$_SESSION['master']=$row['master'];
  				$_SESSION['login_for']=$row['login_for'];
  				$_SESSION['isOtp']=$row['isOtp'];
  				$_SESSION['profile_group_id']=$profile_group_id;
				setcookie("auser_name", $user_name, time() + 60*60*24*100); 
				setcookie("profile_group_id", $profile_group_id, time() + 60*60*24*100); 
 				$query="insert into login_history(user_id,ip,login_date)values('$userid','$ip','$dt')";
				$sql_insert=$db->insert($query);	
				//dbClose($conn);
 		 }
 	}else{echo "no";} 
  }

}else{
	echo "no"; //Invalid Login
}
//dbClose($conn);
$db->dbClose();

function SendSMS($mobile, $message1){
	 $uid="Newtest"; //your uid
	$pin="160022"; //your api pin
	$sender="DGNOTP"; // approved sender id
	 
	 
	$hostUrl = "http://sms.thinkbuyget.com/api.php?username=$uid&password=$pin&sender=$sender&sendto=$mobile&message=$message1";
	 $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $hostUrl);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
   curl_setopt($ch, CURLOPT_POST, 0);
   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1); // change to 1 to verify cert
   curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
   //curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");

   $result = curl_exec($ch);

   return $result;

	} 
	
	
function SendSMS1($mobile, $message1){
$user = 'datagenapi';
$pass = 'h(5Ta~2Q';
//$sender="DGNOTP"; // approved sender id

	$sender="ACCOTP"; // approved sender id
 
 
//$hostUrl = "http://sms.thinkbuyget.com/api.php?username=$uid&password=$pin&sender=$sender&sendto=$mobile&message=$message1";
	$url = 'http://www.unicel.in/SendSMS/sendmsg.php?ver=1.0&uname='.$user.'&pass='.$pass.'&send=ACCOTP&dest='.$mobile.'&msg='.$message1.'&dlr_req=1';
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_POST, 0);
	
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1); // change to 1 to verify cert
	curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
	//curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
	$result = curl_exec($ch);
	curl_close($ch);
	return $result;

} 
function SendSMStanla($mobile, $message1){
	$sender="ACCOTP"; // approved sender id
	$uid=isset($_SESSION['uid'])?$_SESSION['uid']:0;
	$logid=uniqid();	
	$mobilearr=explode(',',$mobile);
	$phone_number=urlencode(implode(' ',$mobilearr));
	$route='tanlaotp';//VFirst tanla1 Unicel tanlaotp univcon
	$dlrurl=urlencode('http://sms.datagenit.in/kannel_reports.php?logid='.$logid.'&user_id='.$uid.'&phNo=%p&result=%d&delivery=%A&route=%i');
	$url="http://45.114.143.70:17013/cgi-bin/sendsms?username=run13&password=1r3un&dlr-mask=19&from=$sender&to=$phone_number&text=$message1&dlr-url=$dlrurl&smsc=$route";
	//tanlaotp
	
	$curl = curl_init();
	// Set some options - we are passing in a useragent too here
	curl_setopt_array($curl, array(
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_URL => $url,
		CURLOPT_USERAGENT => 'Codular Sample cURL Request'
	));
	// Send the request & save response to $resp
	$response = curl_exec($curl);
	// Close request to clear up some resources
	curl_close($curl);
	//$result = json_decode($response, true);
	return $response;	

}	
	
function randomString($length = 6) {
	$str = "";
	//$characters = array_merge(range('A','Z'), range('a','z'), range('0','9'));
	$characters = array_merge(range('0','9'));
	$max = count($characters) - 1;
	for ($i = 0; $i < $length; $i++) {
		$rand = mt_rand(0, $max);
		$str .= $characters[$rand];
	}
	return $str;
}

?>