<?php
session_start();
include_once '../dashboard/lib/database.php';
include_once '../dashboard/lib/db_config.php';

 
$id=$_SESSION['uid'];
$otp=trim($_POST['otp']);
$otp_session=$_SESSION['otp'];
function getRealIpAddr($ip)
 {
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    { 
     $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }

   else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
 }
$ip=getRealIpAddr(0);
//now validating the username and password
$sql="SELECT * FROM users WHERE id='".$id."' and otp='$otp'";
$db = new database();
$result=$db->execute_query($sql);
$numrows=$result->num_rows;
//if username exists
if($numrows >0){
	$row=mysqli_fetch_array($result);
	
    if($row['status']!=1){
		echo 'Please verify your email id to click on given link on your email';		
	}else{
	//compare the password
	if(strcmp($otp_session,$otp)==0){
		$profile_group_id = $row['profile_group_id'];
		echo "yes";
		//now set the session from here if needed
		$_SESSION['userid']=$row['id']; 
		$userid=$row['id'];
		$_SESSION['auser_name']=$row['username'];
		$_SESSION['otp']='';
                $user_name=$row['username'];
  		$_SESSION['name']=$row['name']; 
		$_SESSION['email']=$row['email'];
		$_SESSION['mobile']=$row['mobile'];
		$_SESSION['organization']=$row['organization'];
		$_SESSION['master']=$row['master'];
 		$_SESSION['isOtp']=$row['isOtp'];
 		$_SESSION['profile_group_id']=$profile_group_id;
		setcookie("auser_name", $user_name, time() + 60*60*24*100); 
		setcookie("profile_group_id", $profile_group_id, time() + 60*60*24*100); 
		$dt=date('y-m-d H:i:s');
     	        $query="insert into login_history(user_id,ip,login_date)values('$userid','$ip','$dt')";
	        $sql_insert=$db->insert($query);	
		//dbClose($conn);
	}else{echo "no";} 
  }

}else{
	echo "no"; //Invalid Login
}?>