<?php error_reporting(0); 
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
$db->execute_query("SET NAMES utf8");
$userid=$_SESSION['userid'];
$profile_group_id=$_SESSION['profile_group_id'];

$dt11=$_GET['dt'];
$dt22=isset($_REQUEST['dt2'])? $_REQUEST['dt2']:$dt11;

if($dt11==$dt22){
$cond="camp_start_datetime >= '$dt11'";	
}else{
$cond="date(camp_start_datetime) >= '$dt11' and date(camp_start_datetime) <= '$dt22'";		
}
?>
<div class="table-responsive">
        <div class="table-responsive mt10">
        <div id="loading"></div>
        <table class="table align-middle">
         <thead>  <tr>      <th  width="10%">Select Date</th><th width="10%">   <input style="width:120px;" class="form-control" value="<?php echo $dt11; ?>" id="datepicker1" autocomplete="off" placeholder="Checkin Date" name="search_date" required></th> <th width="10%">   <input style="width:120px;" class="form-control" value="<?php echo $dt22; ?>" id="datepicker2" autocomplete="off" placeholder="Checkin Date" name="search_date" required></th><th width="10%"> <button type="submit"class="d-none float-right d-sm-inline-block btn btn-sm btn-primary shadow-sm" onClick="loadfunction1();" id="sendnou">Search</button></th>
         <th width="50%"></th>
         <th  align="right"><!-- <button type="submit" class="btn btn-cap m-r-5" id="sendnou">Download</button>--></th>
       </th></tr>
           </thead>                           
          </table>
        <table class="table table-bordered table-hover" id="dataTables-example">
         <thead>
 					 <?php 
			   $dt=date('Y-m-d G:i:s');
             //  $selectdata=mysqli_query($conn,"select id,user_id,username,created_date,text_message,contact_count,sender_id from compose_sms where user_id = '$userid' and camp_start_datetime <= '$dt' and status not in (0) order by id desc limit 10") or die(mysqli_error($conn));
			
			
	                  if($profile_group_id==1){
						 
						  $query1="select id,user_id,username,text_message,msg_count,camp_start_datetime,sender_id,created_date,status from sms_campaign where message_type in(1,2,3) and $cond order by id desc"; 						  
						   $selectdata=$db->execute_query($query1);
						   
					  }else{
						  
						  $query1="select id,user_id,username,text_message,msg_count,camp_start_datetime,sender_id,created_date,status from sms_campaign where user_id = '$userid' and message_type in(1,2,3) and $cond order by id desc";
 						  $selectdata=$db->execute_query($query1);
 					  }		 
?> 
              
        <tr class="active">
	       <?php  if($profile_group_id==1){ ?> <th width="9%">UserID</th> <?php } ?>
           <th width="6%">SenderID</th>
          <th width="10%">Camp ID</th>
           <th width="40%">Content</th>
         <th width="10%">Status</th>
         <th width="16%">Submit on</th>
         <th width="20%">Action</th>
        </tr>
        </thead>   <tbody>
							  <?php
		   if($selectdata->num_rows>0)
		   {
		 
		    while($row = $selectdata->fetch_array()){
				
$username=$row['username'];	
$msg_count=$row['msg_count'];
$campaignid=$row['id'];
$result = substr($username,0,1);
//echo $result;
$result =strtolower($result);
$reorttable='sms_reports';
								//echo $reorttable;
			//$seltotal=mysqli_query($conn,"select count(status) as total,status from $reorttable where campaign_id=$campaignid  group by status") or die(mysqli_error($conn));
			
			// $seltotal=mysqli_query($conn,"select count(status) as total,status from $reorttable where campaign_id=$campaignid and submit_from='PANEL'  group by status desc") or die(mysqli_error($conn));
			$seltotal=$db->execute_query("SELECT status,SUM(msgcount) AS msgcount  FROM (SELECT status,SUM(msg_count) AS msgcount FROM $reorttable WHERE campaign_id=$campaignid AND submit_from='PANEL' GROUP BY STATUS,msg_count) t GROUP BY status,msgcount");
			//$rowtotal=mysqli_fetch_array($seltotal); 
			
			// echo $rowtotal['st'];
								$total=0;$totaldelivered=0;$totalfailed=0;$totaldnd=0;$totalinvalid=0;$totalblacklist=0;$totaloptout=0;
 							 while($rowtotal=$seltotal->fetch_array()){
 									//print_r($rowtotal);
									$total +=$rowtotal['msgcount'];
									if($rowtotal['status']=='dnd'){$totaldnd +=$rowtotal['msgcount'];}
									if($rowtotal['status']=='delivered'){$totaldelivered +=$rowtotal['msgcount'];}
									if($rowtotal['status']=='failed'){$totalfailed +=$rowtotal['msgcount'];}
									if($rowtotal['status']=='invalid'){$totalinvalid +=$rowtotal['msgcount'];}
									if($rowtotal['status']=='blacklist'){$totalblacklist +=$rowtotal['msgcount'];}
									if($rowtotal['status']=='optout'){$totaloptout +=$rowtotal['msgcount'];}
								}  
								//$totalinvalid=$total-($totaldnd+$totaldelivered+$totalsended);
 				?>
                          <tr class="gradeA" id="r<?= $row['id']?>"> 
                          
                          <?php  if($profile_group_id==1){ ?><td><?= $row['username']?></td> <?php } ?>
                          <td><?= $row['sender_id']?></td><td><?= $row['id']?></td><td><?php
 		   echo $row['text_message'];
		   echo "<br><br>";
			
			if($row['camp_start_datetime']>$dt and $row['status']!='4') { echo "<b>[Scheduled time :".$row['camp_start_datetime']."]  </b>"; }
		 
			if($row['status']=='4'){ echo " <b>[Deleted Scheduled Message]</b> "; }
		   ?></td><td>Total : <?php //$tt=$row['contact_count'];
		   $total_send=$total-($totalinvalid+$totalblacklist+$totaloptout);
		   echo ($total_send);
  		   ?><br>
           Delivered: <?= ($totaldelivered)?><br>
           Failed: <?=($totalfailed)?><br>
        <?php if($_SESSION['dnd_check']==1){ ?>    Dnd: <?=($totaldnd)?><br>  <?php }  ?>          
            
          
                        </td>
                        <td><?= date('d M Y h:i A',strtotime($row['created_date']))?></td>
                        <td>  
                      <!-- <a  href="download-report.php?table_name=<?php echo $reorttable; ?>&uid=<?php echo $row['user_id']; ?>&camp_id=<?php echo $row['id']; ?>" target="_blank"> <i class="glyphicon glyphicon-download-alt"></i></a>&nbsp;&nbsp;
                       <a href="campaign_detail.php?camp_id=<?php echo $row['id']; ?>&username=<?php echo $username ?>" target="_blank"> <span class="glyphicon glyphicon-eye-open" title="View Detail"></span></a>-->
                       
                       <a href="campaign_detail.php?camp_id=<?php echo $row['id']; ?>&username=<?php echo $username ?>"><button type="button" class="btn btn-sm btn-warning">View</button></a>
                       </td></tr>
                            <?php $i++; } } $db->dbClose(); ?>
                            </tbody>
 
         
        </table>

        </div>

        </div>
   
<script>
$( function() {
$('#datepicker2').datepicker({ maxDate: '0',dateFormat: 'yy-mm-dd' }).val();
$('#datepicker1').datepicker({  maxDate: '0',dateFormat: 'yy-mm-dd' }).val();
//$( "#datepicker3" ).datepicker({ dateFormat: 'yy-mm-dd' }).val();
} );
$(document).ready(function() {
	$('#dataTables-example').DataTable({
		"order": [[ 5, "desc" ]],
	  //  responsive: true
	  "scrollX": true

	});
});

function loadfunction1()
  {
	 // alert(dt1);
	 var dt1=$('#datepicker1').val();
	  var dt2=$('#datepicker2').val();
	 
    $("#loadtable").html('<div id="loading" align="center"><img src="../ajax-loader.gif" /></div>').load('web-campaign-report.php?dt='+dt1+'&dt2='+dt2);
  }
  function loadfunction2()
  {
	   var dt1=$('#datepicker1').val();
    $("#loadtable").html('<div id="loading" align="center"><img src="../ajax-loader.gif" /></div>').load('web-detail-report.php?dt='+dt1);
  }
   function loadfunction3()
  {
	   var dt1=$('#datepicker1').val();
    $("#loadtable").html('<div id="loading" align="center"><img src="../ajax-loader.gif" /></div>').load('web-archive-report.php?dt='+dt1);
  }

</script>