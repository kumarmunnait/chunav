<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
error_reporting(0);
$db = new database();
$userid=$_SESSION['userid'];
$username=$_SESSION['auser_name'];

$profile_group_id=$_SESSION['profile_group_id'];
$db->execute_query("set names 'utf8'");
$todate=date('Y-m-d');
 $dt1=date('Y-m-d');
$fromdate=date('Y-m-d',strtotime("-0 days",strtotime($todate)));
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="../vendor/jquery-ui-1.12.1/jquery-ui.css">
    <title>SMS Report</title>
    <?php include_once '../inc/style.php'; ?>
  </head>
  <body id="page-top" onload="loadfunction1('<?php echo $dt1; ?>');">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
    <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->

            <?php /*?><div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">SMS Report</h1>
            </div><?php */?>
              <div class="row">
              <!-- DataTales Example -->
              <div class="col-md-12" >
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">SMS Report</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                             <div class="panel-body" id="loadtable">
                                   <?php //include "web-campaign-report.php"; ?>
                             </div>
                        </div>
                    </div>
                  </div><!-- /.card shadow mb-4 -->
                </div><!-- /.col-md-12 -->
                </div><!-- /.row -->
              </div><!-- /.container-fluid -->
            </div><!-- /.content -->
          
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
<script src="../vendor/jquery-ui-1.12.1/jquery-ui.min.js"></script> 
<script>
$( function() {
$('#datepicker2').datepicker({ maxDate: '0',dateFormat: 'yy-mm-dd' }).val();
$('#datepicker1').datepicker({  maxDate: '0',dateFormat: 'yy-mm-dd' }).val();
//$( "#datepicker3" ).datepicker({ dateFormat: 'yy-mm-dd' }).val();
} );
function loadfunction1(dt1)
{
 //alert(dt1);
$("#loadtable").html('<div id="loading"><img src="../ajax-loader.gif" /></div>').load('web-campaign-report.php?dt='+dt1);
}
</script>
</body>
</html>