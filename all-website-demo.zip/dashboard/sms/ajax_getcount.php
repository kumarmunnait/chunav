<?php
date_default_timezone_set("Asia/Calcutta"); 
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$userid=$_SESSION['userid'];
$username=$_SESSION['auser_name'];
 
$field=explode("#",$_POST['tbl_name']);
echo $table_name=$field[0];

$form_fields="id,";
$form_fields .=$field[1];
$form_fields .=",created_date,updated_date";
$form_fields=explode(",",$form_fields);

//$filter=$_POST['filter'];
print_r($_POST);
//print_r($_POST['Name']);
$cond ="";
$filter=0;
$data=0;
foreach($form_fields  as $value ) {
	echo $value;
	if(!empty($_POST[$value])){
		$data++;
		 $filter=1;
		 $cond .=$value.' IN ';
		 $cond .="(";
 		 foreach($_POST[$value] as $value1){
		 	$cond .="'".$value1."',";
		 }
		 //$cond=rtrim($cond,"'");
		 $cond=rtrim($cond,',');
		 $cond .=")";
		 $cond .=" AND ";
	}
}
$cond=rtrim($cond,' AND');
 
 

if(!empty($_SESSION['userid'])){
$query="select count(*) from $table_name where $cond";
$result=$db->execute_query($query);
$row=$result->fetch_array();
//echo "ashu";
echo $row[0];
 		
}
?>