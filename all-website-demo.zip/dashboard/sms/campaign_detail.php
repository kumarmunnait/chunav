<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
error_reporting(0);
$db = new database();
$userid=$_SESSION['userid'];
$username=$_SESSION['auser_name'];
$campaignid=$_REQUEST['camp_id'];
$profile_group_id=$_SESSION['profile_group_id'];
$db->execute_query("set names 'utf8'");
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.css">
    <title>SMS Report</title>
    <?php include_once '../inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
    <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->

            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">Campaign Detail Of Campaign Id- <?php echo $campaignid; ?></h1>
              <?php
 
                    $seltotal=$db->execute_query("select * from sms_reports where campaign_id=$campaignid and submit_from='PANEL'");
                    $item_per_page=100;
                    $get_total_rows = $seltotal->num_rows; //total records
				    $pages = ceil($get_total_rows/$item_per_page);
                    ?>
               
            </div>
               <div class="row">
              <!-- DataTales Example -->
              <div class="col-md-12" >
                <div class="card shadow mb-4">
 
                   <div class="card-body">
                    <div class="table-responsive">
                     <input type="hidden" id="camp_id"  value="<?php echo $campaignid; ?>"   />
                                         <table class="table table-bordered table-hover">
                                                  <tr>
                                                  <th width="20%">
                                                <h4 id="tt"><?php echo $get_total_rows; ?> Records Found</h4> 
                                                </th>
                                                <th width="10%"><input type="text" id="mobile" autocomplete="off"  placeholder="Enter Mobile Number" class="form-control" name="mobile"></th>
                                                <th width="5%"> <button type="submit" onClick="loadfunction5();"  class="btn btn-primary btn-user btn-block">Search</button></th>
                                                <th width="10%"> <button type="submit" onClick="goback();"  class="btn btn-primary btn-user btn-block">Goback</button></th>
                                                </tr>
                                                </table>
                                            <div class="pagination"></div> <p>&nbsp;</p>
                                            <div class="panel-body" id="results"> </div>
                                             <div class="pagination"></div>
                                              <div class="panel-body" id="results2"> </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.container-fluid -->
            </div>
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.14/jquery.datetimepicker.full.js"></script>        
<script>
$('#datepicker1').datetimepicker({
			minDate: 0,
  			//format:"Y-m-d h:i a",
			format:"Y-m-d",
  			step:15
		}); 
$('#datepicker2').datetimepicker({
			minDate: 0,
  			//format:"Y-m-d h:i a",
			format:"Y-m-d",
  			step:15
		}); 
 
 
</script>
<script src="<?php echo $baseurl; ?>dashboard/js/jquery.bootpag.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$("#results").load("fetch_pages.php?cid=<?php echo $campaignid; ?>");  //initial page number to load
	//alert();
	$(".pagination").bootpag({
		//alert('sd');
	   total: <?php echo $pages; ?>,
	    page: 1,
		leaps: true,
		firstLastUse: true,
		first: '←',
		last: '→',
		wrapClass: 'pagination',
		activeClass: 'active',
		disabledClass: 'disabled',
	   maxVisible:10,
	   next: 'Next',
	   prev: 'Prev'
	}).on("page",function(e, num){
		e.preventDefault();
	 
		$("#results").prepend('<div class="loading-indication"><img src="../ajax-loader.gif" /></div>');
		$("#results").load("fetch_pages.php?cid=<?php echo $campaignid; ?>", {'page':num});
	});

});

   function loadfunction5()
  {
	var textBox = $("#mobile").val();
 	if (textBox==""){ 
	alert('Enter number'); 
	return false;
	}
	 
	$("#results").hide();
	$("#tt").hide();
	$(".pagination").hide();
	$("#results2").show();
	 var mob=$('#mobile').val();
	 var cid=$('#camp_id').val();
 	 //alert(tbl);
     $("#results2").load('fetch_pages_mob.php?mob='+mob+'&cid='+cid);
  }
  function goback()
  {  
			 
			$("#results").show();
			$("#tt").show();
			$(".pagination").show();
			$("#results2").hide();
    //$("#loadtable").html('<div id="loading"><img src="ajax-loader.gif" /></div>').load('web-detail-report.php?dt='+dt1);
  }
</script>
    
      </body>
    </html>