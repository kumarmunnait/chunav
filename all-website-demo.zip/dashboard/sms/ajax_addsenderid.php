<?php
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$User_id=$_SESSION['userid'];
if(!empty($_SESSION['userid'])){
 	// $groupname = mysqli_real_escape_string($conn, $_POST['groupname']);	
	  $sender_id_val =trim($_POST['sender_id_val']);	
	  $userid_val =$_POST['userid'];
	  $dt=date('Y-m-d:h:i:s');
	   $sel_senderid=$db->execute_query("select sender_id_val from sender_id where sender_id_val='$sender_id_val' and user_id=$userid_val");
		if($sel_senderid->num_rows==0)
			{		 		  
				 $sql=$db->insert("insert into sender_id(user_id,sender_id_val,created_date)values('$userid_val','$sender_id_val','$dt')");		  						
				 //$db->dbClose();
					 if($sql){
						echo "saved";
						}
						else{
							echo "Could not saved!";
							} 
				
			}else{
			  echo 3;	
			}
	}
		


?>