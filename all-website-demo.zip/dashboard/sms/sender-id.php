<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
$userid=$_SESSION['userid'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.css">
    <title>Sender ID</title>
    <?php include_once '../inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->
             <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800"> Sender ID</h1>  
             </div>
               <?php 
				if($_SESSION['profile_group_id']==1)
					{
						?>
           <div class="row">
               <div class="col-lg-12">
               <!-- Dropdown Card Example -->
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                     <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Sender ID </h6>
                
                </div>


                 <!-- Card Body -->
                <div id="form-create" class="card-body">
                      <!-- Card Header - Accordion -->
                  <form  method="post" name="frm" id="frm" action="#">
      <div class="panel-body">
        
           <div class="col-md-6">
        <div class="form-group">
												<label class="col-md-12 control-label" for="inputSuccess">Select User</label>
												<div class="col-md-12">
													<select class="form-control" name="userid" id="selalternateroute" required>
                                        	<?php 
											$selroute=$db->execute_query("select id,username from users where status='1' order by username asc");
											if($selroute->num_rows>0){
												echo "<option value=\"\">Select User</option>";
												while($rowroute=$selroute->fetch_array()){
													?><option value="<?php echo $rowroute['id']?>"><?php echo $rowroute['username']?></option><?php
												}
											}else{
												echo "<option value=\"\">no route found</option>";
											}?>
											</select>					</div>
	</div>
    </div>
     <div class="col-md-6">
        <div class="form-group ">
												<label class="col-md-12 control-label" for="inputSuccess">SenderID</label>
												<div class="col-md-12">
													<input class="form-control" placeholder="Sender ID" name="sender_id_val"  maxlength="6" type="text" required>
												</div>
	</div>
                     </div>
                    						 <div class="form-group">
												<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
													<p class="form-control-static" style="font-size:12px;">Max length : 6 alpha chars Only.</p>
													<div id="results">
													</div>
												</div>
                                                
											</div>
                                            
                                       
 <div class="form-group mb11">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 margin-bottom-all">
				<button type="submit" class="btn btn-info btn-sm hidden-xs"> <span class="pdlr2 ">Request Sender ID</span></button>
				<!--<button type="submit" class="btn btn-info btn-sm btn-block btn-lg visible-xs " onclick="onClickFun();">Request Sender ID</button>-->
				</div>
                 
				</div>


  
               		
                                             
        
      </div>
  
  </form>




              </div>


              </div>


            </div>

          </div>
          
          <?php } ?>
          
          <div class="row">
              <!-- DataTales Example -->
              <div class="col-md-12" >
                <div class="card shadow mb-4">

                   <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">List Sender ID</h6>
                  </div>


                   <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <?php 
				if($_SESSION['profile_group_id']==1)
					{
					$selectdata=$db->execute_query("select a.*,b.username from sender_id a ,users b where a.status!=0 and a.user_id=b.id order by id desc");
					}else{
                  $selectdata=$db->execute_query("select a.*,b.username from sender_id a ,users b where a.status!=0 and a.user_id=b.id and (b.master=$userid or a.user_id=$userid) order by id desc");
					}
$db->dbClose();						
						?>                          
                              <thead>
        <tr>
                	<th>S.No.</th>
                    <th>User ID</th>
					<th>Sender ID</th>
                    <th>Submited On</th>
                    
                    
                    <th>Status</th>
                     <?php 
				if($_SESSION['profile_group_id']==1)
					{
						?>
                    <th>Approve/Reject</th>
                    <?php } ?>
				<!--	<th>Delete</th>-->
				</tr>
        </thead>
                            <tbody>
							  <?php
		   if($selectdata->num_rows>0)
		   { $i=1;
		    while($row =$selectdata->fetch_array()){ ?>
            
           <tR class="gradeA" id="r<?= $row['id']?>"><td><?= $i?></td>
           <td><?= $row['username']?></td>
           <td><?= $row['sender_id_val']?></td><td><?= $row['created_date']?></td>
           
            <?php 
				if($_SESSION['profile_group_id']==1)
					{
						?>
           
           <tD><?php 
		   if($row['status']==2){ echo "Pending"; } if($row['status']==1){ echo "Approved"; }  if($row['status']==3){ echo "Rejected"; }
		    ?></tD>
            <tD><?php 
		   if($row['status']==2){ echo "<a onClick=change_status(".$row['id'].",1)>Approve</a> / <a onClick=change_status($row[id],3)>Reject</a>"; } if($row['status']==1){ echo "<a onClick=change_status($row[id],3)>Reject</a>"; } if($row['status']==3){ echo "<a onClick=change_status($row[id],1)>Approve</a>"; }
		    ?></tD>
            <?php }else{ ?>
         <tD><?php 
                            if($row['status']==2){ echo "Pending"; } if($row['status']==1){ echo "Approved"; }  if($row['status']==3){ echo "Rejected"; }
                            ?></tD>
            <?php } ?>
         
         
         
         
         </tR>
                       
                        
                <?php $i++; } } else { ?></tbody>
                <tbody>
<tr><td colspan="6" style="text-align:">No Record found..</td></tr>

        </tbody>
<?php  } ?>
                            </tbody>
                        </table>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.container-fluid -->
            </div>
           
           
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
    <script>
$(document).ready(function (e) {
	 $("#frm").on('submit',(function(e) {
	 	e.preventDefault();
		$.ajax({
			url: "ajax_addsenderid.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
			cache: false,
			processData:false,
			beforeSend : function(){
			//$("#preview").fadeOut();
			console.log('before call');
			$("#err").fadeOut();
			},
			success: function(data){
				console.log('success call',data);
				
				if(data!='saved')
				{
							if(data==3)
							  {
								alert('Sender id already added please check');  
							  }			 
				}
				else
				{
				 // view uploaded file.				 
				  $("#err").hide();
				  $("#success").html("Sender Id Added Successfully!").fadeIn();
				  alert('Sender Id Added Successfully!');
 				  $("#frm")[0].reset(); 
				  window.location.reload();
				}
			 },
			 error: function(e){
				  console.log('error call');
					$("#err").html(e).fadeIn();
			}          
		});
	 }));
	});
function change_status(id,status){ 
	//var res = confirm('Are sure want to !');
	var res =true;
	
	
	if(res==true){ 
	$.ajax({
			url: "ajax_changestatus_senderid.php?id="+id+"&status="+status,
			type: 'POST',
			
			beforeSend: function() {				 
			},
			success: function(data, t666666extStatus, xhr) {
			console.log('new data',data);
			alert('Sender Id Approved Successfully!');
			window.location.reload();
 			},
			error: function(xhr, textStatus, errorThrown) {					
			
			}
			});
				
			}else{
				return false;
				}
					
	}
			
	
</script>
 
    
      </body>
    </html>