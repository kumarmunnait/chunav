<?php
date_default_timezone_set("Asia/Calcutta"); 
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$userid=$_SESSION['userid'];
$username=$_SESSION['auser_name'];
$field=explode("#",$_POST['tbl_name']);
$table_name=$field[0];
$query="select count(*) from $table_name";
$result=$db->execute_query($query);		
$row=$result->fetch_array();
//echo "ashu";
echo $row[0];
 
?>