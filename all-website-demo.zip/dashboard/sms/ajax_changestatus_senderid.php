<?php
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$User_id=$_SESSION['userid'];
$id = $_GET['id'];
$status = $_GET['status'];
if($status=='1')
{
	$st=2;
}
if($status=='2')
{
	$st=1;
}
  $delaudio=$db->update("update sender_id set status='$status' where id = '$id'");							
  $db->dbClose();

if($delaudio){
	echo "Approved";
	}

?>