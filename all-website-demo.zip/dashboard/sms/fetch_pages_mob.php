<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
error_reporting(0);
$db = new database();
$userid=$_SESSION['userid'];
$username=$_SESSION['auser_name'];
//sanitize post value
echo $cid=$_REQUEST['cid'];
echo "ashu";
echo $mob=$_REQUEST['mob'];
 
 ?>

       <div class="table-responsive">
 
        <table class="table table-bordered table-hover">
        <thead>
 					 <?php 
				    $dt=date('Y-m-d G:i:s');
 			  $selectdata=$db->execute_query("select * from sms_reports where campaign_id=$cid and phone_number like '%$mob%' and submit_from='PANEL'");
?> 
                 
        <tr class="active">
         
	  <th width="9%">UserID</th>
           <th width="10%">Msg ID</th>
           <th width="10%">MSISDN</th>
           <th width="6%">SenderID</th>
           <!--<th width="30%">Content</th>-->
           <th width="10%">Count</th>
           <th width="16%">Submit on</th>
          <th width="16%">Deliver on</th>
          <th width="10%">Status</th>
          <th width="10%">Country</th>
        </tr>
        </thead><tbody>
           <?php
		   if($selectdata->num_rows>0)
		   {
		
		    while($rowtotal = $selectdata->fetch_array()){
 				?>
           <tR class="gradeA" > 
            
           <td><?= $rowtotal['username']?></td> 
           <td><?= $rowtotal['id']?></td>
           <td><?= $rowtotal['phone_number']?></td>
           <td><?= $rowtotal['sender_id']?></td>
           <!-- <td><?= $rowtotal['campaign_message']?></td>-->
             <td><?= $rowtotal['msg_count']?></td>
              <td><?= $rowtotal['starttime']?></td>
               <td><?= $rowtotal['deliver_time']?></td>
                <td><?php 
				if($rowtotal['status']=='sent')
				{
					echo 'Submitted';
				}else {
					
				  echo ucwords($rowtotal['status']);
				}
				
				?></td>
               <td><?= $rowtotal['country_code']?></td></tR>
                <?php $position ++; } } else { ?></tbody>
                <tbody>
<tr><td colspan="6" style="text-align:">No Record found..</td></tr>

        </tbody>
<?php  } dbClose($conn); ?>
        </table>

       

        </div>

