<?php
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$userid=$_SESSION['userid'];
$tbl_name=$_REQUEST['tbl_name'];
$tbl_name=explode("#",$tbl_name);
$tbl_name=$tbl_name[0];
$download="select * from $tbl_name limit 0";
if(!empty($_SESSION['userid'])){ 

?>
<div class="card">
<div class="">
<?php
$result = $db->execute_query($download);
while ($fieldinfo = $result -> fetch_field()) {
$field=$fieldinfo -> name; ?>
           <div class="fliter-box">
            <div class="filter-label-name">Filters <span> <?php echo $field; ?></span></div>
             <select data-width="fit" data-actions-box="true" data-selected-text-format="count > 3" data-size="5" name="<?php echo $field.'[]'; ?>" class="selectpicker form-control" multiple title="Choose Filter">
                                  
                                    <?php
                                    $query1="select distinct $field from $tbl_name";			
                                    $all_senderid_list = $db->execute_query($query1);
                                     if($all_senderid_list->num_rows>0) { 
                                             while($row_sender = $all_senderid_list->fetch_array()){ ?>  
                                      <option value="<?php echo $row_sender[$field]; ?>"><?php echo $row_sender[$field]; ?></option> 
                                      <?php }  } ?>
                          
              </select>
          </div>
          
        <?php } ?>
         
  </div>  
  </div> 
  <br />   
 <div class="row" >
              <div class="col-lg-4">
                <!-- Dropdown Card Example -->
                <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary"> Customise SMS </h6>
                  </div>
                  <!-- Card Body -->
                    <div class="filter-bar">
              <article class="card-group-item filter">
                   
                  <div class="filter-content">
                    <div class="card-body">
                    <?php
					$result = $db->execute_query($download);
 					while ($fieldinfo = $result -> fetch_field()) {
 							//$contents .= '"'.$fieldinfo -> name.'",';
							?>
                    <label class="form-check">
                        <input class="form-check-input" type="checkbox" value="">
                        <span class="form-check-label">
                          <?php echo $fieldinfo -> name; ?>
                        </span>
                      </label> <!-- form-check.// -->
                            
					<?php   } ?>
                      

                    </div> <!-- card-body.// -->
                  </div>
                </article> <!-- card-group-item.// -->
               <?php /*?> 
                <article class="card-group-item">
                  <header class="card-header">
                    <h6 class="title">Gender</h6>
                  </header>
                  <div class="filter-content">
                    <div class="card-body">
                    <label class="form-check">
                      <input class="form-check-input" type="radio" name="exampleRadio" value="">
                      <span class="form-check-label">
                       Male
                      </span>
                    </label>
                    <label class="form-check">
                      <input class="form-check-input" type="radio" name="exampleRadio" value="">
                      <span class="form-check-label">
                       Female
                      </span>
                    </label>
                    <label class="form-check">
                      <input class="form-check-input" type="radio" name="exampleRadio" value="">
                      <span class="form-check-label">
                        Some other option
                      </span>
                    </label>
                    </div> <!-- card-body.// -->
                  </div>
                </article> <!-- card-group-item.// -->

                <article class="card-group-item">
                  <header class="card-header"><h6 class="title">Tag</h6></header>
                  <div class="filter-content">
                    <div class="card-body">
                      <label class="btn btn-danger">
                        <input class="" type="checkbox" name="myradio" value="">
                        <span class="form-check-label">Plan 2</span>
                      </label>
                      <label class="btn btn-success">
                        <input class="" type="checkbox" name="myradio" value="">
                        <span class="form-check-label">Plan 2</span>
                      </label>
                      <label class="btn btn-primary">
                        <input class="" type="checkbox" name="myradio" value="">
                        <span class="form-check-label">Plan 3</span>
                      </label>
                    </div> <!-- card-body.// -->
                  </div>
                </article> <!-- card-group-item.// -->
<?php */?>
            </div>	 
               
                </div>
         </div>
 
              <div class="col-lg-8">
                <!-- Dropdown Card Example -->
                <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Send SMS</h6>
                  </div>
                  <!-- Card Body -->
                  <div class="card-body">
                       <div class="row">
                    <div class="col-md-12 mb-3">
                       <select class="form-control" name="sender_id" id="sender_id" required="">
                                     <option value="">Select Senderid</option> 
                                   <?php
                                    $query1="select * from sender_id where user_id='$userid' order by id desc";			
                                    $all_senderid_list = $db->execute_query($query1);
                                     if($all_senderid_list->num_rows>0) { 
                                             while($row_sender = $all_senderid_list->fetch_array()){ ?>  
                                      <option value="<?php echo $row_sender['sender_id_val']; ?>"><?php echo $row_sender['sender_id_val']; ?></option> 
                                      <?php }  } ?>
                          
                                    </select>
                                  </div>
                                  
                                  <div class="col-md-12 mb-3">
                       <select class="form-control" name="mobile_col" required="">
                                     <option value="">Select Mobile Colom</option> 
                                       <?php
						$result1 = $db->execute_query($download);
 					while ($fieldinfo1 = $result1 -> fetch_field()) {
							//$contents .= '"'.$fieldinfo -> name.'",';
							?>
                    <option value="<?php echo $fieldinfo1 -> name; ?>"><?php echo $fieldinfo1 -> name; ?></option> 
                            
					<?php   } ?>
                                    </select>
                                  </div>
                     <div class="col-md-12">
                
                    <div class="form-group">
                      <textarea class="form-control" rows="5" id="comment" name="message" spellcheck="false" required></textarea>
                    </div>

      
 				 <input  class="btn btn-primary btn-user btn-block"  value="Send SMS" name="submit" type="submit">
  
                                         

                    </div>
                  </div>
                  </div>
                </div>
              </div>
</div>
<script type="text/javascript">
  $('select').selectpicker();
</script>
<?php } ?>