<?php
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$userid=$_SESSION['userid'];
$tbl_name=$_REQUEST['tbl_name'];
$tbl_name=explode("#",$tbl_name);
$tbl_name=$tbl_name[0];
$download="select * from $tbl_name limit 0";
if(!empty($_SESSION['userid'])){ 

?> 
 <div class="row" >
              <div class="col-lg-4">
                <!-- Dropdown Card Example -->
                <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Send Customise SMS With Tag Names </h6>
                  </div>


                  <!-- Card Body -->
                    <div class="filter-bar">
              <article class="card-group-item filter">
                   
                  <div class="filter-content">
                    <div class="card-body">
                      
                    <?php
					$result = $db->execute_query($download);
 					while ($fieldinfo = $result -> fetch_field()) {
 							//$contents .= '"'.$fieldinfo -> name.'",';
							?>
                    <label class="form-check">
                        <span value="<?php echo $fieldinfo -> name; ?>" class="settag_field">
                          <?php echo $fieldinfo -> name; ?>
                        </span>
                      </label> <!-- form-check.// -->
                            
					<?php   } ?>
                      

                    </div> <!-- card-body.// -->
                  </div>
                </article> <!-- card-group-item.// -->
              
     <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Use Filter  </h6>
                  </div>


<div class="">
<?php
$result = $db->execute_query($download);
while ($fieldinfo = $result -> fetch_field()) {
$field=$fieldinfo -> name; ?>
           <div class="fliter-box">
  
             <select data-live-search="true" onChange="getCount(this.value);" data-style="border-bar" data-width="100%" data-actions-box="true" data-selected-text-format="count > 3" data-size="5" name="<?php echo $field.'[]'; ?>" class="selectpicker form-control" multiple title="<?php echo $field; ?> ">
                                  
                                    <?php
                                    $query1="select distinct $field from $tbl_name";      
                                    $all_senderid_list = $db->execute_query($query1);
                                     if($all_senderid_list->num_rows>0) { 
                                             while($row_sender = $all_senderid_list->fetch_array()){ ?>  
                                      <option value="<?php echo $row_sender[$field]; ?>"><?php echo $row_sender[$field]; ?></option> 
                                      <?php }  } ?>
                          
              </select>
          </div>
          
        <?php } ?>
         
  </div> 


            </div>	 
               
                </div>
         </div>
 
              <div class="col-lg-8">
                <!-- Dropdown Card Example -->
                <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Send SMS</h6>
                     <button class="btn btn-primary btn-sm btn-user"> <i class="fa fa-envelope-open"></i>
 Total Record Found :<span id="getcount2"></span> </button><br />
                  <button class="btn btn-primary btn-sm btn-user"> <i class="fa fa-envelope-open"></i>
 Total Record Selected :<span id="getcount1">0</span> </button> 
                  </div>
                  <!-- Card Body -->
                  <div class="card-body">
                       <div class="row">
                    <div class="col-md-12 mb-3">
                       <select class="form-control" name="sender_id" id="sender_id" required="">
                                     <option value="">Select Senderid</option> 
                                   <?php
                                    $query1="select * from sender_id where user_id='$userid' order by id desc";			
                                    $all_senderid_list = $db->execute_query($query1);
                                     if($all_senderid_list->num_rows>0) { 
                                             while($row_sender = $all_senderid_list->fetch_array()){ ?>  
                                      <option value="<?php echo $row_sender['sender_id_val']; ?>"><?php echo $row_sender['sender_id_val']; ?></option> 
                                      <?php }  } ?>
                          
                                    </select>
                                  </div>
                                  
                                  <div class="col-md-12 mb-3">
                       <select class="form-control" name="mobile_col" required="">
                                     <option value="">Select Mobile Colom</option> 
                                       <?php
						$result1 = $db->execute_query($download);
 					while ($fieldinfo1 = $result1 -> fetch_field()) {
							//$contents .= '"'.$fieldinfo -> name.'",';
							?>
                    <option value="<?php echo $fieldinfo1 -> name; ?>"><?php echo $fieldinfo1 -> name; ?></option> 
                            
					<?php   } ?>
                                    </select>
                                  </div>
                     <div class="col-md-12">
               
                    <div class="form-group">
                      <textarea id="txt" class="form-control" placeholder="Example : Dear #name# Thanks for the registration." rows="5" id="comment" name="message" spellcheck="false" required></textarea>
                    </div>

      
 				 <input  class="btn btn-primary btn-user btn-block" onclick="setCount();"  value="Send SMS" name="submit" type="submit">
  
                                         

                    </div>
                  </div>
                  </div>
                </div>
              </div>
</div>
<script type="text/javascript">
  $('select').selectpicker();
</script>

<script type="text/javascript">
  $(".settag_field").on('click', function() {
    var caretPos = document.getElementById("txt").selectionStart;
    var textAreaTxt = $("#txt").val();
    var txtToAdd = $(this).closest('.settag_field').text();
      var txtToAdd = $.trim(txtToAdd);

    $("#txt").val(textAreaTxt.substring(0, caretPos) + "#"+txtToAdd+"#" + textAreaTxt.substring(caretPos) );
});
</script>


<?php } ?>