<?php
date_default_timezone_set("Asia/Calcutta"); 
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$userid=$_SESSION['userid'];
$username=$_SESSION['auser_name'];
$ip=getRealIpAddr(0);
$field=explode("#",$_POST['table_name']);
$table_name=$field[0];
$form_fields="id,";
$form_fields .=$field[1];
$form_fields .=",created_date,updated_date";
$form_fields=explode(",",$form_fields);

//$filter=$_POST['filter'];
//print_r($_POST);
//print_r($_POST['Name']);
$cond ="";
$filter=0;
foreach($form_fields  as $value ) {
	//echo $value;
	if(!empty($_POST[$value])){
		//$data++;
		 $filter=1;
		 $cond .=$value.' IN ';
		 $cond .="(";
 		 foreach($_POST[$value] as $value1){
		 	$cond .="'".$value1."',";
		 }
		 //$cond=rtrim($cond,"'");
		 $cond=rtrim($cond,',');
		 $cond .=")";
		 $cond .=" AND ";
	}
}
$cond=rtrim($cond,' AND');
///echo $cond;
//echo print_r($data);
//print_r($form_fields);
 
 
$mobile_col=$_POST['mobile_col'];
$senderid=$_POST['sender_id'];
$submit_from="PANEL";
$message=$_POST['message'];	
$unicode=0;
$dt=date('Y-m-d H:i:s');
//$unicode= isset($_POST['unicode']) ? $_POST['unicode'] :0;	
$txtcampstartdate=$dt;
//$message_length=strlen($_POST['message']);		
$message_type=1;	
$camp_status=1;	

if($txtcampstartdate<=$dt){
	$status='inqueue';
}else{
	$status='schedule';
}	


$credit=getCredit($unicode,$message);
 

 if(!empty($_SESSION['userid'])){
		
   		$dataforqueue = array();
 		$db->execute_query("SET NAMES utf8");
		if($filter!=0){
	    	$query="select $mobile_col from $table_name where $cond";
		}else{
			$query="select $mobile_col from $table_name";
		}
		
		//echo $query;
		//exit();
 		$phone='';
		$result=$db->execute_query($query);
		$total_number='0';
		if($result->num_rows>0){	
 				while($row=$result->fetch_array()){
					$number=$row['Phone'];  
					if(strlen($number)>15 or strlen($number)<7 or !is_numeric($number)){ }
					else { 
						$phone .=$row['Phone'].','; 
						$total_number++;
						$dataforqueue[] = trim($number);
				     }
 		}
		$phone=rtrim($phone,',');
		}
		
		//print_r($dataforqueue);
		//exit();
 		$rowuser=getUserdetail($db,$userid);	  
		$country_price=$rowuser['sms_price'];
		$user_credit=$rowuser['currency_credits'];
		$user_block_credit=$rowuser['block_credit'];
		$block_credit=($total_number*$country_price*$credit);
		$total_block_credit=$user_block_credit+$block_credit;
		$remaining_credit=$user_credit-$block_credit;
		
		if($block_credit<=$user_credit and $total_number>0){
 		        $insert_campaign=InsertCampaignData($db,$userid,$username,$message,$credit,$total_number,$country_price,$senderid,$mobile_col,$message_type,$camp_status,$txtcampstartdate,$unicode,$block_credit,$ip,$submit_from); 
			if($insert_campaign==true){
				$campaignid=$db->getlast_insertid();
				$insert_report=InsertReportData($db,$userid,$username,$message,$credit,$total_number,$country_price,$senderid,$txtcampstartdate,$dataforqueue,$campaignid,$unicode,$status,$txtcampstartdate,$ip,$submit_from); 
					if($insert_report==true){
					
					$query3="update users set currency_credits=$remaining_credit,block_credit=$total_block_credit where id=$userid";	 		$update=$db->update($query3);
					echo 1;
					}
				
			}else{
			echo 2; //"Error Campaign ";
			}
 		}else{
			
			 echo 3;   //"Insufficient Balance Please Contact Your Cordinator";
			
		}
  		$db->dbClose();
 }




function InsertCampaignData($db,$userid,$username,$message,$credit,$total_number,$country_price,$senderid,$mobile_col,$message_type,$camp_status,$txtcampstartdate,$unicode,$block_credit,$ip,$submit_from){
		    $cc="91";
		    $query="insert into sms_campaign (user_id,username,text_message,msg_count,contact_count,msg_cost,country_code,camp_start_datetime,sender_id,unicode,sender_ip_address,submit_from,mobile_col,block_cr,message_type,status) values('$userid','$username','$message','$credit','$total_number','$country_price','$cc','$txtcampstartdate','$senderid','$unicode','$ip','$submit_from','$mobile_col','$block_credit','$message_type','$camp_status')";
 			$sqlcamp = $db->insert($query);
 			if($sqlcamp!=false){
				return true;
			}else{
			    return false;	
 			}
}





function InsertReportData($db,$userid,$username,$message,$credit,$total_number,$country_price,$senderid,$txtcampstartdate,$dataforqueue,$campaignid,$unicode,$status,$starttime,$ip,$submit_from){
	     $valuesArr=array();
		 $valuesArr_que=array();
 		 $cc="91";
		 $campaign_name="Camp";
 		 $query_report = "INSERT INTO sms_reports(campaign_id,campaign_message,user_id,username,sender_id,unicode,phone_number,starttime,msg_count,sender_ip_address,country_code,submit_from,msg_cost,status) values ";
		 
		 $query_que = "INSERT INTO sms_queue(campaign_id,campaign_message,user_id,username,sender_id,unicode,phone_number,country_code,msg_count,status) values ";
		 	
			
	   foreach($dataforqueue as $val){
 				 $phone_number = "91".substr($val, -10, 10); 
 				 // array for report data
				 $valuesArr[] = "('$campaignid','$message','$userid','$username','$senderid','$unicode','$phone_number','$txtcampstartdate','$credit','$ip','$cc','$submit_from','$country_price','$status')";
  					// array for que data
				 $valuesArr_que[] = "('$campaignid','$message','$userid','$username','$senderid','$unicode','$phone_number','$cc','$credit','$status')";
 		}
		$query_report .= implode(',', $valuesArr);
 		$query_que .= implode(',', $valuesArr_que);
		
		$ins_report = $db->insert($query_report);
		$ins_que = $db->insert($query_que);
 		if($ins_report!=false and $ins_que!=false){
			return true;
		}else{
			return false;	
		}
}


function getUserdetail($db,$userid){
		$seluser=$db->execute_query("select username,currency_credits,block_credit,sms_price from users where id=$userid");
		$rowuser=$seluser->fetch_assoc();	
		return $rowuser;
		
}

function getCredit($unicode,$message){
	    if($unicode == 1){
				$tmpmsg = $message;
				//$msgtype=2;
				$twochar = array("{", "}","[","]","^","|","\\","~","\n");
				$rplString   = array("  ","  ","  ","  ","  ","  ","  ","  ","");
				$tmpmsg = str_replace($twochar, $rplString, $tmpmsg);
				$strlen = strlen(utf8_decode(html_entity_decode($tmpmsg, ENT_COMPAT, 'utf-8')));
				//$text = utf8_encode($text);
				//$text= utf8_decode(html_entity_decode($text, ENT_COMPAT, 'utf-8'));
				if($strlen>70)
						$credit=ceil($strlen/67);
				else
						$credit=ceil($strlen/70);
		}else{
				$tmpmsg = $message;
				$twochar = array("{", "}","[","]","^","|","\\","~","\n");
				$rplString   = array("  ","  ","  ","  ","  ","  ","  ","  ","");
				$tmpmsg = str_replace($twochar, $rplString, $tmpmsg);
		
				$strlen = strlen(utf8_decode(html_entity_decode($tmpmsg, ENT_COMPAT, 'utf-8')));
				if($strlen>160)
						$credit=ceil($strlen/153);
				else
						$credit = ceil($strlen/160);
		}
		return $credit; 
}


function getkey(){
 	  $keychars = "ABCDEFGHIJKLMNOPQRSTWVXYZ0123456789abcdefghijklmnopqrstuvwxyz";
	 
		$length = 6;
		$randkey = "";
		$randkey2 = "";
		 for ($i=0;$i<$length;$i++)  $randkey .= substr($keychars, rand(1, strlen($keychars) ), 1);
		return $randkey;
}
function getRealIpAddr($ip)
 {
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    { 
     $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
 
?>