<?php $active = $_SERVER["PHP_SELF"]; 
$profile_group_id=$_SESSION['profile_group_id'];
?>
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
<!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo $baseurl?>dashboard/home">
  
    <div class="sidebar-brand-text mx-3"><img src="<?php echo $baseurl?>dashboard/img/logo-white.png"></div>
    </a>
    <!-- Divider -->
    <hr class="sidebar-divider my-0">
<!-- Nav Item - Dashboard -->
     <li <?php if (strpos($active, 'home.php') !== false){echo 'class="nav-item active"';}else {
      echo 'class="nav-item"';}?>> 
    <a class="nav-link" href="<?php echo $baseurl?>dashboard/home">
    <i class="fas fa-fw fa-tachometer-alt"></i>
    <span>Dashboard</span></a>
    </li>
    
    
    <?php
	if($profile_group_id!=1){
	?>
    <!-- Divider -->
    <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
    FORM
    </div>
    <!-- Nav Item - Pages Collapse Menu -->
    <li <?php if (strpos($active, 'create-form.php') !== false or strpos($active, 'list-of-forms.php') !== false ){echo 'class="nav-item active"';} else {
      echo 'class="nav-item"';

    }?>>
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
    <i class="fas fa-fw fa-folder"></i>
    <span>Manage Form</span>
    </a>
    <div id="collapsePages" <?php if (strpos($active, 'form/create-form.php') !== false or strpos($active, 'form/list-of-forms.php') !== false){echo 'class="collapse show"';} else {
      echo 'class="collapse"';

    }?> aria-labelledby="headingPages" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <!--<h6 class="collapse-header">Create Form</h6>-->
      <a class="collapse-item" href="<?php echo $baseurl?>dashboard/form/create-form">Create Form</a>
      <a class="collapse-item" href="<?php echo $baseurl?>dashboard/form/list-of-forms.php">List Form</a>
    </div>
    </div>
    </li>
    
    <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
     SMS
    </div>
    <!-- Nav Item - Pages Collapse Menu -->
    <li <?php if(strpos($active, 'send-sms.php') !== false or strpos($active, 'sender-id.php') !== false or strpos($active, 'web-report.php') !== false  or strpos($active, 'api-report.php') !== false ){echo 'class="nav-item active"';} else {
      echo 'class="nav-item"';

    }?>>
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse6" aria-expanded="true" aria-controls="collapse6">
    <i class="fas fa-fw fa-folder"></i>
    <span>SMS</span>
    </a>
    <div id="collapse6" <?php if(strpos($active, 'send-sms.php') !== false or strpos($active, 'sender-id.php') !== false or strpos($active, 'web-report.php') !== false  or strpos($active, 'api-report.php') !== false){echo 'class="collapse show"';} else {
      echo 'class="collapse"';

    }?> aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="<?php echo $baseurl?>dashboard/sms/send-sms">Send SMS</a>  
             <a class="collapse-item" href="<?php echo $baseurl?>dashboard/sms/sender-id">Sender ID</a>  
              <a class="collapse-item" href="<?php echo $baseurl?>dashboard/sms/sms-report">Web Report</a>  
             </div>
    </div>
    </li>
   
     <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
     TRIGGER
    </div>
    <!-- Nav Item - Pages Collapse Menu -->
    <li <?php if(strpos($active, 'custom-trigger.php') !== false or strpos($active, 'senderid.php') !== false or strpos($active, 'new-trigger.php') !== false  or strpos($active, 'tigger-list.php') !== false ){echo 'class="nav-item active"';} else {
      echo 'class="nav-item"';

    }?>>
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsetrigger" aria-expanded="true" aria-controls="collapsetrigger">
    <i class="fas fa-fw fa-folder"></i>
    <span>Set Trigger</span>
    </a>
    <div id="collapsetrigger" <?php if(strpos($active, 'custom-trigger.php') !== false or strpos($active, 'tigger-list.php') !== false ){echo 'class="collapse show"';} else {
      echo 'class="collapse"';

    }?> aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="<?php echo $baseurl?>dashboard/trigger/custom-trigger">New Trigger</a> 

                  <a class="collapse-item" href="<?php echo $baseurl?>dashboard/trigger/tigger-list">List Of Trigger</a>  
                
           </div>
    </div>
    </li>
    
    
     
    <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
   VOICE
    </div>
    <!-- Nav Item - Pages Collapse Menu -->
    <li <?php if(strpos($active, 'send-sms.php') !== false or strpos($active, 'senderid.php') !== false or strpos($active, 'web-report.php') !== false  or strpos($active, 'api-report.php') !== false ){echo 'class="nav-item active"';} else {
      echo 'class="nav-item"';

    }?>>
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse7" aria-expanded="true" aria-controls="collapse7">
    <i class="fas fa-fw fa-folder"></i>
    <span>VOICE</span>
    </a>
    <div id="collapse7" <?php if(strpos($active, 'list-voice.php') !== false ){echo 'class="collapse show"';} else {
      echo 'class="collapse"';

    }?> aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="<?php echo $baseurl?>dashboard/voice/list-voice">List Voice</a> 
              <a class="collapse-item" href="<?php echo $baseurl?>dashboard/voice/voice_report">Voice Report</a> 
           </div>
    </div>
    </li>
    
    
    
   
    <!-- Nav Item - Pages Collapse Menu -->
   
  <!-- Divider -->
  <!--   <hr class="sidebar-divider d-none d-md-block">
    <div class="sidebar-heading">
     Send SMS 
    </div>
    <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages2" aria-expanded="true" aria-controls="collapsePages2">
        <i class="fas fa-fw fa-folder"></i>
        <span>SMS Setting</span>
      </a>
      <div id="collapsePages2" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
          <h6 class="collapse-header"> SMS Setting / Trigger </h6>
          <a class="collapse-item" href="add-server"> SMS Trigger </a>
          <a class="collapse-item" href="edit-agent"> Send Bulk SMS </a>
          <a class="collapse-item" href="edit-agent"> Add More Phone </a>
          
        </div>
      </li> -->
       <!-- Divider -->


    <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
    My Account
    </div>
    <!-- Nav Item - Pages Collapse Menu -->
    <li <?php if (strpos($active, 'profile-details.php') !== false or strpos($active, 'change-password.php') !== false ){echo 'class="nav-item active"';} else {
      echo 'class="nav-item"';

    }?>>
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse4" aria-expanded="true" aria-controls="collapse4">
    <i class="fas fa-fw fa-folder"></i>
    <span>Account Setting</span>
    </a>
    <div id="collapse4" <?php if (strpos($active, 'profile-details.php') !== false or strpos($active, 'change-password.php') !== false){echo 'class="collapse show"';} else {
      echo 'class="collapse"';

    }?> aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
        
             <a class="collapse-item" href="<?php echo $baseurl?>dashboard/profile-details">Profile Details </a>  
                  <a class="collapse-item" href="<?php echo $baseurl?>dashboard/change-password">Change Password </a>  
            </div>
    </div>
    </li>
    <!-- Nav Item - Pages Collapse Menu -->
  <?php }if($profile_group_id!=3){   ?>
     <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
    Manage User
    </div>
    <!-- Nav Item - Pages Collapse Menu -->
    <li <?php if (strpos($active, 'add-user.php') !== false or strpos($active, 'list-user.php') !== false ){echo 'class="nav-item active"';} else {
      echo 'class="nav-item"';

    }?>>
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse51" aria-expanded="true" aria-controls="collapse51">
    <i class="fas fa-fw fa-folder"></i>
    <span>Manage User</span>
    </a>
    <div id="collapse51" <?php if (strpos($active, 'add-user.php') !== false or strpos($active, 'list-user.php') !== false){echo 'class="collapse show"';} else {
      echo 'class="collapse"';

    }?> aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              
             <a class="collapse-item" href="<?php echo $baseurl?>dashboard/user/add-user">Add User</a>  
             <a class="collapse-item" href="<?php echo $baseurl?>dashboard/user/list-user">List User</a>  
            </div>
    </div>
    </li>
   <?php }if($profile_group_id==1){   ?>  
    
    
      <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
    SMS
    </div>
    <!-- Nav Item - Pages Collapse Menu -->
    <li <?php if (strpos($active, 'sms-report.php') !== false or strpos($active, 'sender-id.php') !== false ){echo 'class="nav-item active"';} else {
      echo 'class="nav-item"';

    }?>>
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse52" aria-expanded="true" aria-controls="collapse52">
    <i class="fas fa-fw fa-folder"></i>
    <span>SMS</span>
    </a>
    <div id="collapse52" <?php if (strpos($active, 'sms-report.php') !== false or strpos($active, 'sender-id.php') !== false){echo 'class="collapse show"';} else {
      echo 'class="collapse"';

    }?> aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              
             <a class="collapse-item" href="<?php echo $baseurl?>dashboard/sms/sms-report">SMS Report</a>  
             <a class="collapse-item" href="<?php echo $baseurl?>dashboard/sms/sender-id">Request Sender ID</a>  
            </div>
    </div>
    </li>
    
     <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
    Voice
    </div>
    <!-- Nav Item - Pages Collapse Menu -->
    <li <?php if (strpos($active, 'list-voice.php') !== false or strpos($active, 'voice-report.php') !== false ){echo 'class="nav-item active"';} else {
      echo 'class="nav-item"';

    }?>>
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse58" aria-expanded="true" aria-controls="collapse58">
    <i class="fas fa-fw fa-folder"></i>
    <span>Voice</span>
    </a>
    <div id="collapse58" <?php if (strpos($active, 'list-voice.php') !== false or strpos($active, 'voice-report.php') !== false){echo 'class="collapse show"';} else {
      echo 'class="collapse"';

    }?> aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
             <a class="collapse-item" href="<?php echo $baseurl?>dashboard/voice/list-voice">List Voice</a> 
             <a class="collapse-item" href="<?php echo $baseurl?>dashboard/voice/voice-report">Voice Report</a>  
             </div>
    </div>
    </li> 
    
     <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
    Form List
    </div>
    <!-- Nav Item - Pages Collapse Menu -->
    <li <?php if (strpos($active, 'sms-report.php') !== false){echo 'class="nav-item active"';} else {
      echo 'class="nav-item"';

    }?>>
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse53" aria-expanded="true" aria-controls="collapse53">
    <i class="fas fa-fw fa-folder"></i>
    <span>Form List</span>
    </a>
    
    <div id="collapse53" <?php if (strpos($active, 'sms-report.php') !== false or strpos($active, 'voice-report.php') !== false){echo 'class="collapse show"';} else {
      echo 'class="collapse"';

    }?> aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              
             <a class="collapse-item" href="<?php echo $baseurl?>dashboard/form/list-of-forms">Form List</a>  
             </div>
    </div>
    </li>
    
    
    
    
    
    
     <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
   Voter List
    </div>
    <!-- Nav Item - Pages Collapse Menu -->
    <li <?php if (strpos($active, 'voter-list.php') !== false){echo 'class="nav-item active"';} else {
      echo 'class="nav-item"';

    }?>>
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse54" aria-expanded="true" aria-controls="collapse54">
    <i class="fas fa-fw fa-folder"></i>
    <span>Voter List</span>
    </a>
    
    <div id="collapse54" <?php if (strpos($active, 'voter-list.php') !== false){echo 'class="collapse show"';} else {
      echo 'class="collapse"';

    }?> aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              
             <a class="collapse-item" href="<?php echo $baseurl?>dashboard/Form/voter-list">Voter List</a>  
             </div>
    </div>
    </li>
    
    
  <?php  } ?>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">
      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>
</ul>