<?php
include_once 'lib/session.php';
include_once 'lib/database.php';
include_once 'lib/db_config.php';
include_once 'lib/user.php';
$db = new user();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Coupon Dashboard</title>
    <?php include_once 'inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
  <div id="wrapper">
      <!-- Sidebar -->
  <?php include_once 'inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
  <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
  <div id="content">
          <!-- Topbar -->
  <?php include_once 'inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">  Change Password  </h1>
              
            </div>
            <div class="row">
              
              <div class="col-lg-12">
                <!-- Dropdown Card Example -->
                <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary"> Set New Password </h6>
                    
                  </div>
                  <!-- Card Body -->

              




                  <div id="form-create" class="card-body">

           
                   <div style="display: none;" id="status" class="alert" role="alert">
                     <span id="statusText"></span>
                    </div>
                   

                    <!-- Card Header - Accordion -->
                    <form id="chnagePassword" action="" method="post">
                      <div class="row">
                        <div class="form-group col-md-4">
                          <label for="email">Old Password:</label>
                          <input type="text" required="" id="old_password" name="old_password" class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                          <label for="email">New Password :</label>
                          <input type="text" required="" id="new_password" name="new_password" class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                          <label for="email">Confirm New Password:</label>
                          <input type="text" required="" id="confirm_password" name="confirm_password" class="form-control">
                        </div>
                      </div>
                    <div class="text-right">
                      <button  class="btn btn-primary btn-user">Save</button>
                     <!--  <input  class="btn btn-primary btn-user"  value="Save" name="submit" type="butto" name=""> -->
                    </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once 'inc/footer.php'; ?>


<!-- send data to database funcation  -->

<script type="text/javascript">

    $(document).ready(function(){

    $("#chnagePassword").submit(function(){
  
        $.post("ajax/change_password.php",{ 
          old_password:$('#old_password').val(),
          new_password:$('#new_password').val(),
          confirm_password:$('#confirm_password').val()
          },
          function(data){
          console.log('data=',data);
          if(data==1){

          var status = document.getElementById('status');
            status.classList.add("alert-danger").innerHTML = "Paragraph changed!";
          }

          else if(data==2){

                 var status = document.getElementById('status');
                 status.style.display = "block";
                 var statusText = document.getElementById('statusText');
                 status.classList.add("alert-danger");
                 statusText.innerHTML = "Old password is incorrect";
              
          }

          else if(data==3) {

                 var status = document.getElementById('status');
                 status.style.display = "block";
                 var statusText = document.getElementById('statusText');
                 status.classList.add("alert-danger");
                 statusText.innerHTML = "New password should be confirm same as password";
             
          }

          else {

            var status = document.getElementById('status');
            status.style.display = "block";
                 var statusText = document.getElementById('statusText');
                 status.classList.remove("alert-danger");
                 status.classList.add("alert-success");
                 statusText.innerHTML = "your password has been changed successfully.";

                 $("#chnagePassword")[0].reset(); 
             
           }
                
        });
   return false;

 });

   });

</script>


  </body>
</html>