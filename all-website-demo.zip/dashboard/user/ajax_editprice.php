<?php  
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$User_id=$_SESSION['userid'];
 
$sms_price=$_POST['sms_price'];
$voice_price=$_POST['voice_price'];
$voice_pulse=$_POST['pulse'];
$id=$_POST['id']; 
 
  
if(!empty($_SESSION['userid']) && $sms_price!=='' && $voice_price!=='' && $voice_pulse!==''){
  		    $dt=date('Y-m-d:h:i:s');	
			 $query="update users set voice_price='$voice_price',
 								sms_price='$sms_price',
 								voice_pulse='$voice_pulse'
 								where id=$id";		  
			
			
			$query1="insert into price_history(user_id,sms_price,voice_price,voice_pulse,update_date) values('$User_id','$sms_price','$voice_price','$voice_pulse','$dt')";	
			
			////echo $query to update user admin balance;
			   
			  $result=$db->update($query);	
			  $result_insert=$db->insert($query1);	
			 
			 // $query2="insert into sender_id(user_id,sender_id_val,status,created_date)values('$User_id','TXTSMS','1','$dt')";
			 // $insert_senderid=$db->insert($query2);	
				if($result){
				echo 1;//"saved";
				//header('location:add.php');
				}else{
				echo 2;// "Could not saved!";
				} 
 		
	 	  						
	$db->dbClose();
}else{
echo 5;	//required field missing please fill all requird fields
}
 
?>