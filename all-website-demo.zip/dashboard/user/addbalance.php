<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
$id=isset($_GET['id']) ? $_GET['id']:'';
 
$seluser=$db->execute_query("select * from users where id=$id");
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Coupon Dashboard</title>
    <?php include_once '../inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
           <div class="container-fluid">
            <!-- Page Heading -->

            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">  Add Balance   </h1> 
             
            </div>

      

          
        

              <!-- Dropdown Card Example -->
              <div class="card shadow   mb-4">

                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary"> Add Balance balace to user account </h6>
                
                </div>
                <!-- Card Body -->
                <div  class="card-body">

                                    <p class="price">
                                	

<a href="javascript:void(0)" class="btn btn-primary btn-icon-split">
                    <span class="icon text-white-50">
                      <i class="fas fa-exclamation-triangle"></i> Current Balance: 
                    </span>
                    <span class="text"><?php if($seluser){
                  $rowuser=$seluser->fetch_array();
                  echo "".round($rowuser['currency_credits'],2);
                  ?></span>
                  </a>


                                 </p>
                                    <form role="form" name="frm" id="frm" method="post">
                                    <input type="hidden" name="id" value="<?php echo $rowuser['id']?>">
                                    <input type="hidden" name="credits" value="<?php echo $rowuser['currency_credits']?>">

                                        <div class="form-group ">
                                       		<label>Add Amount*</label>
                                           <input class="form-control" placeholder="Amount" name="newcredits" value="" required>
                                        </div> 

                                        <div class="form-group ">
                                       		<label>Remarks*</label>
                                           <textarea class="form-control" placeholder="Remarks" name="remarks"></textarea>
                                        </div>                                                             
                                        <button type="submit"  class="d-none float-right d-sm-inline-block btn btn-sm btn-primary shadow-sm" id="sendnou">Add</button>
                                    </form>
                                    <?php }else{
									echo 'wrong attempts';	
									}?>
                                    <div id="err"></div>                                        
                                </div>
                            </div>
           
           
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
 <script>
$(document).ready(function (e) {
 
 $("#frm").on('submit',(function(e) {
	$("#sendnou").attr('disabled',true);
	e.preventDefault();
	$.ajax({
		url: "ajax_addbalance.php",
		type: "POST",
		data:  new FormData(this),
		contentType: false,
		cache: false,
		processData:false,
		beforeSend : function(){
		//$("#preview").fadeOut();
		console.log('before call');
		$("#err").fadeOut();
		},
		success: function(data){
			$("#sendnou").removeAttr("disabled");
			console.log('success call',data);	
			if(data=='1'){
			  $("#err").hide();				  
			 // $("#success").html("Added Successfully!").fadeIn();				
			   alert('Balance Added Successfully');			
			   $("#frm")[0].reset(); 
			   location.reload();
			   $('#toTop').trigger('click');			  					
			}
			else if(data =='2'){
				 $("#success").hide();
				 $("#err").html('Something went wrong. Please try again!').fadeIn();	
			}else if(data =='3'){
				 $("#success").hide();
				 $("#err").html('required field missing please fill all requird fields').fadeIn();	
			}else if(data =='4'){
				 $("#success").hide();
				 $("#err").html('Insufficent Balance').fadeIn();	
			}else if(data =='5'){
				 $("#success").hide();
				 $("#err").html('Invalid amount! only allow current + new amount >=0').fadeIn();	
			}else if(data =='6'){
				 $("#success").hide();
				 $("#err").html('Record already inserted,Please check').fadeIn();	
			}else{
			  $("#success").hide();				  
			  $("#err").html("Something went wrong. Please try again!").fadeIn();				
			}
		 },
		 error: function(e){
			  console.log('error call');
				$("#err").html(e).fadeIn();
		}          
	});
 }));
});
</script>
    
      </body>
    </html>