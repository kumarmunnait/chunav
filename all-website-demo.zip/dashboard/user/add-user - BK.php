<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.css">
    <title>Add User</title>
    <?php include_once '../inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->
             <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">  Add User</h1>  
             </div>
           <div class="row">
               <div class="col-lg-12">
               <!-- Dropdown Card Example -->
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                     <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Add New User </h6>
                
                </div>


                 <!-- Card Body -->
                <div id="form-create" class="card-body">
                      <!-- Card Header - Accordion -->
                  <form role="form" name="frm" id="frm" method="post">

                  
                   <div class="form-group">
                    <label for="email">User Group:</label>
                    <select class="form-control" name="selgroup" id="selgroup" required>
                                        	<?php //$_SESSION['profile_group_id']=1;
											$query ="select * from user_profile_group where id!=1";
											   $grp_list = $db->execute_query($query);
 												echo "<option value=\"\">Select Group</option>";
													 while($rowgroup = $grp_list->fetch_array()):
 													 if($_SESSION['profile_group_id']==2){
														if($rowgroup['id']!=1){
														?><option value="<?php echo $rowgroup['id']?>"><?php echo $rowgroup['group_name']?></option><?php
														}
													}else{
													?><option value="<?php echo $rowgroup['id']?>"><?php echo $rowgroup['group_name']?></option><?php
													}
 									 endwhile; 	 ?>
 			</select>
                  </div>
                  <div class="row">
                  <div class="form-group col-md-6">
                    <label for="email">Name:</label>
                      <input class="form-control" placeholder="Enter name" name="txtname" required>
                  </div>

                   <div class="form-group col-md-6">
                    <label for="email">Email address:</label>
                      <input class="form-control" placeholder="Email" name="txtemail" required>
                  </div>

                   <div class="form-group col-md-6">
                    <label for="email">Phone No:</label>
                     <input class="form-control" placeholder="Mobile" name="mobile" required>
                  </div>

                   <div class="form-group col-md-6">
                    <label for="email">User Name:</label>
                   <input class="form-control" placeholder="username" id="txtusername" name="txtusername" onFocus="$('#errormessage').html('').removeClass();"  onChange="checkuser();" required>
                  </div>
                 
                   <div class="form-group col-md-6">
                    <label for="email">Password:</label>
                  <input type="password" class="form-control" placeholder="password" id="password" name="password" onFocus="$('#errorpassword').html('');" required>
                  </div>
                  
                    <div class="form-group col-md-6">
                    <label for="email">Currency:</label>
                    <select class="form-control" name="currency" required>
                                          <option value="">Select Currency</option>
                                        	 <option value="INR">INR</option> 
                                              <option value="EUR">EURO</option> 
                                               <option value="USD">USD</option>                                          
											</select>
                  </div>
                 
                  <div class="form-group col-md-6">
                    <label for="email">Organisation:</label>
                  <input type="text" class="form-control" placeholder="Organisation" name="organization">
                  </div>
                  <div class="form-group col-md-6">
                    <label for="email">Expired On:</label>
                    <input class="form-control" id="datepicker" autocomplete="off"  placeholder="YYYY-mm-dd" name="expired_on" required>
                  </div>
                       </div>
                   <div class="form-group">
  <label for="comment">Address:</label>
  <textarea class="form-control" rows="5" id="comment" nsme="address"></textarea>
</div>

 <div class="form-group">
  <label for="comment">Remark:</label>
  <textarea class="form-control" rows="5" id="comment" nsme="remark"></textarea>
</div>
                   
 
          <button type="submit" class="d-none float-right d-sm-inline-block btn btn-sm btn-primary shadow-sm" id="sendnou">Create</button>

        
                </form>




              </div>


              </div>


            </div>

          </div>
           
           
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
    <script>
$(document).ready(function (e) {
 $("#frm").on('submit',(function(e) {
	e.preventDefault();
	//var termc=$('#termandconditioncheckbox').attr('checked');
	//console.log('term and condition',termc);
	$.ajax({
		url: "ajax_adduser.php",
		type: "POST",
		data:  new FormData(this),
		contentType: false,
		cache: false,
		processData:false,
		beforeSend : function(){
		//$("#preview").fadeOut();
		console.log('before call');
		$("#err").fadeOut();
		},
		success: function(data){
			console.log('success call',data);
			data=data.trim();	
			if(data=='1'){
			  $("#err").hide();				  
			  $("#success").html("User Created Successfully!").fadeIn();	
			    alert('User Created Successfully');				
			    $("#frm")[0].reset(); 		 
			    document.location='list-user.php'; 					
			}
			else if(data =='2'){
				 $("#success").hide();
				 $("#err").html('Something went wrong. Please try again!').fadeIn();	
				  alert('Something went wrong. Please try again');	
			}else if(data =='3'){
				 $("#success").hide();
				 $("#err").html('User Already exist please use different').fadeIn();	
				  alert('User Already exist please use different');	
			}else if(data =='4'){
				 $("#success").hide();
				 $("#err").html('password and confirm password mismatch').fadeIn();	
				  alert('password and confirm password mismatch');	
			}else if(data =='5'){
				 $("#success").hide();
				 $("#err").html('required field missing please fill all requird fields').fadeIn();	
				  alert('required field missing please fill all requird fields');	
			}else if(data =='6'){
				 $("#success").hide();
				 $("#err").html('You Dont Have Enough Balance').fadeIn();
				  alert('You Dont Have Enough Balance');			
			}else if(data =='11'){
				$("#notification").show();
				 $("#success").hide();
				 $("#err").html('invalid username, allow only alphanumeric without space, max 15 charcter').fadeIn();	
			}else{
			  $("#success").hide();				  
			  $("#err").html("Something went wrong. Please try again!").fadeIn();	
			   alert('Something went wrong. Please try again!');				
			}
		 },
		 error: function(e){
			  console.log('error call');
				$("#err").html(e).fadeIn();
		}          
	});
 }));
});
function checkuser(){
	var user=$('#txtusername').val();
	console.log('user',user);
	//$("#errormessage").html('User already exist');
	$.post("ajax_checkuser.php",{ user:''+user+'',rand:Math.random() } ,function(data){
          var data=data.trim();
          console.log(data);
          if(data=='Available') //if correct login detail
          {
              $("#errormessage").html('Available').addClass('alert-success');
          }
          else{
            $("#errormessage").html(data).addClass('alert-danger');    
          }
                
        });
        return false; //not to post the  form physically
 
}
function checkcpassword(){
	if($('#password').val()!=$('#repassword').val()) //if correct login detail
	{
	  $("#errorpassword").html('Password and confirm password mismatch').addClass('alert-danger');
	}
	
}
</script>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/3.2/select2.min.js"></script>
    <!-- datetime picker -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.14/jquery.datetimepicker.full.js"></script>
    <!-- end datatime-->
    <script>
	/*
	   $( function() {
    	$( "#datepicker" ).datepicker({minDate: 0});
		
 		} );*/
     $("#selectgroup").select2();
	   $(".select2-input").css('width','150px');
	 
		
		$('#datepicker').datetimepicker({
			minDate: 0,
  			//format:"Y-m-d h:i a",
			format:"Y-m-d",
  			step:15
		});
    $('#seltype').change(function(){ // click to
              var type=$("#seltype").val();
			 
			  if(type==1)
			  {
				  // alert(type);
				//  $("#dnd").attr('disabled',true);
				//$("#dnd").attr('checked', true);
				
				$('input[name=dnd]').prop("checked", true);
 				$("#dnd1").hide();
				  
			  }else{
			 	// $("#dnd").removeAttr('disabled');
				$("#dnd1").show();
				 //$("#dnd").attr('checked', false);
 			    $('input[name=dnd]').prop("checked", false);
			  }
 });	
 
 
 $('#selroute').change(function(){ // click to
              var type=$("#selroute").val();
			 
			  if(type==14 || type==15)
			  {
				  // alert(type);
				//  $("#dnd").attr('disabled',true);
				//$("#dnd").attr('checked', true);
   				$("#dnd_route").show();
				  
			  }else{
			 	// $("#dnd").removeAttr('disabled');
				$("#dnd_route").hide();
				 //$("#dnd").attr('checked', false);
 			  }
 });		
		
		</script>
    
      </body>
    </html>