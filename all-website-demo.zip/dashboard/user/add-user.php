<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.css">
    <title>Add User</title>
    <?php include_once '../inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->
             <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">  Add User</h1>  
             </div>
           <div class="row">
               <div class="col-lg-12">
               <!-- Dropdown Card Example -->
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                     <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Add New User </h6>
                
                </div>


                 <!-- Card Body -->
                <div id="form-create" class="card-body">
                      <!-- Card Header - Accordion -->
                  <form role="form" name="frm" id="frm" method="post">

                  <div class="row">
                   <div class="form-group col-md-6">
                    <label for="email">User Group:</label>
                    <select class="form-control" onChange="getFormfields(this.value)" name="selgroup" id="selgroup" required>
                                          <?php //$_SESSION['profile_group_id']=1;
                      $query ="select * from user_profile_group where id!=1";
                         $grp_list = $db->execute_query($query);
                        echo "<option value=\"\">Select Group</option>";
                           while($rowgroup = $grp_list->fetch_array()):
                           if($_SESSION['profile_group_id']==2){
                            if($rowgroup['id']!=1){
                            ?><option value="<?php echo $rowgroup['id']?>"><?php echo $rowgroup['group_name']?></option><?php
                            }
                          }else{
                          ?><option value="<?php echo $rowgroup['id']?>"><?php echo $rowgroup['group_name']?></option><?php
                          }
                   endwhile;   ?>
                </select>
                  </div>

                  <div class="form-group col-md-6">
                   <label for="email">Name:</label>
                      <input class="form-control" placeholder="Enter name" name="txtname" required>
                  </div>
                  

                   <div class="form-group col-md-6">
                    <label for="email">Email address:</label>
                      <input class="form-control" placeholder="Email" name="txtemail" required>
                  </div>

                   <div class="form-group col-md-6">
                    <label for="email">Mobile No:</label>
                     <input class="form-control" placeholder="Mobile" name="mobile" required>
                  </div>

                   <div class="form-group col-md-6">
                   <label for="email">Alernate Mobile No:</label>
                     <input class="form-control" placeholder="Mobile" name="altmobile" required>
                  </div>

                   <div class="form-group col-md-6">
                    <label for="email">User Name:</label>
                   <input class="form-control" placeholder="username" id="txtusername" name="txtusername" required>
                  </div>
                 
                   <div class="form-group col-md-6">
                    <label for="email">Password:</label>
                  <input type="password" class="form-control" placeholder="password" id="password" name="password" onFocus="$('#errorpassword').html('');" required>
                  </div>
                  
                    <div class="form-group col-md-6">
                    <label for="email">Currency:</label>
                    <select class="form-control" name="currency" required>
                          <option value="">Select Currency</option>
                          <option value="INR">INR</option> 
                          <option value="EUR">EURO</option> 
                          <option value="USD">USD</option>                                          
                      </select>
                  </div>
                 
                  <div class="form-group col-md-6">
                     <label for="email">Expired On:</label>
                    <input class="form-control" id="datepicker" autocomplete="off"  placeholder="YYYY-mm-dd" name="expired_on" required>
               
                            
                  </div>
                  <div class="form-group col-md-6">
                  <label for="comment">Pin Code:</label>
                  <input type="number" class="form-control" placeholder="Pincode" name="pin">
                  
                 
                  </div>
                       </div>
                       
             
                       
                  
                  <div class="row">
                       <div class="form-group col-md-6">
                         <label for="email">State:</label>
                                      <select class="form-control" onChange="getDistrict(this.value)" name="state" id="state" required>
                                                  <?php //$_SESSION['profile_group_id']=1;
                      $query1 ="select * from state order by name";
                         $grp_list1 = $db->execute_query($query1);
                        echo "<option value=\"\">Select State</option>";
                           while($rowgroup1 = $grp_list1->fetch_array()):
                            ?><option value="<?php echo $rowgroup1['id']?>"><?php echo $rowgroup1['name']?></option><?php
                            
                   endwhile;   ?>
                   </select>
                                        
                 
                                  </div>
                                  <div class="form-group col-md-6">
                                   <label for="email">District:</label>
                                     <select class="form-control"  name="district" id="district" required> 
                                     		 <option value="">Select State First</option>
                 					 </select>
                                  </div>
 					</div>
     <span id="reseller" style="display:none;">
                    
                             <div class="row">

                             <div class="form-group col-md-4">
                                     <label for="email">Account Number :</label>
                                      <input type="text" class="form-control" placeholder="Account Number" name="acc_number">
                              </div>
                                  <div class="form-group col-md-4">
                                    <label for="email">Account Name :</label>
                                      <input type="text" class="form-control" placeholder="Account Name" name="acc_name">
                                  </div>

                                   <div class="form-group col-md-4">
                                    <label for="email">Bank Name :</label>
                                      <input type="text" class="form-control" placeholder="Bank Name" name="bank_name">
                                  </div>
                  
                        </div>
                         
                             <div class="row">
                             <div class="form-group col-md-6">
                                     <label for="email">IFSC Code :</label>
                                      <input type="text" class="form-control" placeholder="IFSC" name="ifsc">
                         </div>
                                  <div class="form-group col-md-6">
                                    <label for="email">Addhar Card Number :</label>
                                      <input type="text" class="form-control" placeholder="Adhaar No" name="aadhar">
                                  </div>
                         </div>
                        
                           
                        </span>
                         <span id="user" style="display:none;">
                    
                             <div class="row">
                             <div class="form-group col-md-4">
                                     <label for="email">Industry :</label>
                                      <input type="text" class="form-control" placeholder="industry" name="industry">
                         </div>
                                  <div class="form-group col-md-4">
                                    <label for="comment">Business Type:</label>
                                   <select class="form-control" name="businesstype">
                                          <option value="">Select Business</option>
                                           <option value="Retail">Retail</option> 
                                              <option value="Health">Health</option> 
                                                                                         
                                </select>
                                  </div>

                                   <div class="form-group col-md-4">
                                     <label for="email">GST :</label>
                                      <input type="text" class="form-control" placeholder="gst" name="gst">
                         </div>
                  
                        </div>
                         
                           
                        </span>
                     <div class="row">
                             <div class="form-group col-md-6">
                                     <label for="email">Organisation:</label>
                                      <input type="text" class="form-control" placeholder="Organisation" name="organization">
                         </div>

                          <div class="form-group col-md-6">
                                     <label for="email">Remark:</label>
                                      <input type="text" class="form-control" placeholder="Remark" name="remark">
                         </div>
                              
                  
                        </div>
                          <div class="row">
                        <div class="form-group col-md-12">
                                    <label for="comment">Address:</label>
                                    <textarea class="form-control" rows="2" id="comment" name="address"></textarea>
                                  </div>
                        </div>
                    
                                    
                                    <button type="submit" class="d-none float-right d-sm-inline-block btn btn-sm btn-primary shadow-sm" id="sendnou" style="display:none;">Create</button>  
 
       

        
                </form>




              </div>


              </div>


            </div>

          </div>
           
           
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
    <script>
$(document).ready(function (e) {
 $("#frm").on('submit',(function(e) {
  e.preventDefault();
  //var termc=$('#termandconditioncheckbox').attr('checked');
  //console.log('term and condition',termc);
  $.ajax({
    url: "ajax_adduser.php",
    type: "POST",
    data:  new FormData(this),
    contentType: false,
    cache: false,
    processData:false,
    beforeSend : function(){
    //$("#preview").fadeOut();
    console.log('before call');
    $("#err").fadeOut();
    },
    success: function(data){
      console.log('success call',data);
      data=data.trim(); 
      if(data=='1'){
        $("#err").hide();         
        $("#success").html("User Created Successfully!").fadeIn();  
          alert('User Created Successfully');       
          $("#frm")[0].reset();      
          document.location='list-user.php';          
      }
      else if(data =='2'){
         $("#success").hide();
         $("#err").html('User Add Successfully').fadeIn();  
          alert('User Add Successfully');  
      }else if(data =='3'){
         $("#success").hide();
         $("#err").html('User Already exist please use different').fadeIn();  
          alert('User Already exist please use different'); 
      }else if(data =='4'){
         $("#success").hide();
         $("#err").html('password and confirm password mismatch').fadeIn(); 
          alert('password and confirm password mismatch');  
      }else if(data =='5'){
         $("#success").hide();
         $("#err").html('required field missing please fill all requird fields').fadeIn();  
          alert('required field missing please fill all requird fields'); 
      }else if(data =='6'){
         $("#success").hide();
         $("#err").html('You Dont Have Enough Balance').fadeIn();
          alert('You Dont Have Enough Balance');      
      }else if(data =='11'){
        $("#notification").show();
         $("#success").hide();
         $("#err").html('invalid username, allow only alphanumeric without space, max 15 charcter').fadeIn(); 
      }else{
        $("#success").hide();         
        $("#err").html("Something went wrong. Please try again!").fadeIn(); 
         alert('Something went wrong. Please try again!');        
      }
     },
     error: function(e){
        console.log('error call');
        $("#err").html(e).fadeIn();
    }          
  });
 }));
});

</script>


  <!-- datetime picker -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.14/jquery.datetimepicker.full.js"></script>
<!-- end datatime-->



    <script>
        $('#datepicker').datetimepicker({
          minDate: 0,
          format:"Y-m-d",
            step:15
        });
		
		
function getFormfields(val) {
 	//alert(val); 
	if(val==3){
		$("#user").show();
	 
		$("#reseller").hide();
 	}else{
		
		$("#reseller").show();
		$("#user").hide();
	}
	 
}

function getDistrict(val) {
    $("#loader").show();
	//var cid=$("#client_id").val();
	//alert(val);
	$.ajax({
	type: "POST",
	url: "get_district.php",
	data:'pid='+val,
	success: function(data){
		$("#district").html(data);
		$("#loader").hide();
	}
	});
}

    </script>
    
    </body>
</html>