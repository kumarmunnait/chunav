<?php 
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$parent_id=$_SESSION['userid'];


//print_r($_POST);exit;
$user_id=$_POST['id'];
$credits=$_POST['credits'];
$newcredits=$_POST['newcredits'];
$remarks=$_POST['remarks'];
$created_date=date('Y-m-d H:i:s');
$usernewbalance=$credits+$newcredits;
 
if($newcredits <0){$add_detect='detected';}else{$add_detect='added';}
if(!empty($_SESSION['userid']) && $user_id!=='' && $credits!=='' && $newcredits!==''){
	if($usernewbalance>=0){
 		$ip=getRealIpAddr(0);
		$selcredit=$db->execute_query("select currency_credits from users where id=$parent_id");	
		$rowcredit=$selcredit->fetch_assoc();	 
		$parentcredits=$rowcredit['currency_credits'];
		if($parent_id==1 && $user_id==1){
			//update user credit
			$result=$db->update("update users set currency_credits='$usernewbalance' where id=$user_id");	
			//echo "Available";
			if($result){
				//insert in credit_history  table
				$insert=$db->insert("insert into credit_history(user_id,parent_id,amount,add_detect,remarks,created_date,ip) values('$user_id','$parent_id','$newcredits','$add_detect','$remarks','$created_date','$ip')");	
				echo 1;//"saved";
			}else{
				echo 2;// "Could not saved!";
			}	
		}else{
			if($parentcredits >=$newcredits){
				 
  				 $parentnewcredits=$parentcredits - $newcredits;
				  //update user credit
 			    $result=$db->update("update users set currency_credits='$usernewbalance' where id=$user_id");	
				//echo "Available";
				if($result){
					//update parent credit
					$db->update("update users set currency_credits='$parentnewcredits' where id=$parent_id");	
					//insert in credit_history  table
					$insert=$db->insert("insert into credit_history(user_id,parent_id,amount,add_detect,remarks,created_date,ip) values('$user_id','$parent_id','$newcredits','$add_detect','$remarks','$created_date','$ip')");	
					echo 1;//"saved";
				}else{
					echo 2;// "Could not saved!";
				}	
				
			}else{
			echo 4;//insufficent balance	
			}	
		}
		//$db->dbClose();
	}else{
		echo 5;//not allow in negative balance
	}
}else{
echo 3;	//required field missing please fill all requird fields
}
//for ip tracking
function getRealIpAddr($ip){
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    { 
     $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
	}else{
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}?>