<?php
include_once '../lib/session.php';
?>
<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Coupon Dashboard</title>
    <?php include_once '../inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->

            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">  Add Server   </h1> <a href="create-server-form" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">Add New</a>
             
            </div>

          <div class="row">

          

            <div class="col-lg-12">

              <!-- Dropdown Card Example -->
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Add New Server </h6>
                
                </div>
                <!-- Card Body -->
                <div id="form-create" class="card-body">
                      <!-- Card Header - Accordion -->
                <form action="/action_page.php">

                  <div class="form-group">
                    <label for="email">Name:</label>
                    <input type="text" class="form-control" id="email">
                  </div>

                   <div class="form-group">
                    <label for="email">Email address:</label>
                    <input type="text" class="form-control" id="email">
                  </div>

                   <div class="form-group">
                    <label for="email">Phone No:</label>
                    <input type="text" class="form-control" id="email">
                  </div>

                   <div class="form-group">
                    <label for="email">City:</label>
                    <input type="text" class="form-control" id="email">
                  </div>

                

                   <div class="form-group">
                   <div class="form-group">
  <label for="comment">Address:</label>
  <textarea class="form-control" rows="5" id="comment"></textarea>
</div>
                  </div>
 
      <a href="create-server-form" class="d-none float-right d-sm-inline-block btn btn-sm btn-primary shadow-sm">Save This Form</a>
                </form>




              </div>


              </div>


            </div>

          </div>
           
           
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
    
      </body>
    </html>