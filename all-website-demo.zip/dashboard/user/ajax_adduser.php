<?php  
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$User_id=$_SESSION['userid'];
$selgroup=$_POST['selgroup'];
//$master=$userid;
$active=1;
$expired_on=$_POST['expired_on'];
$txtname=$_POST['txtname'];
$login_for=1;
$username=trim($_POST['txtusername']);
$pass=trim($_POST['password']);
$currency=$_POST['currency'];
$amount=0.00; //$_POST['amount'];
$password=$pass;
$repassword=$password;//trim($_POST['repassword']);
$mobile=$_POST['mobile'];
$altmobile=$_POST['altmobile'];
$txtemail=$_POST['txtemail'];
$organization=$_POST['organization'];
$address=$_POST['address'];
$remark=$_POST['remark'];
// new fields added 

$pin=$_POST['pin'];
$state=$_POST['state'];
$district=$_POST['district'];
$acc_number=$_POST['acc_number'];
$acc_name=$_POST['acc_name'];
$bank_name=$_POST['bank_name'];
$ifsc=$_POST['ifsc'];
$aadhar=$_POST['aadhar'];
$industry=$_POST['industry'];
$business_type=$_POST['businesstype'];
$gst=$_POST['gst'];
$aadhar=$_POST['aadhar'];


$mobile_verify=0;
  


if(!empty($_SESSION['userid']) && $username!=='' && $currency!=='' && $amount!=='' && $selgroup!=='' && $pass!=='' && $repassword!=='' && $mobile!=='' && $txtemail!==''){
	if(preg_match('/^[a-zA-Z0-9]{4,15}$/',$username)){
		//echo "Available";
	}else{
		echo 11;exit;//"invalid username, allow only alphanumeric without space, max 15 charcter";
	}
	$query1="select username from users where username='$username'";
 	$sql=$db->execute_query($query1);		  						
	if($sql->num_rows>0){
		echo 3;//"User already exist";
	}else{
		if($pass==$repassword){	
		    $dt=date('Y-m-d:h:i:s');	
			 echo $query="insert into users(username,password,email,mobile,alernate_no,name,currency,master,profile_group_id,organization,expired_on,pin_code,state,district,industry,business_type,gst_no,acc_no,acc_name,acc_bank,acc_ifsc,aadhaar,remark,address,login_for,created_date,status) 

			 values 

			 ('$username','$password','$txtemail','$mobile','$altmobile','$txtname','$currency','$User_id','$selgroup','$organization','$expired_on','$pin','$state','$district','$industry','$business_type','$gst','$acc_number','$acc_name','$bank_name','$ifsc','$aadhar','$remark','$address','$login_for','$dt',1)";	 		  
			
			////echo $query to update user admin balance;
			 // exit();
			 //echo $query;
			 
			  $result=$db->insert($query);	
			 
			  $query2="insert into sender_id(user_id,sender_id_val,status,created_date)values('$User_id','TXTSMS','1','$dt')";
			  $insert_senderid=$db->insert($query2);	
				if($result){
					echo 1;
				//header('location:add.php');
				} else {
				echo 2;
				} 
		}else{
			echo 4;
		}
		
	} 	  						
	//dbClose($conn);
}else{
echo 5;	//required field missing please fill all requird fields
}
 
?>