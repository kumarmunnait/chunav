<?php  
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$User_id=$_SESSION['userid'];
$dt=date('Y-m-d h:i:s');
$payment_status=$_POST['payment_status'];
$payment_date=$_POST['payment_date'];
$user_type=$_POST['user_type'];
$user_master=$_POST['user_master'];
$id=$_POST['id']; 




$seluser=$db->execute_query("select * from users where id=$user_master");
$rowuser=$seluser->fetch_assoc();
$current_earning=$rowuser['total_earning'];

$master=$rowuser['master'];
$master_type=$rowuser['profile_group_id'];
$master_earning=$rowuser['comission'];
$total_earning=$master_earning+$current_earning;
if($master_type==2){
	
		
		$agent_earning=0;
 		$query_update="update users set total_earning='$total_earning' where id=$user_master";	
 	    $query_insert="insert into comission_history(earn_userid,earning,reg_userid,updated_balance,createdDate) values('$user_master','$master_earning','$id','$total_earning','$dt')";	
		////echo $query to update user admin balance;
		$result=$db->update($query_update);	
		$result_insert=$db->insert($query_insert);	
 }else if($master_type==4){
		$sel_agent_master=$db->execute_query("select * from users where id=$master");
		$row_agent_master=$sel_agent_master->fetch_assoc();
		$agent_master_type=$row_agent_master['profile_group_id'];
		$agent_master=$row_agent_master['master'];
		
		$agent_master_earning=$row_agent_master['total_earning'];
		if($agent_master_type==2){
				$master_comission=$row_agent_master['comission'];
				$agent_earning=$rowuser['comission'];
				$master_earning=$master_comission-$agent_earning;
				$total_master_earning=$agent_master_earning+$master_earning;
				
				$query_update1="update users set total_earning='$total_earning' where id=$user_master";
				$query_update2="update users set total_earning='$total_master_earning' where id=$master";
				
				$query_insert1="insert into comission_history(earn_userid,earning,reg_userid,updated_balance,createdDate) values('$user_master','$agent_earning','$id','$total_earning','$dt')";		
				$query_insert2="insert into comission_history(earn_userid,earning,reg_userid,updated_balance,createdDate) values('$master','$master_earning','$id','$total_master_earning','$dt')";	
				////echo $query to update user admin balance;
				$result=$db->update($query_update1);	
				$result_insert=$db->insert($query_insert1);
				
				$result=$db->update($query_update2);	
				$result_insert=$db->insert($query_insert2);	
  		}else if($agent_master_type==1){
 				$query_update="update users set total_earning='$total_earning' where id=$user_master";	
				$query_insert="insert into comission_history(earn_userid,earning,reg_userid,updated_balance,createdDate) values('$user_master','$master_earning','$id','$total_earning','$dt')";	
				////echo $query to update user admin balance;
				$result=$db->update($query_update);	
				$result_insert=$db->insert($query_insert);	
 		}
}
 

  
  
if(!empty($_SESSION['userid']) && $payment_status!=='' && $payment_date!=='' && $user_type==3){
  		       $dt=date('Y-m-d:h:i:s');	
			  $query="update users set payment_status='$payment_status',payment_date='$payment_date' where id=$id";		  
  			  ////echo $query to update user admin balance;
 			  $result=$db->update($query);	
 			 // $query2="insert into sender_id(user_id,sender_id_val,status,created_date)values('$User_id','TXTSMS','1','$dt')";
			 // $insert_senderid=$db->insert($query2);	
				if($result){
					echo 1;//"saved";
				//header('location:add.php');
  				}else{
					echo 2;// "Could not saved!";
				} 
     	$db->dbClose();
}else{
echo 5;	//required field missing please fill all requird fields
 
}
 
?>