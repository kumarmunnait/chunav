<?php  
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$User_id=$_SESSION['userid'];
$selgroup=$_POST['selgroup'];
 
$expired_on=$_POST['expired_on'];
$txtname=$_POST['txtname'];
$username=trim($_POST['txtusername']);
$pass=trim($_POST['password']);

$currency=$_POST['currency'];
$amount=0.00; //$_POST['amount'];
$password=$pass;
$id=$_POST['id']; 
$mobile=$_POST['mobile'];
$txtemail=$_POST['txtemail'];
$organization=$_POST['organization'];
$comission=$_POST['comission'];
$isotp=$_POST['isotp'];
$address=$_POST['address'];
$remark=$_POST['remark'];
$mobile_verify=0;
  
if(!empty($_SESSION['userid']) && $username!=='' && $currency!=='' && $selgroup!=='' && $mobile!=='' && $txtemail!==''){
  		    $dt=date('Y-m-d:h:i:s');	
			$query="update users set profile_group_id='$selgroup',
								email='$txtemail',
								mobile='$mobile',
								name='$txtname',
								comission='$comission',
 								organization='$organization',
  								expired_on='$expired_on',
 								isotp='$isotp',
								address='$address',
								remark='$remark',
								password='$password'
 								where id=$id";		  
			
			////echo $query to update user admin balance;
			 // exit();
			  $result=$db->update($query);	
			 
			 // $query2="insert into sender_id(user_id,sender_id_val,status,created_date)values('$User_id','TXTSMS','1','$dt')";
			 // $insert_senderid=$db->insert($query2);	
				if($result){
				echo 1;//"saved";
				//header('location:add.php');
				}else{
				echo 2;// "Could not saved!";
				} 
 		
	 	  						
 	$db->dbClose();
}else{
echo 5;	//required field missing please fill all requird fields
}
 
?>