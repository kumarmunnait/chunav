<?php

include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$User_id=$_SESSION['userid'];
$id=trim($_GET['id']);
 
$pid=trim($_REQUEST['pid']);
 
	?>
	<option value="">Select District</option>
	<?php	 
  	$q= "SELECT * FROM `district` WHERE `state_id`='$pid'";
	$rsMain =$db->execute_query($q);
 	while($row = $rsMain->fetch_array()){?>
	<option value="<?php echo $row["id"]; ?>"><?php echo $row["dist_name"]; ?></option>
	<?php }
$db->dbClose();
?>