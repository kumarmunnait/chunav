<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();

$id=isset($_GET['id']) ? $_GET['id']:'';
$seluser=$db->execute_query("select * from users where id=$id");
$rowuser=$seluser->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.css">
    <title>Edit User</title>
    <?php include_once '../inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->
             <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">Edit User</h1>  
             </div>
           <div class="row">
               <div class="col-lg-12">
               <!-- Dropdown Card Example -->
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Edit User Details </h6>
                
                </div>
                 <!-- Card Body -->
                <div style="background:#e74a3b14;" id="form-create" class="card-body">
                      <!-- Card Header - Accordion -->
                  <form  role="form" name="frm" id="frm" method="post">
                    <input type="hidden" name="id" value="<?php echo $rowuser['id']?>">
                  
                   <div class="row">
                    <div class="form-group col-md-6">
                    <label for="email">User Group:</label>
                    <select class="form-control" name="selgroup" id="selgroup" required>
                                        	<?php //$_SESSION['profile_group_id']=1;
											$query ="select * from user_profile_group where id!=1";
											   $grp_list = $db->execute_query($query);
 												echo "<option value=\"\">Select Group</option>";
													 while($rowgroup = $grp_list->fetch_array()):
 												 
														?><option value="<?php echo $rowgroup['id']?>" <?php if($rowuser['profile_group_id']==$rowgroup['id']){echo 'selected';}?>><?php echo $rowgroup['group_name']?></option>
														<?php  endwhile; 	 ?>
 			</select>
            
            </div>
             <div class="form-group col-md-6">
              <label for="email">Comission:</label>
             <input class="form-control" placeholder="Enter Comission" value="<?php echo $rowuser['comission']; ?>" name="comission" required>
             </div>
                  </div>
                  <div class="row">
                  <div class="form-group col-md-6">
                    <label for="email">Name:</label>
                      <input class="form-control" placeholder="Enter name" value="<?php echo $rowuser['name']; ?>" name="txtname" required>
                  </div>

                   <div class="form-group col-md-6">
                    <label for="email">Email address:</label>
                      <input class="form-control" placeholder="Email" value="<?php echo $rowuser['email']; ?>" name="txtemail" required>
                  </div>

                   <div class="form-group col-md-6">
                    <label for="email">Phone No:</label>
                     <input class="form-control" value="<?php echo $rowuser['mobile']; ?>" placeholder="Mobile" name="mobile" required>
                  </div>

                   <div class="form-group col-md-6">
                    <label for="email">User Name:</label>
                   <input class="form-control" placeholder="username" value="<?php echo $rowuser['username']; ?>" id="txtusername" name="txtusername" onFocus="$('#errormessage').html('').removeClass();"  onChange="checkuser();" required>
                  </div>
                 
                   <div class="form-group col-md-6">
                    <label for="email">Password:</label>
                  <input type="password" class="form-control" value="<?php echo $rowuser['password']; ?>" placeholder="password" id="password" name="password" onFocus="$('#errorpassword').html('');" required>
                  </div>
                  
                    <div class="form-group col-md-6">
                    <label for="email">Currency:</label>
                    <select class="form-control" name="currency" required>
                        <option value="">Select Currency</option>
                        <option value="INR" <?php if($rowuser['currency']=='INR'){echo 'selected';}?>>INR</option> 
                        <option value="EUR" <?php if($rowuser['currency']=='EUR'){echo 'selected';}?>>EURO</option> 
                        <option value="USD" <?php if($rowuser['currency']=='USD'){echo 'selected';}?>>USD</option>                                          
                    </select>
                  </div>
                 
                  <div class="form-group col-md-6">
                    <label for="email">Organisation:</label>
                  <input type="text" class="form-control" value="<?php echo $rowuser['organization']; ?>" placeholder="Organisation" name="organization">
                  </div>
                  <div class="form-group col-md-6">
                    <label for="email">Expired On:</label>
                    <input class="form-control" id="datepicker" autocomplete="off" value="<?php echo $rowuser['expired_on'];  ?>" placeholder="YYYY-mm-dd" name="expired_on" required>
                  </div>
                  
                  
             
                  
                   
                   <div class="form-group col-md-6">
                    <label for="email">Auth Key</label>
                  <input type="text" class="form-control" value="<?php echo $rowuser['authkey']; ?>" placeholder="authkey" name="authkey" disabled>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="email">OTP</label>
                    <select class="form-control" name="isotp" required>
                        <option value="">Select OTP Verify</option>
                        <option value="0" <?php if($rowuser['isOtp']=='0'){echo 'selected';}?>>NO</option> 
                        <option value="1" <?php if($rowuser['isOtp']=='1'){echo 'selected';}?>>YES</option> 
                                                                  
                    </select>
                  </div>
                  
                  
                    
                   <div class="form-group col-md-6">
  <label for="comment">Address:</label>
  <textarea class="form-control" rows="5" id="comment" name="address"><?php echo $rowuser['address']; ?></textarea>
</div>

 <div class="form-group col-md-6">
  <label for="comment">Remark:</label>
  <textarea class="form-control" rows="5" id="comment" name="remark"><?php echo $rowuser['remark']; ?></textarea>
</div>
                  </div>    
 
          <button type="submit" class="d-none float-right d-sm-inline-block btn btn-sm btn-primary shadow-sm" id="sendnou">Update</button>

        
                </form>




              </div>


              </div>


            </div>

          </div>
           







<div class="card shadow mb-4">
    <!-- Card Header - Dropdown -->
     <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
      <h6 class="m-0 font-weight-bold text-primary">SMS and Voice Price</h6>
    
    </div>

        <div id="form-create" class="card-body">     
         <div class="panel-body">
      
      <form  role="form" name="frm_price" id="frm_price" method="post">
                    <input type="hidden" name="id" value="<?php echo $rowuser['id']?>">
      		<div class="row">
      		       <div class="form-group col-md-6">
                    <label for="email">Current SMS Price:</label>
                  <input type="text" class="form-control" value="<?php echo $rowuser['sms_price']; ?>" placeholder="SMS Price" name="sms_price">
                  </div>
                  <div class="form-group col-md-6">
                    
                  </div>
              </div>
              
              <div class="row">
      		       <div class="form-group col-md-6">
                    <label for="email">Voice Pulse</label>
                 <select class="form-control" name="pulse" required>
                        <option value="">Select Pulse</option>
                        <option value="15" <?php if($rowuser['voice_pulse']=='15'){echo 'selected';}?>>15</option> 
                        <option value="30" <?php if($rowuser['voice_pulse']=='30'){echo 'selected';}?>>30</option> 
                          <option value="60" <?php if($rowuser['voice_pulse']=='60'){echo 'selected';}?>>60</option> 
                                                                  
                    </select>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="email">Current Voice Price:</label>
                    <input class="form-control" autocomplete="off" value="<?php echo $rowuser['voice_price'];  ?>" placeholder="Voice Price" name="voice_price" required>
                  </div>
              </div>
               <button type="submit" class="d-none float-right d-sm-inline-block btn btn-sm btn-primary shadow-sm" id="sendnou">Update Price</button>
        </form>


         </div>
                 
	   </div>        		
                           
</div>
 
 
 
 
 <div class="card shadow mb-4">
    <!-- Card Header - Dropdown -->
     <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
      <h6 class="m-0 font-weight-bold text-primary">Payment Status</h6>
    
    </div>

        <div id="form-create" class="card-body">     
         <div class="panel-body">
      
      <form  role="form" name="frm_payment" id="frm_payment" method="post">
                    <input type="hidden" name="id" value="<?php echo $rowuser['id']?>">
                    <input type="hidden" name="user_master" value="<?php echo $rowuser['master']?>">
                     <input type="hidden" name="user_type" value="<?php echo $rowuser['profile_group_id']?>">
      		 
              
              <div class="row">
      		       <div class="form-group col-md-6">
                    <label for="email">Payment Status</label>
                 <select class="form-control" name="payment_status" required>
                        <option value="">Payment Status</option>
                        <option value="0" <?php if($rowuser['payment_status']==0){echo 'selected';}?>>Payment Pending</option> 
                        <option value="1" <?php if($rowuser['payment_status']==1){echo 'selected';}?>>Payment Done</option> 
                           
                                                                  
                    </select>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="email">Payment Date:</label>
                    <input class="form-control" id="datepicker1" autocomplete="off" value="<?php echo $rowuser['payment_date'];  ?>" placeholder="YYYY-mm-dd" name="payment_date" required>
                  </div>
              </div>
               <button type="submit" class="d-none float-right d-sm-inline-block btn btn-sm btn-primary shadow-sm" id="sendnou">Update Payment</button>
        </form>


         </div>
                 
	   </div>        		
                           
</div>








           
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
    <script>
$(document).ready(function (e) {
 $("#frm").on('submit',(function(e) {
	e.preventDefault();
	//var termc=$('#termandconditioncheckbox').attr('checked');
	//console.log('term and condition',termc);
	$.ajax({
		url: "ajax_edituser.php",
		type: "POST",
		data:  new FormData(this),
		contentType: false,
		cache: false,
		processData:false,
		beforeSend : function(){
		//$("#preview").fadeOut();
		console.log('before call');
		$("#err").fadeOut();
		},
		success: function(data){
			console.log('success call',data);
			data=data.trim();	
			if(data=='1'){
			  $("#err").hide();				  
			  $("#success").html("User Updated Successfully!").fadeIn();	
			    alert('User Updated Successfully!');				
			    $("#frm")[0].reset(); 		 
			    document.location='list-user.php'; 					
			}
			else if(data =='2'){
				 $("#success").hide();
				 $("#err").html('Something went wrong. Please try again!').fadeIn();	
				  alert('Something went wrong. Please try again');	
			}else if(data =='3'){
				 $("#success").hide();
				 $("#err").html('User Already exist please use different').fadeIn();	
				  alert('User Already exist please use different');	
			}else if(data =='4'){
				 $("#success").hide();
				 $("#err").html('password and confirm password mismatch').fadeIn();	
				  alert('password and confirm password mismatch');	
			}else if(data =='5'){
				 $("#success").hide();
				 $("#err").html('required field missing please fill all requird fields').fadeIn();	
				  alert('required field missing please fill all requird fields');	
			}else if(data =='6'){
				 $("#success").hide();
				 $("#err").html('You Dont Have Enough Balance').fadeIn();
				  alert('You Dont Have Enough Balance');			
			}else if(data =='11'){
				$("#notification").show();
				 $("#success").hide();
				 $("#err").html('invalid username, allow only alphanumeric without space, max 15 charcter').fadeIn();	
			}else{
			  $("#success").hide();				  
			  $("#err").html("Something went wrong. Please try again!").fadeIn();	
			   alert('Something went wrong. Please try again!');				
			}
		 },
		 error: function(e){
			  console.log('error call');
				$("#err").html(e).fadeIn();
		}          
	});
 }));
});


$(document).ready(function (e) {
 $("#frm_price").on('submit',(function(e) {
	e.preventDefault();
	//var termc=$('#termandconditioncheckbox').attr('checked');
	//console.log('term and condition',termc);
	$.ajax({
		url: "ajax_editprice.php",
		type: "POST",
		data:  new FormData(this),
		contentType: false,
		cache: false,
		processData:false,
		beforeSend : function(){
		//$("#preview").fadeOut();
		console.log('before call');
		$("#err").fadeOut();
		},
		success: function(data){
			console.log('success call',data);
			data=data.trim();	
			if(data=='1'){
			  $("#err").hide();				  
 			    alert('Price Updated Successfully!');				
			    $("#frm_price")[0].reset(); 		 
			    document.location='list-user.php'; 					
			}
			else if(data =='2'){
				 $("#success").hide();
				 $("#err").html('Something went wrong. Please try again!').fadeIn();	
				  alert('Something went wrong. Please try again');	
			}else if(data =='3'){
				 $("#success").hide();
				 $("#err").html('User Already exist please use different').fadeIn();	
				  alert('User Already exist please use different');	
			}else if(data =='4'){
				 $("#success").hide();
				 $("#err").html('password and confirm password mismatch').fadeIn();	
				  alert('password and confirm password mismatch');	
			}else if(data =='5'){
				 $("#success").hide();
				 $("#err").html('required field missing please fill all requird fields').fadeIn();	
				  alert('required field missing please fill all requird fields');	
			}else if(data =='6'){
				 $("#success").hide();
				 $("#err").html('You Dont Have Enough Balance').fadeIn();
				  alert('You Dont Have Enough Balance');			
			}else if(data =='11'){
				$("#notification").show();
				 $("#success").hide();
				 $("#err").html('invalid username, allow only alphanumeric without space, max 15 charcter').fadeIn();	
			}else{
			  $("#success").hide();				  
			  $("#err").html("Something went wrong. Please try again!").fadeIn();	
			   alert('Something went wrong. Please try again!');				
			}
		 },
		 error: function(e){
			  console.log('error call');
				$("#err").html(e).fadeIn();
		}          
	});
 }));
});


$(document).ready(function (e) {
 $("#frm_payment").on('submit',(function(e) {
	e.preventDefault();
	//var termc=$('#termandconditioncheckbox').attr('checked');
	//console.log('term and condition',termc);
	$.ajax({
		url: "ajax_editpayment.php",
		type: "POST",
		data:  new FormData(this),
		contentType: false,
		cache: false,
		processData:false,
		beforeSend : function(){
		//$("#preview").fadeOut();
		console.log('before call');
		$("#err").fadeOut();
		},
		success: function(data){
			console.log('success call',data);
			data=data.trim();	
			if(data==1){
			  $("#err").hide();				  
 			    alert('Payment Updated Successfully!');				
			    $("#frm_payment")[0].reset(); 		 
			    document.location='list-user.php'; 					
			}
			else if(data =='2'){
				 $("#success").hide();
				 $("#err").html('Something went wrong. Please try again!').fadeIn();	
				  alert('Something went wrong. Please try again');	
			}else if(data =='3'){
				 $("#success").hide();
				 $("#err").html('User Already exist please use different').fadeIn();	
				  alert('User Already exist please use different');	
			}else if(data =='4'){
				 $("#success").hide();
				 $("#err").html('password and confirm password mismatch').fadeIn();	
				  alert('password and confirm password mismatch');	
			}else if(data =='5'){
				 $("#success").hide();
				 $("#err").html('required field missing please fill all requird fields').fadeIn();	
				  alert('required field missing please fill all requird fields');	
			}else if(data =='6'){
				 $("#success").hide();
				 $("#err").html('You Dont Have Enough Balance').fadeIn();
				  alert('You Dont Have Enough Balance');			
			}else if(data =='11'){
				$("#notification").show();
				 $("#success").hide();
				 $("#err").html('invalid username, allow only alphanumeric without space, max 15 charcter').fadeIn();	
			}else{
			  $("#success").hide();				  
			  $("#err").html("Something went wrong. Please try again!").fadeIn();	
			   alert('Something went wrong. Please try again!');				
			}
		 },
		 error: function(e){
			  console.log('error call');
				$("#err").html(e).fadeIn();
		}          
	});
 }));
});

function checkuser(){
	var user=$('#txtusername').val();
	console.log('user',user);
	//$("#errormessage").html('User already exist');
	$.post("ajax_checkuser.php",{ user:''+user+'',rand:Math.random() } ,function(data){
          var data=data.trim();
          console.log(data);
          if(data=='Available') //if correct login detail
          {
              $("#errormessage").html('Available').addClass('alert-success');
          }
          else{
            $("#errormessage").html(data).addClass('alert-danger');    
          }
                
        });
        return false; //not to post the  form physically
 
}
function checkcpassword(){
	if($('#password').val()!=$('#repassword').val()) //if correct login detail
	{
	  $("#errorpassword").html('Password and confirm password mismatch').addClass('alert-danger');
	}
	
}
</script>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/3.2/select2.min.js"></script>
    <!-- datetime picker -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.14/jquery.datetimepicker.full.js"></script>
    <!-- end datatime-->
    <script>
	/*
	   $( function() {
    	$( "#datepicker" ).datepicker({minDate: 0});
		
 		} );*/
     $("#selectgroup").select2();
	   $(".select2-input").css('width','150px');
	 
		
		$('#datepicker').datetimepicker({
			minDate: 0,
  			//format:"Y-m-d h:i a",
			format:"Y-m-d",
  			step:15
		});
		
		
			$('#datepicker1').datetimepicker({
			minDate: 0,
  			//format:"Y-m-d h:i a",
			format:"Y-m-d",
  			step:15
		});
		
		
    $('#seltype').change(function(){ // click to
              var type=$("#seltype").val();
			 
			  if(type==1)
			  {
				  // alert(type);
				//  $("#dnd").attr('disabled',true);
				//$("#dnd").attr('checked', true);
				
				$('input[name=dnd]').prop("checked", true);
 				$("#dnd1").hide();
				  
			  }else{
			 	// $("#dnd").removeAttr('disabled');
				$("#dnd1").show();
				 //$("#dnd").attr('checked', false);
 			    $('input[name=dnd]').prop("checked", false);
			  }
 });	
 
 
 $('#selroute').change(function(){ // click to
              var type=$("#selroute").val();
			 
			  if(type==14 || type==15)
			  {
				  // alert(type);
				//  $("#dnd").attr('disabled',true);
				//$("#dnd").attr('checked', true);
   				$("#dnd_route").show();
				  
			  }else{
			 	// $("#dnd").removeAttr('disabled');
				$("#dnd_route").hide();
				 //$("#dnd").attr('checked', false);
 			  }
 });		
		
		</script>
    
      </body>
    </html>