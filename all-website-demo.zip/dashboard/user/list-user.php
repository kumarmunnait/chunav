<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
error_reporting(0);
$db = new database();
$User_id=$_SESSION['userid'];
$profile_group_id=$_SESSION['profile_group_id'];
  
?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>List User</title>
    <?php include_once '../inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
    <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->

            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">List Users</h1>
               
            </div>
               <div class="row">
              <!-- DataTales Example -->
              <div class="col-md-12" >
                <div class="card shadow mb-4">

                   <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">List of Users</h6>
                  </div>


                   <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <?php 
						  if($profile_group_id==1){$query="select u.id,u.username,u.name,u.email,u.password,u.mobile,u.comission,u.total_earning,u.master,u.currency_credits,u.currency,u.status,ug.group_name,u.created_date from users u,user_profile_group ug where ug.id=u.profile_group_id and u.id!=1 order by u.id desc"; 
						  }elseif($profile_group_id==2 or $profile_group_id==4){ 
						  $query="select u.id,u.username,u.name,u.email,u.password,u.mobile,u.master,u.comission,u.total_earning,u.currency_credits,u.currency,u.status,ug.group_name,u.created_date from users u,user_profile_group ug where ug.id=u.profile_group_id and master='$User_id' and u.id!=1 order by u.id desc";  
						  }  
						
 						$selectsqll=$db->execute_query($query);							
						//dbClose($conn);							
						?>                          
                            <thead>
                            <tr>
                                <th>UID</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Mobile</th>
                                <th>Credits</th>
                                <th>Parent</th>
                                <th>Comission</th>
                                <th>Earning</th>
                                <th>Payment Status</th>
                                <th>Created On</th>
                                <th>Action</th>
                            </tr>

                             <tfoot>
                              <tr>
                                <th>UID</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Mobile</th>
                                <th>Credits</th>
                                <th>Parent</th>
                                <th>Comission</th>
                                <th>Earning</th>
                                <th>Payment Status</th>
                                <th>Created On</th>
                                <th>Action</th>
                            </tr>
                             </tfoot>
                            </thead>
                            <tbody>
							<?php $i=1; 
							//for all parent user array
							$query2="SELECT id,username FROM `users` WHERE profile_group_id in(1,2,4)";
							$sel_parent_name=$db->execute_query($query2);
							$parentarr=array();
							while($row_pname = $sel_parent_name->fetch_array()){
								$parentarr[$row_pname['id']]=$row_pname['username'];
							}
							 
							while($row = $selectsqll->fetch_array()){
                            // echo $row['master'];
							$master=$row['master'];
							if(isset($parentarr[$master])){
								$pusername=$parentarr[$master];
							}else{
								$pusername='';	
							}
							
					 if($row['status']==0){$statusstr='../img/inactive.png'; $class='gradeA disable';}else{$statusstr='../img/active.png'; $class='gradeA';}            
                            //  dbClose($conn);	
                            ?>
                            <tr class="<?= $class?>">
                                <td><?= $i?></td>
                                <td> <a href="edit.php?id=<?php echo $row['id'];?>" ><?= $row['username']?></a></td>
                                <?php if($row['id']==1){echo "<td></td>";}else{?>
                                <td style="cursor:pointer" id="tdr<?= $row['id']?>" onClick="toggle('tdr<?= $row['id']?>','<?= $row['password']?>')">getPassword</td>
                                <?php }?>
                                <td style="cursor:pointer;min-width:130px;" id="tdrc<?= $row['id']?>" onClick="togglecontact('tdrc<?= $row['id']?>','<?= $row['mobile']?> <br><?= $row['email']?>')">getContact</td>
                                 <td nowrap><?php echo $row['currency'].' '.number_format($row['currency_credits'],2)?></td>
                                <td><?php echo $pusername.'('.$row['group_name'].')';?> </td>
                               
                                 <td><?php echo $row['comission']; ?> </td>
                                  <td><?php echo $row['total_earning']; ?> </td>
                                <td><?php  $payment_status=$row['payment_status'];
								if($payment_status==1){ echo "<span class='green'>Payment Done</span>"; }else{
								  echo "<span class='red'>Payment Pending</span>";	
								}
								?></td>
                                 <td nowrap><?php echo $row['created_date']; ?></td>
                                <td class="d-flex justify-content-center justify-content-between ">   
                                <a href="edit_user.php?id=<?php echo $row['id'];?>" ><i class="fa fa-edit" title="Edit"></i></a>                                   
                                <span class="linkp" title="Enable/Disable" id="enadis<?= $row['id']?>" onClick="change_status(<?= $row['id']?>);"> <i class="green fa fa-circle"></i> </span>
                                <?php if($profile_group_id==1){?>
                                  <a href="addbalance.php?id=<?php echo $row['id'];?>"> <i class="hvr-buzz-out fa fa-cart-plus" title="Add/Delete Balance"></i></a> <?php }elseif($row['master']==$User_id){ ?>
                                  <a href="addbalance.php?id=<?php echo $row['id'];?>"> <i class="hvr-buzz-out fa fa-credit-card" title="Add/Delete Balance"></i></a> <?php  } ?>  
                                </td>
                            </tr>
                            <?php $i++; }  ?>
                            </tbody>
                        </table>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.container-fluid -->
            </div>
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
        
<script>
 
	
function toggle(id,pass){
	if($('#'+id+'').html()=='getPassword'){
		$('#'+id+'').html(pass);
	}else{
		$('#'+id+'').html('getPassword');
	}
}

function togglecontact(id,pass){
	if($('#'+id+'').html()=='getContact'){
		$('#'+id+'').html(pass);
	}else{
		$('#'+id+'').html('getContact');
	}
}
	
  
function change_status(id){ 
	var rowid='#enadis'+id;
	var isrc=$('#enadis'+id+' img').attr('src');
	console.log(isrc);
	if(isrc=='../template/assets/dist/img/inactive.png'){
	var status='Enable';
	}else{
	var status='Disable';	
	}
	//var status=$(rowid).html();
	var res = confirm('Are sure want to '+status);
	
	if(res==true){ 
		$.ajax({
			url: "ajax_deluser.php?id="+id+"&status="+status,
			type: 'POST',
			
			beforeSend: function() {				 
			},
			success: function(data, t666666extStatus, xhr) {
				//var data=0;
				if(data==1){var classstr='gradeA';var statusstr='../template/assets/dist/img/active.png';}else{var classstr='gradeA disable';var statusstr='../template/assets/dist/img/inactive.png';}
				$( "#r"+id ).attr('class',''+classstr+'');
				//$(rowid).html(''+statusstr+'');
				$('#enadis'+id+' img').attr('src',statusstr);
			},
			error: function(xhr, textStatus, errorThrown) {					
			
			}
		});			
	}else{
		return false;
	}
				
}
</script>
    
      </body>
    </html>