
<script type="text/javascript">
    $(document).ready(function(){
      $("#chnagePassword").submit(function(){

        $.ajax({
      url: "ajax/change_password.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
      cache: false,
      processData:false,
      beforeSend : function(){
      //$("#preview").fadeOut();
      console.log('before call');
      $("#err").fadeOut();
       $('#loader').show();
      }, complete: function(){
        $('#loader').hide();
        },
      success: function(data){
        $("#send_sms").removeAttr("disabled");
        console.log('success call',data); 
           if(data==1){
         // view uploaded file.        
          $("#err").hide();     
          console.log('insert  call',data);     
          $("#success").html("Saved!").fadeIn();        
          //$("#loadtable").load('loadUploadNumaber.php');    
           alert(data);
           $('#preview-count').text('0');
           $('#wcount').text(0);
             $('#msg').text(0);
          // window.location.reload();     
         $("#frm")[0].reset(); 
         $("#reply_msg").hide();
         $('#selectgroup').val('').trigger("change");
         $("#modal-lg .close").click();
         $("#languageDropDown").hide();
        }
       },
       error: function(e){
         $("#send_sms").removeAttr("disabled");
          console.log('error call');
          $("#err").html(e).fadeIn();
      }          
    });

    
       });
       });
</script>
