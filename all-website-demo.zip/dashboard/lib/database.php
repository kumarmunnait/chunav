<?php 



class database {

	public $host =DB_SERVER;
	public $user =DB_USERNAME;
	public $password =DB_PASSWORD;
	public $db_name =DB_DATABASE;

	public $link;
	public $error;

	public function __construct(){
		$this->connect();
	}

	private function connect() {

		$this->link = new mysqli($this->host,$this->user,$this->password,$this->db_name);

		if(!$this->link){
			$this->error ="coonection Faild".$this->link->connect_error;
		}



	}
	
	public function dbClose(){
 		$this->link->close();
 	}


   

	public function create_table ($query) {
		$result = $this->link->query($query);
		if($result){
			return true;
		}
		else{
			return false;
		}
	}

	public function execute_query ($query) {
		$result = $this->link->query($query) or die($this->link->error);
		if($result){
			return $result;
		}
		else{
			return false;
		}
	}
	public function execute_options ($query) {
		$result = $this->link->options($query, "/opt/bitnami/mysql/my.cnf") or die($this->link->error);
		if($result){
			return $result;
		}
		else{
			return false;
		}
	}
	public function getlast_insertid() {
		$last_id = $this->link->insert_id;
 		return $last_id;
 	}
 
 	public function insert ($query) {
		$result = $this->link->query($query);
		if($result){
			return "Record Inserted";
		}
		else{
			return false;
		}
	}

    public function update($query) {
		$result = $this->link->query($query);
		if($result){
			return "Record Updated";
		}
		else{
			return false;
		}
	}


}


?>