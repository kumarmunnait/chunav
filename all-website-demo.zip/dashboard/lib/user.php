<?php 



class user extends database{


}


?>