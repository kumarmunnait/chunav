<?php
date_default_timezone_set("Asia/kolkata");
session_start();
if (!isset($_SESSION['userid'])) {
  header("location: index.php");
}

?>