<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
$User_id=$_SESSION['userid'];
$query ="select * from tags where tags_user_id=$User_id order by id DESC";
$tag_name = $db->execute_query($query);

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Create Tags </title>
    <?php include_once '../inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->

            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800"> Tags   </h1> 
            
            </div>

            <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Creaet New Tags </h6>
                  
                     <a href="#"><button  class="btn btn-primary btn-sm btn-user">Set Into Form</button></a>  
                   
                  </div>

                

                
                    <div class="card-body">

                        <div style="display: none;" id="status" class="alert" role="alert">
                     <span id="statusText"></span>
                    </div>

                  <form id="createtags"  action="" method="post">

                    <div class="row">
                        <div class="form-group col-md-4">
                          <label>Tag Name</label>
                          <input type="text" class="form-control" id="tag-name" placeholder="Enter Tag Name" required>
                        </div>
                        <div class="form-group col-md-4">
                          <label>Choose Tag Colour</label>
                          <input type="color" class="form-control" id="tag-color" placeholder="Enter Tag Name" required  >
                        </div>
                           <div class="form-group col-md-4">
                             <label></label>
                         <input type="submit" name="submit" value="Create Tags" onclick="tagevent(1);" class="btn btn-block btn-primary btn-user">

                        </div>

                        </div>
                        <hr>

                      </form>
                 
                
                </div>

       <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                          <h6 class="m-0 font-weight-bold text-primary">All Tag's List </h6>
                         
                        </div>
        <div class="card-body">
   

     <div class="tag-system table-responsive">
                        <table class="table table-bordered" id="tagList" width="100%" cellspacing="0">

                            <thead>
                            <tr>
                                <th>S.N</th>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>


                             <?php
                    if($tag_name== false) {
                       echo "<div class='text-center alert alert-danger'> No Trags </div>";
                      }
                      else{

                  while($row = $tag_name->fetch_array()): ?>

                            <tr>
                              <td> <?php echo $row['id'];?></td>
                              <td> <button style="background:<?php echo $row['tag_color'];?>;" class="btn btn-name btn-sm"><?php echo $row['tag_name'];?></button> </td>
                              <td>
                                <?php 
                                if($row['tag_status']==1){
                                  echo '<span class="label label-active"> <a href="#" class="btn btn-success btn-circle btn-sm">
                    <i class="fas fa-check"></i>
                  </a> active </span>';
                                }else{
                                   echo '<span class="label label-inactive">Inactive <a href="#" class="btn btn-secondary btn-circle btn-sm">
                    <i class="fas fa-trash"></i>
                  </a> </span>';
                                }

                                ?>
                                  
                               </td>
                              <td class="something">


                                   <a href="#" class="btn btn-warning  btn-circle btn-sm">
                                     <i class="fas fa-edit"></i>
                                </a>

                                <a href="#" class="btn btn-danger btn-circle btn-sm">
                                     <i class="fas fa-trash"></i>
                                </a>


     
                            </tr>

                    <?php endwhile; } ?>

                            <tbody>


</table>

              </div>
           
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
          

<script type="text/javascript">



function tagevent(x){

  if(x==1){
        var inputVal = document.getElementById("tag-name").value;
         if(inputVal==""){
         var status = document.getElementById('status');
         status.style.display = "block";
         var statusText = document.getElementById('statusText');
         status.classList.add("alert-danger");
         statusText.innerHTML = "Please Enter Tag Name";
          return false;
        }else{
          set(x);
        }


  }else if(x==2){
         var dataId = $(elem).data("id");
    alert(dataId);
    exit();
    set(x);
  }


}

       function set(x){
        $.post("ajax-create-tags.php",{ 
          tag_name:$('#tag-name').val(),
          tag_color:$('#tag-color').val(),
          req_id:x
          },
          function(data){
          console.log('data=',data);
          if(data==1){
          var status = document.getElementById('status');
                 status.style.display = "block";
                 var statusText = document.getElementById('statusText');
                 status.classList.add("alert-success");
                 statusText.innerHTML = "Your tag has been created successfully";
                  $("#createtags")[0].reset(); 
                   document.location='create-tag';
           }
           else if(data==2) {
                 var status = document.getElementById('status');
                 status.style.display = "block";
                 var statusText = document.getElementById('statusText');
                 status.classList.add("alert-danger");
                 statusText.innerHTML = "Tag already created, Use different name";
                 $("#createtags")[0].reset(); 
           }
           else {
            var status = document.getElementById('status');
            status.style.display = "block";
                 var statusText = document.getElementById('statusText');
                 status.classList.add("alert-success");
                 statusText.innerHTML = "Your tag has been created successfully";
                 $("#createtags")[0].reset(); 
             
           }
                
        });

     
   return x;

 }




</script>



<!-- <script type="text/javascript">
    $(document).ready(function(){

      $(".delete_tag").click(function(){
         confirm("Do You Want To Delete Tag");
      });

    });

</script> -->

    <script type="text/javascript">
      $(document).ready(function() {
       $('#tagList').DataTable({
          "order": [[ 0, "desc" ]],
           responsive: true
       });
   });
    </script>




      </body>
    </html>