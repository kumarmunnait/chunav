<?php 
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
$User_id=$_SESSION['userid'];
$reqid=$_POST['req_id'];

echo $reqid;


if($reqid==1){
	$tag_name=$_POST['tag_name'];
	$tag_color=$_POST['tag_color'];
	$query ="INSERT INTO tags (tag_name,tags_user_id,tag_color) VALUES ('$tag_name','$User_id','$tag_color')";
	$tagQuery  = $db->execute_query($query);
	if($tagQuery){
		echo 1;
	}else{
		echo 3;
	}
}
//  requet 1 
else if($reqid==2){

	$delete_tag=$_POST['delete_tag_red'];
	$tag_delete_query ="UPDATE tags SET  del_status='0' WHERE tags_user_id=$User_id and id=$delete_tag";
	$tagDeleted = $db->execute_query($tag_delete_query);
	if($tagDeleted){
		echo 3;
	}else{
		echo 4;
	}
}


?>