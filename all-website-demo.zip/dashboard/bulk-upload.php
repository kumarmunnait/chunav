<?php
include_once 'lib/session.php';
include_once 'lib/database.php';
include_once 'lib/db_config.php';
$db = new database();
$User_id=$_SESSION['userid'];
$query ="select * from tbl_forms where user_id=$User_id order by id DESC";
$form_list = $db->execute_query($query);
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Coupon Dashboard</title>
    <?php include_once 'inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once 'inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once 'inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->

            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800"> Bulk Upload Data  </h1> 
            
            </div>

            <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary"> Select One Form List: </h6>
                    <form id="exportdata" action="" method="post">
                     <button  class="btn btn-primary btn-sm btn-user"><i class="fas fa-download fa-sm text-white-50"></i> Download CSV Formate</button>  
                     </form>
                  </div>

                  <div class="card-body">

                     <?php

                 if($form_list== false) {
                       echo "<div class='text-center alert alert-danger'> No Record </div>";
                      }
                      else {
                        
                     
                      ?>
                        <div class="form-group">
                    <select class="form-control" name="selgroup" id="selgroup" required="">
                       <option value="">Select Form </option>

                       <?php
                               
                      while($row = $form_list->fetch_array()): ?>
                      <option value=""><?php echo $row['name'];?></option>
                      <?php endwhile;  } ?>    

                    </select>
                  </div>

                      


                </div>


              </div>


            <div class="row">
              <div id="importFrm" class="col-lg-12">
                <!-- Overflow Hidden -->
                <div class="card shadow mb-4">
                  <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"> Select CSV File  </h6>

                  </div>
                  <div class="card-body">
                    <!-- CSV file upload form -->
                  
                      <form action="importData.php" method="post" enctype="multipart/form-data">
                        <input type="file" name="file">
                        <input type="submit" class="btn btn-sm btn-info " name="importSubmit" value="IMPORT">
                      </form>
                 
                  </div>
                </div>
              </div>
              
            </div>
           
           
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once 'inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->


<script type="text/javascript">

    $(document).ready(function(){

    $("#exportdata").submit(function(){

    



    });

   });


</script>
    
      </body>
    </html>