<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();

  $User_id=$_SESSION['userid'];
  $form_id = base64_decode($_GET["id"]);
  $form_id_name = base64_decode($_GET["formid"]);
  $query ="select * from tbl_forms where user_id='$User_id' AND id='$form_id'";
  $formdata  = $db->execute_query($query);
  if($formdata) {
      $row = $formdata->fetch_assoc();
      $form_name = $row['name'];
      $form_html = $row['form_html'];
      $form_tabel_name = $row['form_table_name'];
      $form_fields = $row['form_fields'];
      $form_field= explode(",",$form_fields);
      $filed = count($form_field);
      $form_html = str_replace("Delete"," ", $form_html);
      $html = str_replace('contenteditable="true"'," ", $form_html);

 }
 

if(isset($_POST['senddata'])) {

  $query ="SELECT * FROM set_trigger where tigger_user_id='$User_id'";
  $checktrigger = $db->execute_query($query);

  if($checktrigger) {
      $row = $checktrigger->fetch_assoc();
	  $col=$row['form_option'];
	  $admin_mobile=$row['admin_mobile'];
	  $mobile =$_POST[$col];
      $get_triger_form_id = $row['form_id_for_trigger'];
      if($form_tabel_name == $form_id_name){

			//echo "trigger set";
			$msg=$row['trigger_message'];
			$message = urlencode($msg);
			$resetlink = SendResetLink($mobile,$message); 
			if(!empty($admin_mobile)){
				$admin_message=$row['admin_message'];
				$resetlink = SendResetLink($admin_mobile,$admin_message); 
				
				
			}
 
      }else{
        //echo "This Form Don't have any trigger";
      }

    }





 $form_post_data=""; 
 for($i=0;$i<$filed;$i++){
 $var ="'".$form_field[$i]."'";
      $form_post_data .= "'".$_POST[$form_field[$i]]."',";
  }
   $form_post_data=substr($form_post_data, 0, -1);
    //echo  print_r($form_field);
	
	//echo $_POST[$col];
	
	//exit();      
  // echo $mobile = $form_post_data['Phone'];

  
   $insert_form_data ="INSERT INTO $form_id_name ($form_fields)
  VALUES ($form_post_data);";


       $insert_form_data = $db->insert($insert_form_data);
      if($insert_form_data){
        echo "<script>alert('Record Inserted Successfully')</script>";
      } 
      else{
        echo "<script>alert('Error in Record Insertedd')</script>";
      }


  }



// send reset link 
function SendResetLink($mobile,$message_staff){
$sender ='ACCOTP';
$auth='D!~1988aJRF9l2ZcJ';
$hostUrl = 'https://global.datagenit.com/API/sms-api.php?auth='.$auth.'&msisdn='.$mobile.'&senderid='.$sender.'&message='.$message_staff.'';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $hostUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_POST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0); // change to 1 to verify cert
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
//curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
$resetlink = curl_exec($ch);
return $resetlink;
} 

// send reset link 



?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Coupon Form Dashboard</title>
    <?php include_once '../inc/style.php'; ?>
  </head>
<style type="text/css">
  .sub-option{
    display: none;
  }
  label.label-name:before {
    content: none;
}
</style>

  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->

            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800"> Form   </h1> <a href="my-form.php?uid=<?php echo base64_encode($User_id);?>&&fid=<?php echo base64_encode($form_id);?>&&fn=<?php echo base64_encode($form_id_name);?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">Share Form Link</a>
             
            </div>

          <div class="row">

          

            <div class="col-lg-12">

              <!-- Dropdown Card Example -->
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary"><?php echo $form_name  ;?></h6>
                
                </div>
                <!-- Card Body -->
                <div id="form-create" class="card-body">
                      <!-- Card Header - Accordion -->
                <form id="chunavform" action="" method="post" name="chunav">

                  <?php echo $html  ;?>



                  <input  class="btn btn-primary btn-user btn-block"  value="Submit" name="senddata" type="submit" name="">
 
      
                </form>




              </div>


              </div>


            </div>

          </div>
           
           
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
    
      </body>
    </html>