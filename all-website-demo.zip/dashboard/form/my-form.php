<?php
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
$User_id=base64_decode($_GET['uid']);
$form_id = base64_decode($_GET['fid']);
$form_id_name = base64_decode($_GET['fn']);
$query ="select * from tbl_forms where user_id='$User_id' AND id='$form_id'";
$formdata  = $db->execute_query($query);
if($formdata) {
    $row = $formdata->fetch_assoc();
    $form_name = $row['name'];
    $form_html = $row['form_html'];
    $form_tabel_name = $row['form_table_name'];
    $form_fields = $row['form_fields'];
    $form_field= explode(",",$form_fields);
    $filed = count($form_field);
    $form_html = str_replace("Delete"," ", $form_html);
    $html = str_replace('contenteditable="true"'," ", $form_html);

}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Coupon Form Dashboard</title>
    <?php include_once '../inc/style.php'; ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
<style type="text/css">
  .sub-option{
    display: none;
  }
  label.label-name:before {
    content: none;
}
.social:hover {
     -webkit-transform: scale(1.1);
     -moz-transform: scale(1.1);
     -o-transform: scale(1.1);
 }
 .social {
     -webkit-transform: scale(0.8);
     /* Browser Variations: */
     -moz-transform: scale(0.8);
     -o-transform: scale(0.8);
     -webkit-transition-duration: 0.5s;
     -moz-transition-duration: 0.5s;
     -o-transition-duration: 0.5s;
 }
 #social-fb:hover {
     color: #3B5998;
 }
 #social-tw:hover {
     color: #4099FF;
 }
 #social-gp:hover {
     color: #d34836;
 }
 #social-em:hover {
     color: #f39c12;
 }
</style>

  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-lg-8">
              <div class="text-center m-3">
               <img src="<?php echo $baseurl?>dashboard/img/logo-blue.png">
             </div>
              <!-- Dropdown Card Example -->
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary"><?php echo $form_name  ;?></h6>
                
                </div>
                <!-- Card Body -->
                <div id="form-create" class="card-body">
                      <!-- Card Header - Accordion -->
                <form id="myBaseform" action="" method="post" name="chunav">
                  <input type="hidden" id="custId" name="user_id" value="<?php echo $User_id ;?>">
                  <input type="hidden" id="custId" name="form_id" value="<?php echo $form_id; ?>">
                  <input type="hidden" id="custId" name="form_id_name" value="<?php echo $form_id_name; ?>">
                  <?php echo $html  ;?>
                  <input  class="btn btn-primary btn-user btn-block"  value="Submit" name="senddata" type="submit" name="">
                </form>
              </div>


              </div>

          <div class="">
                  <div class="text-center center-block">
            <p class="txt-railway">- Share On -</p>
                <a href="#"><i class="fa fa-facebook-square fa-3x social"></i></a>
              <a href="#"><i class="fa fa-twitter-square fa-3x social"></i></a>
              <a href="#"><i class="fab fa-whatsapp-square fa-3x social"></i></a>
              <a href="#"><i class="fa fa-linkedin-square fa-3x social"></i></a>
              <a href="#"><i class="fa fa-envelope-square fa-3x social"></i></a>
              <a href="#"><i class="fa fa-clipboard fa-3x social"></i></a>
            </div>
              </div>
            <div class="text-center m-5">
              <a href="" class="btn btn-sm btn-primary shadow-sm"><i class="fa fa-chrome" aria-hidden="true"></i> Create Form Short cut </a>
            </div>
            </div>
          </div>




 </div>
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
    

<script>
  $(document).ready(function (e) {
   $("#myBaseform").on('submit',(function(e) {
    e.preventDefault();
    $.ajax({
      url: "ajax_mybase_form.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
      cache: false,
      processData:false,
      beforeSend : function(){
      console.log('before call');
      $("#err").fadeOut();
      },
      success: function(data){
        console.log('success call',data);
        data=data.trim(); 
        if(data=='1'){
          $("#err").hide();         
          $("#success").html("User Created Successfully!").fadeIn();  
            alert('User Created Successfully');       
            $("#myBaseform")[0].reset();      
            document.location='thank-you';          
        }else{
          $("#success").hide();         
          $("#err").html("Something went wrong. Please try again!").fadeIn(); 
           alert('Something went wrong. Please try again!');        
        }
       },
       error: function(e){
          console.log('error call');
          $("#err").html(e).fadeIn();
      }          
    });
   }));
  });

</script>


       
      </body>
    </html>