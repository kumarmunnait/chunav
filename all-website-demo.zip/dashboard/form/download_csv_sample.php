<?php 
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
include_once '../lib/user.php';
$User_id=$_SESSION['userid'];
$form_id_name = base64_decode($_GET["tbl"]);
$db = new user();
$download="select * from $form_id_name limit 0";
$result = $db->execute_query($download);
$columns_total =  $result->field_count;
$contents='';

while ($fieldinfo = $result -> fetch_field()) {
    // echo $fieldinfo -> name;

     $contents .= '"'.$fieldinfo -> name.'",';

  }
$contents .="\n";
// Get Records from the table
while ($row = $result->fetch_array()) {
	//$contents.=implode(',',$row);
for ($i = 0; $i < $columns_total; $i++) {
$contents.='"'.$row["$i"].'",';
}
$contents.="\n";
}
// remove html and php tags etc.
$contents = strip_tags($contents); 
//echo $contents;
//header to make force download the file
ob_flush();
Header("Content-Disposition: attachment; filename=User-Data".date('d-m-Y').".csv");
print $contents;
//go to this link---http://studycopter.com/scripts/csvdownload.php
// go to this path on file zilla .../public_html/home/scripts/?>