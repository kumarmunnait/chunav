<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
$User_id=$_SESSION['userid'];
$form_id = base64_decode($_GET["id"]);
$form_id_name = base64_decode($_GET["formid"]);
$query ="select * from tbl_forms where user_id='$User_id' AND id='$form_id'";
$formdata  = $db->execute_query($query);
if($formdata) {
      $row = $formdata->fetch_assoc();
      $form_name = $row['name']; 
    $form_table_name = $row['form_table_name']; 
 }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Coupon Dashboard</title>
    <?php include_once '../inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->

            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800"> Bulk Upload Data  </h1> 
            
            </div>

            <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo $form_name  ;?> </h6>
                  
                     <a href="download_csv_sample?tbl=<?php echo $_GET['formid'] ?>"><button  class="btn btn-primary btn-sm btn-user"><i class="fas fa-download fa-sm text-white-50"></i> Download CSV Formate</button></a>  
                   
                  </div>

                  <div style="display: none;padding: 10px;margin: 5px;" id="status" class="alert" role="alert">
                     <span id="statusText"></span>
                    </div>

                
                    <div class="card-body">

    <div style="display: none;" id="status" class="alert" role="alert">
                     <span id="statusText"></span>
                    </div>


                        <div class="row">
             <div class="col-md-6">
                    <!-- CSV file upload form -->
                  
                      <form id="importData" action="" enctype="multipart/form-data" method="post">
                      <input type="hidden" name="form_table_name" value="<?php echo $form_table_name; ?>"/>
                        <div class="custom-file">
                          <input type="file" name="filename" required class="custom-file-input" id="customFile">
                        
                          <label class="custom-file-label" for="customFile">Select .CSV File </label>

                          <input type="submit" name="submit" value="Import Data" class="btn mt-2 btn-block btn-primary btn-user">
                        </div>

                      </form>
                 
                  </div>

                    <div class="col-md-6">
                    <!-- CSV file upload form -->
                   <div style="padding: 6px;" class="alert alert-warning" role="alert">
                   Downlaod First CSV Formate 
                  </div> 
                  <div style="padding: 6px;" class="alert alert-warning" role="alert">
                    Don't Change the formate of the .CSV File. 
                  </div> 
                 
                  </div>
                </div>
                </div>

              </div>
           
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
          


<script type="text/javascript">

    $(document).ready(function(){

      $(".custom-file-input").on("change", function() {
          var fileName = $(this).val().split("\\").pop();
          $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
      });


         $(document).ready(function (e) {
      $("#importData").on('submit',(function(e) {
      e.preventDefault();
      $.ajax({
      url: "Ajax_importData.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
      cache: false,
      processData:false,
      beforeSend : function(){
      //$("#preview").fadeOut();
      console.log('before call');
  
      }, complete: function(){
      $('#loader').hide();
      },
      success: function(data){

       console.log(data);

       if(data==1){
       
         var status = document.getElementById('status');
         status.style.display = "block";
         var statusText = document.getElementById('statusText');
         status.classList.add("alert-success");
         statusText.innerHTML = "Data Important Successful";

          setTimeout(function(){
            window.location.href = 'list-of-forms';
         }, 2000);



       }else if(data!=''){
      // view uploaded file.
       console.log('insert  call',data);  
      
      }
      },
      error: function(e){
     console.log('error call ');
      }          
      });
      }));
      });









   });




</script>



      </body>
    </html>