<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
$User_id=$_SESSION['userid'];
$profile_group_id=$_SESSION['profile_group_id'];
// $query ="select * from tbl_forms where user_id=$User_id order by id DESC LIMIT 5";
if($profile_group_id==1){
$query="select f.*, u.username from tbl_forms f, users u where u.id=f.user_id order by f.id desc";
}else{
$query="select f.*, u.username from tbl_forms f, users u where u.id=f.user_id and f.user_id=$User_id order by f.id desc";
}
$all_form_list = $db->execute_query($query);

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> All Form List </title>
    <?php include_once '../inc/style.php'; ?>
  </head>
<body id="page-top">
<!-- Page Wrapper -->
<div id="wrapper">
<!-- Sidebar -->
<?php include_once '../inc/side_menu.php'; ?>
<!-- End of Sidebar -->
<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">
  <!-- Main Content -->
  <div id="content">
    <!-- Topbar -->
    <?php include_once '../inc/header.php'; ?>
    <!-- End of Topbar -->
    <!-- Begin Page Content -->
    <div class="container-fluid">
      <!-- Page Heading -->
      <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"> All Form List  </h1> <a href="create-server-form" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">Add New</a>
        
      </div>
  <div class="row">
    <div class="col-lg-12">
      <!-- Dropdown Card Example -->
      <div class="card shadow mb-4">
        <!-- Card Header - Dropdown -->
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
          <h6 class="m-0 font-weight-bold text-primary">List Of All Forms </h6>
          
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered text-center" id="formlist" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>ID</th>
              <th>User Name</th>
              <th>Form Title</th>
              <th>Total Data</th>
              <th>Create Date</th>
              <th>Action</th>
              
            </tr>
            <tfoot>
            <tr>
              <th>ID</th>
               <th>User Name</th>
              <th>Form Title</th>
              <th>Total Data</th>
              <th>Create Date</th>
              <th>Action</th>
            </tr>
            </tfoot>


              <?php
                if($all_form_list->num_rows==0) {
                   echo "<div class='text-center alert alert-danger'> No Record </div>";
                  }
                  else {

                 while($row = $all_form_list->fetch_array()): ?>     

                  <tr>
                    <td> <?php echo $row['id'];?> </td>
                    <td> <?php echo $row['username'];?> </td>
                    <td><?php echo $row['name'];?></td>
                    <td>
                      <?php 

                          $table_name= $row['form_table_name']; 

                          $total_data ="SELECT * FROM $table_name";

                          $result = $db->execute_query($total_data);
                      
                          echo $result->num_rows;
                       ?>
                     </td>
                      <td><?php echo $row['created_date'];?></td>
                    <td>
                      <div class="btn-group" role="group" aria-label="Basic example">
                      
                      <a href="form-view.php?id=<?php echo base64_encode($row['id']);  ?>&&formid=<?php echo base64_encode($row['form_table_name']);?>"><button type="button" class="btn btn-sm btn-warning">View Form</button></a>

                      <a href="data-collected.php?id=<?php echo base64_encode($row['id']);  ?>&&formid=<?php echo base64_encode($row['form_table_name']);?>"><button type="button" class="btn btn-sm btn-primary">View Data</button></a>

                      <a href="bulk-upload?id=<?php echo base64_encode($row['id']);  ?>&&formid=<?php echo base64_encode($row['form_table_name']);?>"><button type="button" class="btn btn-sm btn-secondary">Import Data</button></a>




                      </div>
                    </td>
                  </tr>

             <?php endwhile; } 
              $db->dbClose(); ?>


          </thead>
              <tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
        
        
      </div>
    </div>
    <!-- End of Main Content -->
    <?php include_once '../inc/footer.php'; ?>
    <!-- Show/hide CSV upload form -->
    
    <script type="text/javascript">
      $(document).ready(function() {
       $('#formlist').DataTable({
          "order": [[ 0, "desc" ]],
           responsive: true
       });
   });
    </script>


  </body>
</html>