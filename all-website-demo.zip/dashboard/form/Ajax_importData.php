<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
$User_id=$_SESSION['userid'];
$file_name = $_FILES['filename']['name'];
$form_table_name=$_POST['form_table_name'];
//print_r($_FILES);
//print_r($_POST);
if(($file_name!='')) {
$path = "upload/";
$tmp = $_FILES["filename"]["tmp_name"];
$valid_extensions = array('csv'); // valid extensions
$ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
$final_name = date('dmYHis').$file_name;
$filpath = '/opt/bitnami/nginx/html/dashboard/form/upload/'.$final_name;
$filpath;

//$filpath = 'http://mybase.in/dashboard/form/upload/data.csv';
//$filpath = 'http://mybase.in/dashboard/form/upload/data.csv';
//http://mybase.in/dashboard/form
//$filpath = 'upload/21012020152655data3.csv';
if(in_array($ext, $valid_extensions)){
$uplo = move_uploaded_file($tmp, "$path/$final_name");//Product Thumb  

$db->execute_query("SET GLOBAL local_infile = TRUE;");
//$db->execute_options("MYSQLI_OPT_LOCAL_INFILE");
//$db->options(MYSQLI_OPT_LOCAL_INFILE, 10);
//mysqli_options($conn, MYSQLI_OPT_LOCAL_INFILE, true);
//$con -> options(MYSQLI_READ_DEFAULT_FILE, "myfile.cnf");
//$sqlin = mysqli_query($conn, 'LOAD DATA LOCAL INFILE "'.'../'.$filpath.'" INTO TABLE blacklist FIELDS TERMINATED by \',\' LINES TERMINATED BY \'\n\' IGNORE 0 LINES (number) SET user_id = "'.$userid.'",gb_id = "'.$last_id.'",status =1') or die(mysqli_error($conn));


//$importdatat ="LOAD DATA LOCAL INFILE '".$filpath."' INTO TABLE  ".$form_table_name." FIELDS TERMINATED by \',\' LINES TERMINATED BY \'\n\' IGNORE 0 LINES";
$importdatat ='LOAD DATA LOCAL INFILE "'.$filpath.'" INTO TABLE '.$form_table_name.' FIELDS TERMINATED by \',\' LINES TERMINATED BY \'\n\' IGNORE 1 LINES';


$result = $db->execute_query($importdatat);

if($result){
	echo 1;

}
else{
	echo "Not";
}


} else {
	echo "Invilid format File";
} 
}


exit();

?>