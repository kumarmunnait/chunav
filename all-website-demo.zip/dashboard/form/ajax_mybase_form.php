<?php 
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
$user_id = $_POST['user_id'];
$form_id = $_POST['form_id'];
$form_id_name = $_POST['form_id_name'];
$query ="select * from tbl_forms where user_id='$user_id ' AND id='$form_id'";
  $formdata  = $db->execute_query($query);
if($formdata) {
     $row = $formdata->fetch_assoc();
      $form_name = $row['name'];
      $form_html = $row['form_html'];
      $form_tabel_name = $row['form_table_name'];
      $form_fields = $row['form_fields'];
      $form_field= explode(",",$form_fields);
      $filed = count($form_field);
      $form_html = str_replace("Delete"," ", $form_html);
      $html = str_replace('contenteditable="true"'," ", $form_html);
  }

$query_trigger ="SELECT * FROM set_trigger where tigger_user_id='$user_id' and form_id_for_trigger='$form_id'";
$checktrigger = $db->execute_query($query_trigger);

  if($checktrigger) {
      $row = $checktrigger->fetch_assoc();
	  $col=$row['form_option'];
	  $mobile =$_POST[$col];
      $get_triger_form_id = $row['form_id_for_trigger'];
      if($form_tabel_name == $form_id_name){
			// "trigger set";
			$msg=$row['trigger_message'];
			$message = urlencode($msg);
			$resetlink = sendtrigger($mobile,$message); 
 
      }else{
        echo "This Form Don't have any trigger";
      }

    }



	 $form_post_data=""; 
	 for($i=0;$i<$filed;$i++){
	 $var ="'".$form_field[$i]."'";
	      $form_post_data .= "'".$_POST[$form_field[$i]]."',";
	  }
     $form_post_data=substr($form_post_data, 0, -1);
	   $insert_form_data ="INSERT INTO $form_id_name ($form_fields)
	  VALUES ($form_post_data);";
	       $insert_form_data = $db->insert($insert_form_data);
	      if($insert_form_data){
	        echo 1;
	      } 
	      else{
	        echo "<script>alert('Error in Record Insertedd')</script>";
	      }





// send reset link 
function sendtrigger($mobile,$message_staff){
$sender ='ACCOTP';
$auth='D!~1988aJRF9l2ZcJ';
$hostUrl = 'https://global.datagenit.com/API/sms-api.php?auth='.$auth.'&msisdn='.$mobile.'&senderid='.$sender.'&message='.$message_staff.'';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $hostUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_POST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0); // change to 1 to verify cert
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
//curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
$resetlink = curl_exec($ch);
return $resetlink;
} 

// send reset link 





?>