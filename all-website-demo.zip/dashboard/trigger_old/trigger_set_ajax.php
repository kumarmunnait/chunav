<?php
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
include_once '../lib/user.php';
$db = new user();
$User_id=$_SESSION['userid'];
$form_id_for_trigger="formid123";
$trigger_name=$_POST['trigger_name'];
$trigger_message=$_POST['trigger_message'];
$send_option=$_POST['send_option'];
$send_day_wise_message=$_POST['send_day_wise_message'];
$form_option=$_POST['form_option'];
$set_date=$_POST['set_date'];
$set_month=$_POST['set_month'];
$day_after=$_POST['day_after'];
$set_time=$_POST['set_time'];
$activate=$_POST['activate'];
$query ="INSERT INTO set_trigger (tigger_user_id,form_id_for_trigger,tigger_name,trigger_message, mesage_type, day_message, form_option, set_date, set_month, day_after, set_time, status)
VALUES ('$User_id','$form_id_for_trigger','$trigger_name','$trigger_message','$send_option','$send_day_wise_message','$form_option','$set_date','$set_month','$day_after','$set_time','$activate')";

$trigger_set = $db->execute_query($query);

if($trigger_set){
	echo 1;
}else{
	echo 2;
}



?>