<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
$User_id=$_SESSION['userid'];
$query ="select * from tbl_forms where user_id=$User_id";
$trigger_form = $db->execute_query($query);

// Select all Predefined Trigger
$pre_query ="select * from predefined_trigger";
$all_pre_def_trigger = $db->execute_query($pre_query);


// trigger set query 
$query ="select * from set_trigger where tigger_user_id=$User_id";
$trigger = $db->execute_query($query);


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Coupon Dashboard</title>
    <?php include_once '../inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">  Trigger   </h1> <a href="create-server-form" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">Set New Trigger</a>
              
            </div>
            <div class="row">
              
              <div class="col-lg-12">
                <!-- Dropdown Card Example -->
                <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary"> Select One Form List: </h6>
                  </div>
                  <div class="card-body">
                    <div class="form-group">
                      <select id="formselect" class="form-control">
                         <?php
                    if($trigger_form==false) {
                       echo "<div class='text-center alert alert-danger'> No Trigger </div>";
                      }
                      else{
                        echo"<option value=''> Select Form For Trigger </option>";
                  while($row = $trigger_form->fetch_array()): ?>

                     <option value=""> <?php echo $row['name'];?>  </option>

                     <?php endwhile; } ?>

                      </select>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div style="display: none;" id="show-trigger" class="row justify-content-center">
           
                 <div class="col-lg-8">
                <!-- Dropdown Card Example -->
                <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Trigger Action </h6>
                  </div>
                  <!-- Card Body -->
                  <div class="card-body">
                       <div class="row">
                  
                    <div class="col-md-12">
                
                        <div class="">
      
      <ul class="timeline">

        

      
            <?php
            
             if($trigger->num_rows ==0) {
                       echo "<li>
          <a href='javascript:void(0)'>Set New Trigger </a>
          <p>Click On Add New Trigger Button </p>
        </li> ";
                      }

              else{

        while($row = $trigger->fetch_array()): ?>


        <li>
          <a href="#"><?php echo $row['tigger_name'];?></a>
          <a href="#" class="float-right">Edit </a>
          <p><?php echo $row['trigger_message'];?></p>
           <div class="footer-time-line">
             <a href="#" >Date : 1 April, 2014</a> <a href="#" >Voice Call</a>
          </div>
        </li> 

  <?php endwhile; } ?>


        <div style="display: none;" id="status" class="alert alert-dismissible" role="alert">
           <span id="statusText"></span>
          </div>
       

         <div class="collapse mt-2" id="newtrigger">
          <div style="background: #95e8f15c;" class="card card-body">

              

           <form id="set_new_trigger" action="" method="post">

              <div class="form-group">
                <label>Select Predefined Trigger </label>

                 <select id="formselect" class="form-control">
                         <?php
                    if($all_pre_def_trigger==false) {
                       echo "<div class='text-center alert alert-danger'> No Predefined Trigger </div>";
                      }
                      else{
                        echo"<option value=''> Select Predefined Trigger </option>";
                  while($row = $all_pre_def_trigger->fetch_array()): ?>

                     <option value=""> <?php echo $row['pre_tigger_name'];?>  </option>

                     <?php endwhile; } ?>

                      </select>
                
              </div>


              <div class="form-group">
                 <div class="filter-content mb-2">
                  
                      
                                        <label class="form-check">
                        <span value="id" class="settag_field">
                          id                        </span>
                      </label> <!-- form-check.// -->
                            
                              <label class="form-check">
                        <span value="Name" class="settag_field">
                          Name                        </span>
                      </label> <!-- form-check.// -->
                            
                              <label class="form-check">
                        <span value="Phone" class="settag_field">
                          Phone                        </span>
                      </label> <!-- form-check.// -->
                            
                              <label class="form-check">
                        <span value="ChoosePlan" class="settag_field">
                          ChoosePlan                        </span>
                      </label> <!-- form-check.// -->
                            
                              <label class="form-check">
                        <span value="EnterCity" class="settag_field">
                          EnterCity                        </span>
                      </label> <!-- form-check.// -->
                            
                              <label class="form-check">
                        <span value="Address" class="settag_field">
                          Address                        </span>
                      </label> <!-- form-check.// -->
                            
                              <label class="form-check">
                        <span value="created_date" class="settag_field">
                          created_date                        </span>
                      </label> <!-- form-check.// -->
                            
                              <label class="form-check">
                        <span value="updated_date" class="settag_field">
                          updated_date                        </span>
                      </label> <!-- form-check.// -->
                            
                  </div>
                <label for="exampleFormControlTextarea1">Triger Message</label>
                <textarea id="trigger_message" required="" placeholder="Enter Message Here" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
              </div>
               <div class="row">
              <div class="form-group col-md-4">
                <label for="exampleFormControlSelect1">Send Message Type </label>
                <select class="form-control" id="send_option">
                  <option value="0">Select</option>
                  <option value="1">SMS</option>
                  <option value="2">Voice</option>
                  <option value="3">Both</option>
                </select>
              </div>

              <div class="form-group col-md-4">
                <label for="exampleFormControlSelect1">Send Message</label>
                <select class="form-control" id="send_day_wise_message">
                  <option value="0">Select Day</option>
                  <option value="all">All Day </option>
                  <option value="Sunday">Every Sunday</option>
                  <option value="Monday">Every Monday</option>
                  <option value="Tuesday">Every Tuesday</option>
                  <option value="Wednesday">Every Wednesday</option>
                  <option value="Thursday">Every Thursday</option>
                  <option value="Friday">Every Friday</option>
                  <option value="Saturday">Every Saturday</option>
                </select>
              </div>



              <div class="form-group col-md-4">
                <label for="exampleFormControlSelect1">Form Option </label>
                <select class="form-control" id="form_option">
                  <option value="0">Select Form </option>
                  <option value="dob">Date Of Birth</option>
                  <option value="created_date">Created Date</option>
                  <option value="Signup">Signup Date</option>
                </select>
              </div>

              <div class="form-group col-md-12">
                  <div class="custome-check-box">
                  <p>Day of Message</p>
                  <div class="select-box">
                   <label for="one"><input type="checkbox" id="one[]" /> All Day </label>
                 </div>
                 <div class="select-box">
                   <label for="one"><input type="checkbox" id="one[]" /> Sunday </label>
                 </div>
                 <div class="select-box">
                   <label for="one"><input type="checkbox" id="one[]" /> Monday </label>
                 </div>
                  <div class="select-box">
                   <label for="one"><input type="checkbox" id="one[]" /> Wednesday </label>
                 </div>
                 <div class="select-box">
                   <label for="one"><input type="checkbox" id="one[]" /> Tuesday </label>
                 </div>
                 <div class="select-box">
                   <label for="one"><input type="checkbox" id="one[]" /> Friday </label>
                 </div>
                 <div class="select-box">
                   <label for="one"><input type="checkbox" id="one[]" /> Saturday </label>
                 </div>
               </div>
             </div>

             <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Day</label>
                <select class="form-control" id="set_date">
                  <option value="0">Select</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                  <option value="13">13</option>
                  <option value="14">14</option>
                  <option value="15">15</option>
                  <option value="16">16</option>
                  <option value="18">18</option>
                  <option value="19">19</option>
                  <option value="20">20</option>
                  <option value="21">21</option>
                  <option value="22">22</option>
                  <option value="23">23</option>
                  <option value="24">24</option>
                  <option value="25">25</option>
                  <option value="26">26</option>
                  <option value="27">27</option>
                  <option value="28">28</option>
                  <option value="29">29</option>
                  <option value="30">30</option>
                  <option value="31">31</option>
                </select>
              </div>

            <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Month</label>
                <select class="form-control" id="set_month">
                   <option value="0">Select</option>
                  <option value="Jan">January</option>
                  <option value="Feb">February</option>
                  <option value="Mar">March</option>
                  <option value="Apr">April</option>
                  <option value="May">May</option>
                  <option value="Jun">June</option>
                  <option value="Jul">July</option>
                  <option value="Aug">August</option>
                  <option value="Sep">September</option>
                  <option value="Oct">October</option>
                  <option value="Nov">November</option>
                  <option value="Dec">December</option>
                </select>
              </div>
             
              <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Day After</label>
               <input  type="number" id="day_after" placeholder="After 15 day " class="form-control" >
              </div>
              <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Set Time</label>
                <input value="00:00" id="set_time" type="time" class="form-control" >
              </div>
            </div>

              <div style="padding-left: 20px;">
              <input type="checkbox" value="1" id="activate" class="form-check-input" checked="" id="exampleCheck1">
              <label class="form-check-label" for="exampleCheck1">Activate Trigger</label>
            </div>

          <button type="submit"  class="btn btn-sm float-right btn-primary">Save</button>
            </form>
          </div>
        </div>

         <button  data-toggle="collapse" href="#newtrigger" aria-expanded="false" aria-controls="newtrigger" class="btn btn-primary mt-3 btn-sm"> Add New Triggers </button>


      </ul>
    </div>

                    </div>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        





        
        
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>



        <!-- Show/hide CSV upload form -->

<Script> 
   $('#formselect').change(function() {
        $('#show-trigger').show();
 });
</Script>

<script type="text/javascript">
  $(".settag_field").on('click', function() {
    var caretPos = document.getElementById("trigger_message").selectionStart;
    var textAreaTxt = $("#trigger_message").val();
    var txtToAdd = $(this).closest('.settag_field').text();
      var txtToAdd = $.trim(txtToAdd);

    $("#trigger_message").val(textAreaTxt.substring(0, caretPos) + "#"+txtToAdd+"#" + textAreaTxt.substring(caretPos) );
});
</script>



<!-- send data to database funcation  -->

<script type="text/javascript">

  $(document).ready(function(){

    $("#set_new_trigger").submit(function(){
        $.post("trigger_set_ajax.php",{ 
          trigger_name:$('#trigger_name').val(),
          trigger_message:$('#trigger_message').val(),
          send_option:$('#send_option').val(),
          send_day_wise_message:$('#send_day_wise_message').val(),
          form_option:$('#form_option').val(),
          set_date:$('#set_date').val(),
          set_month:$('#set_month').val(),
          day_after:$('#day_after').val(),
          set_time:$('#set_time').val(),
          activate:$('#activate').val()
          },
          function(data){
          console.log('data=',data);
          if(data==1){
                $('#newtrigger').removeClass("show");
                  var status = document.getElementById('status');
                 status.style.display = "block";
                 var statusText = document.getElementById('statusText');
                 status.classList.add("alert-success");
                 statusText.innerHTML = "Trigger Create successful ";
                   setTimeout(function(){
                      window.location.href = 'new-trigger';
                   }, 2000);


          }
          else {

            console.log('2');
              alert('esle part');
              //  $('#newtrigger').removeClass("show");
             
           }
                
        });
   return false;

 });

   });

</script>


        
      </body>
    </html>