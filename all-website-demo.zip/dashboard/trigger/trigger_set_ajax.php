<?php
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
include_once '../lib/user.php';
$db = new user();
$User_id=$_SESSION['userid'];
 

$form_id_for_trigger=$_REQUEST['form_id'];
$form_id_for_trigger=explode("#",$form_id_for_trigger);
$form_id_for_trigger=$form_id_for_trigger[0];

$admin_mobile=$_POST['admin_mobile'];
$admin_message=$_POST['admin_message'];


$trigger_name=$_POST['trigger_name'];
$trigger_message=$_POST['trigger_message'];
$send_option=$_POST['send_option'];
$send_day_wise_message=$_POST['send_day_wise_message'];
$form_option=$_POST['form_option'];
$set_date=$_POST['set_date'];
$set_month=$_POST['set_month'];
 
$set_time=$_POST['set_time'];
$activate=$_POST['activate'];
$day_after= isset($_POST['day_after'])?$_POST['day_after']:0;
 

if(!empty($_SESSION['userid'])){
				$sql="SELECT * FROM set_trigger WHERE form_id_for_trigger='".$form_id_for_trigger."' and tigger_name='$trigger_name' and tigger_user_id='$User_id'";
				$result=$db->execute_query($sql);
				$numrows=$result->num_rows;
				
				if($numrows==0){
						$query ="INSERT INTO set_trigger (tigger_user_id,form_id_for_trigger,tigger_name,trigger_message, mesage_type, day_message, form_option, set_date, set_month, day_after, set_time,admin_mobile,admin_message,status)
						VALUES ('$User_id','$form_id_for_trigger','$trigger_name','$trigger_message','$send_option','$send_day_wise_message','$form_option','$set_date','$set_month','$day_after','$set_time','$admin_mobile','$admin_message','1')";
						$trigger_set = $db->execute_query($query);
						  echo 1;
				}else{
						  echo 5;// Triggen already created
				}
				 
}else{
	echo 2;	
}


?>