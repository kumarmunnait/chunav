<?php
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$userid=$_SESSION['userid'];
$tbl_name=$_REQUEST['tbl_name'];
$tbl_name=explode("#",$tbl_name);
$tbl_name=$tbl_name[1];
$download="select * from $tbl_name limit 0";
if(!empty($_SESSION['userid'])){ 



?> 
 <div class="row" >
              
 

                        
                 <div class="col-lg-12">
                <!-- Dropdown Card Example -->
                    <div class="card shadow mb-4"> 
      <div class="card-body">
                        <div class="row justify-content-center">
        

        </div>

       


      </ul>
    </div>

                    </div>
                  </div>
                  </div>
                </div>
              </div>
            </div>
                        </div>
                  </div>
                  </div>
                </div>
              </div>
</div>
<script type="text/javascript">
  $('select').selectpicker();
</script>

<script type="text/javascript">
  $(".settag_field").on('click', function() {
    var caretPos = document.getElementById("txt").selectionStart;
    var textAreaTxt = $("#txt").val();
    var txtToAdd = $(this).closest('.settag_field').text();
      var txtToAdd = $.trim(txtToAdd);

    $("#txt").val(textAreaTxt.substring(0, caretPos) + "#"+txtToAdd+"#" + textAreaTxt.substring(caretPos) );
});
</script>

<script type="text/javascript">
  $("#week_day").click(function(){
    $('input:checkbox').not(this).prop('checked', this.checked);
});
</script>

<script type="text/javascript">
  $(function() {
    $('#row_dim').hide(); 
    $('#event_date').change(function(){
    $('#row_dim').show(); 
    $('#bootom').hide(); 

    });
});
</script>


<script type="text/javascript">
  $(function() {
    $('#hours').hide(); 
    $('#is_repeat').change(function(){
    $('#hours').show(); 

    });
});
</script>


<?php } ?>