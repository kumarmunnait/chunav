<?php
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$userid=$_SESSION['userid'];
$tbl_name=$_REQUEST['tbl_name'];
$tbl_name=explode("#",$tbl_name);
$tbl_name=$tbl_name[1];
$download="select * from $tbl_name limit 0";
if(!empty($_SESSION['userid'])){ 



?> 
 <div class="row" >
              
 

                        
                 <div class="col-lg-12">
                <!-- Dropdown Card Example -->
                    <div class="card shadow mb-4"> 
      <div class="card-body">
                        <div class="row justify-content-center">
        

         <div class="collapse show mt-2" id="newtrigger">
          <div style="background: #95e8f15c;" class="card card-body">

            
              <div class="form-group">
                <label>Enter Trigger Name </label>

                <input type="text" class="form-control" id="trigger_name" required="" name="trigger_name">
                
              </div>
                <div class="form-group">



                <label>Trigger Message</label>

                <div class="set_message_box">
                  <div class="filter-content">
                      <label class="form-check">
                        <span value="id" class="settag_field">
                          id </span>
                      </label> 
                      <label class="form-check">
                        <span value="FullName" class="settag_field">
                          FullName</span>
                      </label>     
                      <label class="form-check">
                        <span value="updated_date" class="settag_field">
                          updated_date</span>
                      </label> 
                  </div>

                      <textarea id="trigger_message"  name="trigger_message" required placeholder="Dear #FullName#, Message " class="form-control" rows="3"></textarea>
                  <input type="checkbox" id="" name="unicode" value="1"> <small> Unicode SMS </small> 

                </div>

             
                
              </div>

              <div class="row">
               <div class="form-group col-md-4">
                <label>Mobile Column Name</label>

                 <select class="form-control" name="form_option" id="form_option" required="">
                                     <option value="">Select Mobile Column</option> 
                                       <?php
						$result1 = $db->execute_query($download);
 					while ($fieldinfo1 = $result1 -> fetch_field()) {
							//$contents .= '"'.$fieldinfo -> name.'",';
							?>
                    <option value="<?php echo $fieldinfo1 -> name; ?>"><?php echo $fieldinfo1 -> name; ?></option> 
                            
					<?php   } ?>
                                    </select>
                
              </div>
                    <div class="form-group col-md-4">
                <label for="exampleFormControlSelect1">Select Channel </label>
                <select class="form-control" name="channel" id="channel" required>
                  <option value="0">Select</option>
                  <option value="SMS">SMS</option>
                  <option value="Voice">Voice</option>
                  <option value="Both">Both</option>
                </select>
              </div>

              <div class="form-group col-md-4">
                     <label for="exampleFormControlSelect1">Select Sender ID </label>
                          <select class="form-control" name="sender_id" id="sender_id" required="">
                          <option value="">Select Senderid</option> 
                          <?php
                          $query1="select * from sender_id where user_id='$userid' order by id desc";     
                          $all_senderid_list = $db->execute_query($query1);
                          if($all_senderid_list->num_rows>0) { 
                                 while($row_sender = $all_senderid_list->fetch_array()){ ?>  
                          <option value="<?php echo $row_sender['sender_id_val']; ?>"><?php echo $row_sender['sender_id_val']; ?></option> 
                          <?php }  } ?>
                          </select>          
                </div> 
            </div>

            <div class="row">
               <div class="form-group col-md-12">
                <label>Event Column Date</label>

                 <select class="form-control" name="event_date" id="event_date" >
                                     <option value="">Select Mobile Date</option> 
                                       <?php
                    $result1 = $db->execute_query($download);
                  while ($fieldinfo1 = $result1 -> fetch_field()) {
                      //$contents .= '"'.$fieldinfo -> name.'",';
                      ?>
                            <option value="<?php echo $fieldinfo1 -> name; ?>"><?php echo $fieldinfo1 -> name; ?></option> 
                                    
                  <?php   } ?>
                </select>
                
              </div>
            </div>
            <div id="row_dim" style="padding: 10px;margin-bottom: 12px;" class="custome-check-box">
            <div  class="row">

            <div class="col-md-12">
               <label for="one"><input type="checkbox" name="on_date" id="on_date" value="1"/> On Date </label>
               <hr>
            </div>

            <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Day Before</label>
               <select class="form-control" name="bef_day" id="bef_day">
                  <option value="0">Select</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                  <option value="13">13</option>
                  <option value="14">14</option>
                  <option value="15">15</option>
                </select>
              </div>
              
             
              <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Day After</label>
               <select class="form-control" name="aft_day" id="aft_day">
                  <option value="0">Select</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                  <option value="13">13</option>
                  <option value="14">14</option>
                  <option value="15">15</option>
                </select>
              </div>
              
              <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Set Time</label>
                <input value="00:00" id="set_time" name="set_time_ev" type="time" class="form-control" >
              </div>

              <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Repeat In Day  </label>
                <select  name="is_repeat" id="is_repeat" class="form-control">
                 <option value="">Select </option>
                  <option  value="1">1 Time</option>
                  <option value="2">2 Time</option>
                  <option value="3">3 Times</option>
                </select>
              </div>

                <div id="hours" class="form-group col-md-3">
                <label for="exampleFormControlSelect1">After Minute  </label>
                <input value="" id="aft_minute" placeholder="5" name="rep_aft_minute" type="text" class="form-control" >
              </div>
            


            </div>
            </div>
           
          


               
               <div class="row">
         

              <div class="form-group col-md-12">
                  <div class="custome-check-box">
                  <p>Day of Message</p>
                  <div class="select-box">
                   <label for="one"><input type="checkbox" name="week_day[]" value="ALL" id="week_day" /> All Day </label>
                 </div>
                 <div class="select-box">
                   <label for="one"><input type="checkbox" name="week_day[]" value="Sunday" id="week_day[]" /> Every Sunday </label>
                 </div>
                 <div class="select-box">
                   <label for="one"><input type="checkbox" name="week_day[]" value="Monday" id="week_day[]" /> Every Monday </label>
                 </div>
                    <div class="select-box">
                   <label for="one"><input type="checkbox" name="week_day[]" value="Tuesday" id="week_day[]" /> Every Tuesday </label>
                 </div>
                  <div class="select-box">
                   <label for="one"><input type="checkbox" name="week_day[]" value="Wednesday" id="week_day[]" /> Every Wednesday </label>
                 </div>

                   <div class="select-box">
                   <label for="one"><input type="checkbox" name="week_day[]" value="Thursday" id="week_day[]" /> Every Thursday  </label>
                 </div>
              
                 <div class="select-box">
                   <label for="one"><input type="checkbox"  name="week_day[]" value="Friday" id="week_day[]" /> Every Friday </label>
                 </div>

                 <div class="select-box">
                   <label for="one"><input type="checkbox" name="week_day[]" value="Saturday" id="week_day[]" /> Every Saturday </label>
                 </div>
               </div>
             </div>
           </div>

             <div id="bootom" class="row">

             <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Day</label>
                <select class="form-control" name="set_date" id="set_date">
                  <option value="0">Select</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                  <option value="13">13</option>
                  <option value="14">14</option>
                  <option value="15">15</option>
                  <option value="16">16</option>
                  <option value="18">18</option>
                  <option value="19">19</option>
                  <option value="20">20</option>
                  <option value="21">21</option>
                  <option value="22">22</option>
                  <option value="23">23</option>
                  <option value="24">24</option>
                  <option value="25">25</option>
                  <option value="26">26</option>
                  <option value="27">27</option>
                  <option value="28">28</option>
                  <option value="29">29</option>
                  <option value="30">30</option>
                  <option value="31">31</option>
                </select>
              </div>

            <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Month</label>
                <select class="form-control" name="set_month" id="set_month">
                   <option value="">Select</option>
                  <option value="Jan">January</option>
                  <option value="Feb">February</option>
                  <option value="Mar">March</option>
                  <option value="Apr">April</option>
                  <option value="May">May</option>
                  <option value="Jun">June</option>
                  <option value="Jul">July</option>
                  <option value="Aug">August</option>
                  <option value="Sep">September</option>
                  <option value="Oct">October</option>
                  <option value="Nov">November</option>
                  <option value="Dec">December</option>
                </select>
              </div>
             
              <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Day After</label>
              
                <select class="form-control" name="day_after" id="day_after">
                  <option value="0">Select</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                  <option value="13">13</option>
                  <option value="14">14</option>
                  <option value="15">15</option>
                </select>
              </div>

              <div  class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Set Time</label>
                <input value="00:00" id="set_time" name="set_time" type="time" class="form-control" >
              </div>
            </div>

          </div>

              <div style="padding-top: 20px;">
             
          <button type="submit"  class="btn btn-sm float-right btn-primary">Save Trigger</button>
            </div>

            
          </div>
        </div>

       


      </ul>
    </div>

                    </div>
                  </div>
                  </div>
                </div>
              </div>
            </div>
                        </div>
                  </div>
                  </div>
                </div>
              </div>
</div>
<script type="text/javascript">
  $('select').selectpicker();
</script>

<script type="text/javascript">
  $(".settag_field").on('click', function() {
    var caretPos = document.getElementById("txt").selectionStart;
    var textAreaTxt = $("#txt").val();
    var txtToAdd = $(this).closest('.settag_field').text();
      var txtToAdd = $.trim(txtToAdd);

    $("#txt").val(textAreaTxt.substring(0, caretPos) + "#"+txtToAdd+"#" + textAreaTxt.substring(caretPos) );
});
</script>

<script type="text/javascript">
  $("#week_day").click(function(){
    $('input:checkbox').not(this).prop('checked', this.checked);
});
</script>

<script type="text/javascript">
  $(function() {
    $('#row_dim').hide(); 
    $('#event_date').change(function(){
    $('#row_dim').show(); 
    $('#bootom').hide(); 

    });
});
</script>


<script type="text/javascript">
  $(function() {
    $('#hours').hide(); 
    $('#is_repeat').change(function(){
    $('#hours').show(); 

    });
});
</script>


<?php } ?>