<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
$userid=$_SESSION['userid'];

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Send SMS</title>
    <?php include_once '../inc/style.php'; ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/css/bootstrap-select.min.css">
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
            <div class="container-fluid">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">  Create Trigger   </h1> <a href="create-server-form" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">Change Form</a>
              
            </div>

            

             <form id="set_new_trigger" action="" method="post" name="send_sms">
             <input type="hidden" name="counting" id="count"/>
                    <div class="row">
                                <div class="col-lg-12">
                        <!-- Dropdown Card Example -->
                                <div class="card shadow mb-4">
                          <!-- Card Header - Dropdown -->
                          <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary"> Select Form: </h6>
                          </div>
                                   <div class="card-body">
                                   
                                   
                                  
                                          <div class="form-group">
                                            <select class="form-control" onChange="getFormfields(this.value),getCountAll(this.value);" name="form_id" id="form_id" required="">
                                             <option value="">Select Form</option> 
                                           <?php
                                            $query="select f.*, u.username from tbl_forms f, users u where u.id=f.user_id and user_id='$userid' order by f.id desc";			
                                            $all_form_list = $db->execute_query($query);
                                             if($all_form_list->num_rows>0) { 
                                                     while($row = $all_form_list->fetch_array()){ ?>  
                                                <option value="<?php echo $row['id']."#".$row['form_table_name']."#".$row['form_fields']; ?>"><?php echo $row['name']; ?></option> 
                                              <?php }  } ?>
                                            </select>
                                          </div>
                                          
                                          
                                        
                        </div>
                    </div>
                              </div>
                     </div>
                      <div id="filter-data">
                      
                      </div> 
                      
                        <div id="getcount">
                      
                      </div> 
                      
            </form> 


</div>
            </div>
          </div>
        </div>
        
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>

<script>
  $(document).ready(function (e) {
   $("#set_new_trigger").on('submit',(function(e) {
    e.preventDefault();
    $.ajax({
      url: "ajax_trigger_set.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
      cache: false,
      processData:false,
      beforeSend : function(){
      console.log('before call');
      $("#err").fadeOut();
      },
      success: function(data){
        console.log('success call',data);
        data=data.trim(); 
        if(data=='1'){
          $("#err").hide();         
          $("#success").html("User Created Successfully!").fadeIn();  
            alert('User Created Successfully');       
            $("#myBaseform")[0].reset();      
            document.location='thank-you';          
        }else{
          $("#success").hide();         
          $("#err").html("Something went wrong. Please try again!").fadeIn(); 
           alert('Something went wrong. Please try again!');        
        }
       },
       error: function(e){
          console.log('error call');
          $("#err").html(e).fadeIn();
      }          
    });
   }));
  });

</script>

 <script>
  
 
function getFormfields(val) {
 	$.ajax({
	type: "POST",
	url: "ajax_custom-filterdata.php",
	data:'&tbl_name='+val,
	success: function(data){
		$("#getcount").html(data);
 	 }
	});
}



function getCount(val) {
		$("#count").val('10');
		$("#send_sms").submit();
		 
}
function getCountAll(val) {
  	$.ajax({
	type: "POST",
	url: "ajax_getcountall.php",
	data:'&tbl_name='+val,
	success: function(data){
		$("#getcount2").html(data);
 	 }
	});
		 
}

function setCount(val) {
		$("#count").val('20');
  }
</script>





        <!-- Show/hide CSV upload form -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/bootstrap-select.min.js"></script>


 
      </body>
    </html>