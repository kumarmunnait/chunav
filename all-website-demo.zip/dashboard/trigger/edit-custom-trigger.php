<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
include_once '../lib/db_config.php';
$db = new database();
$userid=$_SESSION['userid'];
$form_trigger_id=base64_decode($_GET['formid']);
$trigger_id=base64_decode($_GET['triggerid']);
$query ="select * from tbl_forms where id=$form_trigger_id";
$trigger_form_name = $db->execute_query($query);
if($trigger_form_name ) {
      $row = $trigger_form_name->fetch_assoc();
      $form_name = $row['form_table_name'];
  }
$download="select * from $form_name limit 0";
$trigger_data ="select * from set_trigger where id=$trigger_id AND tigger_user_id=$userid";
$trigger_data = $db->execute_query($trigger_data);
if($trigger_data ) {
      $rowtrigger = $trigger_data->fetch_assoc();
       $tigger_name = $rowtrigger['tigger_name'];
       $trigger_message = $rowtrigger['trigger_message'];
         $mobile_cal = $rowtrigger['form_option'];
         $channel = $rowtrigger['channel'];
         $sender_id = $rowtrigger['sender_id'];
         $event_date_col = $rowtrigger['event_date_col'];
         $bef_day = $rowtrigger['bef_day'];
         $aft_day = $rowtrigger['aft_day'];
         $set_time_ev = $rowtrigger['set_time_ev'];
         $is_repeat = $rowtrigger['is_repeat'];
         $rep_aft_minute = $rowtrigger['rep_aft_minute'];
         $on_date = $rowtrigger['on_date'];
    }


?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Edit Trigger</title>
    <?php include_once '../inc/style.php'; ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/css/bootstrap-select.min.css">
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
            <div class="container-fluid">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">  Edit Trigger   </h1> 
              
            </div>

            

         <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary"> <span class="data-name">Trigger Name:</span> <?php echo $tigger_name ?> </h6>
                </div>
                <div class="card-body"> 


         <div class="collapse show mt-2" id="newtrigger">
          <div style="background: #95e8f15c;" class="card card-body">

            
              <div class="form-group">
                <label>Enter Trigger Name </label>

                <input type="text" value="<?php echo $tigger_name ?>" class="form-control" id="trigger_name" required="" name="trigger_name">
                
              </div>
                <div class="form-group">



                <label>Trigger Message</label>

                <div class="set_message_box">


                  <div class="filter-content">
                      <label class="form-check">
                        <span value="id" class="settag_field">
                          id </span>
                      </label> 
                      <label class="form-check">
                        <span value="FullName" class="settag_field">
                          FullName</span>
                      </label>     
                      <label class="form-check">
                        <span value="updated_date" class="settag_field">
                          updated_date</span>
                      </label> 
                   </div>

                      <textarea id="trigger_message"   name="trigger_message" required placeholder="Dear #FullName#, Message " class="form-control" rows="3"><?php echo $trigger_message ?></textarea>
                  <input type="checkbox" id="" name="unicode" value="1"> <small> Unicode SMS </small> 

                </div>

             
                
              </div>

              <div class="row">
               <div class="form-group col-md-4">
                <label>Mobile Column Name</label>

                 <select class="form-control" name="form_option" id="form_option" required="">

         

                                     <option value="">Select Mobile Column</option> 
                                       <?php
            $result1 = $db->execute_query($download);
          while ($fieldinfo1 = $result1 -> fetch_field()) {
              //$contents .= '"'.$fieldinfo -> name.'",';
              ?>
                    <option value="<?php echo $fieldinfo1 -> name; ?>"<?php if($fieldinfo1 -> name== $mobile_cal) echo 'selected' ; ?>><?php echo $fieldinfo1 -> name; ?></option> 
                            
          <?php   } ?>
                                    </select>
                
              </div>
                    <div class="form-group col-md-4">
                <label for="exampleFormControlSelect1">Select Channel </label>
                <select class="form-control" name="channel" id="channel" required>
                  <option value="0" >Select</option>
                  <option value="SMS" <?php if("SMS"== $channel) echo 'selected' ; ?>>SMS</option>
                  <option value="Voice" <?php if("Voice"== $channel) echo 'selected' ; ?>>Voice</option>
                  <option value="Both" <?php if("Both"== $channel) echo 'selected' ; ?>>Both</option>
                </select>
              </div>

              <div class="form-group col-md-4">
                     <label for="exampleFormControlSelect1">Select Sender ID </label>
                          <select class="form-control" name="sender_id" id="sender_id" required="">
                          <option value="">Select Senderid</option> 
                          <?php
                          $query1="select * from sender_id where user_id='$userid' order by id desc";     
                          $all_senderid_list = $db->execute_query($query1);
                          if($all_senderid_list->num_rows>0) { 
                                 while($row_sender = $all_senderid_list->fetch_array()){ ?>  
                          <option value="<?php echo $row_sender['sender_id_val']; ?>" <?php if($row_sender['sender_id_val']== $sender_id) echo 'selected' ; ?> ><?php echo $row_sender['sender_id_val']; ?></option> 
                          <?php }  } ?>
                          </select>          
                </div> 
            </div>

            <div class="row">
               <div class="form-group col-md-12">
                <label>Event Column Date</label>

                 <select class="form-control" name="event_date" id="event_date" >
                                     <option value="">Select Mobile Date</option> 
                                       <?php
                    $result1 = $db->execute_query($download);
                  while ($fieldinfo1 = $result1 -> fetch_field()) {
                      //$contents .= '"'.$fieldinfo -> name.'",';
                      ?>
                            <option value="<?php echo $fieldinfo1 -> name; ?>" <?php if($fieldinfo1 -> name == $event_date_col) echo 'selected' ; ?> ><?php echo $fieldinfo1 -> name; ?></option> 
                                    
                  <?php   } ?>
                </select>
                
              </div>
            </div>
            <div id="row_dim" style="padding: 10px;margin-bottom: 12px;" class="custome-check-box">
            <div  class="row">

            <div class="col-md-12">
               <label for="one"><input type="checkbox" name="on_date" id="on_date" value="1"/> On Date </label>
               <hr>
            </div>

            <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Day Before</label>
               <select class="form-control" name="bef_day" id="bef_day">
                  <option value="0" <?php if("0"== $bef_day) echo 'selected' ; ?>>Select</option>
                  <option value="1" <?php if("1"== $bef_day) echo 'selected' ; ?>>1</option>
                  <option value="2" <?php if("2"== $bef_day) echo 'selected' ; ?>>2</option>
                  <option value="3" <?php if("3"== $bef_day) echo 'selected' ; ?>>3</option>
                  <option value="4" <?php if("4"== $bef_day) echo 'selected' ; ?>>4</option>
                  <option value="5" <?php if("5"== $bef_day) echo 'selected' ; ?>>5</option>
                  <option value="6" <?php if("6"== $bef_day) echo 'selected' ; ?>>6</option>
                  <option value="7" <?php if("7"== $bef_day) echo 'selected' ; ?>>7</option>
                  <option value="8" <?php if("8"== $bef_day) echo 'selected' ; ?>>8</option>
                  <option value="9" <?php if("9"== $bef_day) echo 'selected' ; ?>>9</option>
                  <option value="10" <?php if("10"== $bef_day) echo 'selected' ; ?>>10</option>
                  <option value="11" <?php if("11"== $bef_day) echo 'selected' ; ?>>11</option>
                  <option value="12" <?php if("12"== $bef_day) echo 'selected' ; ?>>12</option>
                  <option value="13" <?php if("13"== $bef_day) echo 'selected' ; ?>>13</option>
                  <option value="14" <?php if("14"== $bef_day) echo 'selected' ; ?>>14</option>
                  <option value="15" <?php if("15"== $bef_day) echo 'selected' ; ?>>15</option>
                </select>
              </div>
              
              <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Day After</label>
               <select class="form-control" name="aft_day" id="aft_day">
                  <option value="0" <?php if("0"== $aft_day) echo 'selected' ; ?>>Select</option>
                  <option value="1" <?php if("1"== $aft_day) echo 'selected' ; ?>>1</option>
                  <option value="2" <?php if("2"== $aft_day) echo 'selected' ; ?>>2</option>
                  <option value="3" <?php if("3"== $aft_day) echo 'selected' ; ?>>3</option>
                  <option value="4" <?php if("4"== $aft_day) echo 'selected' ; ?>>4</option>
                  <option value="5" <?php if("5"== $aft_day) echo 'selected' ; ?>>5</option>
                  <option value="6" <?php if("6"== $aft_day) echo 'selected' ; ?>>6</option>
                  <option value="7" <?php if("7"== $aft_day) echo 'selected' ; ?>>7</option>
                  <option value="8" <?php if("8"== $aft_day) echo 'selected' ; ?>>8</option>
                  <option value="9" <?php if("9"== $aft_day) echo 'selected' ; ?>>9</option>
                  <option value="10" <?php if("10"== $aft_day) echo 'selected' ; ?>>10</option>
                  <option value="11" <?php if("11"== $aft_day) echo 'selected' ; ?>>11</option>
                  <option value="12" <?php if("12"== $aft_day) echo 'selected' ; ?>>12</option>
                  <option value="13" <?php if("13"== $aft_day) echo 'selected' ; ?>>13</option>
                  <option value="14" <?php if("14"== $aft_day) echo 'selected' ; ?>>14</option>
                  <option value="15" <?php if("15"== $aft_day) echo 'selected' ; ?>>15</option>
                </select>
              </div>
              
              <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Set Time</label>
                <input value="<?php echo $set_time_ev; ?>" id="set_time" name="set_time_ev" type="time" class="form-control" >
              </div>

              <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Repeat In Day  </label>
                <select  name="is_repeat" id="is_repeat" class="form-control">
                 <option value="">Select </option>
                  <option  value="1" <?php if("1"== $is_repeat) echo 'selected' ; ?>>1 Time</option>
                  <option value="2" <?php if("2"== $is_repeat) echo 'selected' ; ?>>2 Time</option>
                  <option value="3" <?php if("3"== $is_repeat) echo 'selected' ; ?>>3 Times</option>
                </select>
              </div>

                <div id="hours" class="form-group col-md-3">
                <label for="exampleFormControlSelect1">After Minute  </label>
                <input value="<?php echo $rep_aft_minute; ?>" id="aft_minute" placeholder="5" name="rep_aft_minute" type="text" class="form-control" >
              </div>
            


            </div>
            </div>
          
               <div class="row">
              <div class="form-group col-md-12">
                  <div class="custome-check-box">
                  <p>Day of Message</p>
                  <div class="select-box">
                   <label for="one"><input type="checkbox" name="week_day[]" value="ALL" id="week_day" /> All Day </label>
                 </div>
                 <div class="select-box">
                   <label for="one"><input type="checkbox" name="week_day[]" value="Sunday" id="week_day[]" /> Every Sunday </label>
                 </div>
                 <div class="select-box">
                   <label for="one"><input type="checkbox" name="week_day[]" value="Monday" id="week_day[]" /> Every Monday </label>
                 </div>
                    <div class="select-box">
                   <label for="one"><input type="checkbox" name="week_day[]" value="Tuesday" id="week_day[]" /> Every Tuesday </label>
                 </div>
                  <div class="select-box">
                   <label for="one"><input type="checkbox" name="week_day[]" value="Wednesday" id="week_day[]" /> Every Wednesday </label>
                 </div>

                   <div class="select-box">
                   <label for="one"><input type="checkbox" name="week_day[]" value="Thursday" id="week_day[]" /> Every Thursday  </label>
                 </div>
              
                 <div class="select-box">
                   <label for="one"><input type="checkbox"  name="week_day[]" value="Friday" id="week_day[]" /> Every Friday </label>
                 </div>

                 <div class="select-box">
                   <label for="one"><input type="checkbox" name="week_day[]" value="Saturday" id="week_day[]" /> Every Saturday </label>
                 </div>
               </div>
             </div>
           </div>

             <div id="bootom" class="row">

             <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Day</label>
                <select class="form-control" name="set_date" id="set_date">
                  <option value="0">Select</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                  <option value="13">13</option>
                  <option value="14">14</option>
                  <option value="15">15</option>
                  <option value="16">16</option>
                  <option value="18">18</option>
                  <option value="19">19</option>
                  <option value="20">20</option>
                  <option value="21">21</option>
                  <option value="22">22</option>
                  <option value="23">23</option>
                  <option value="24">24</option>
                  <option value="25">25</option>
                  <option value="26">26</option>
                  <option value="27">27</option>
                  <option value="28">28</option>
                  <option value="29">29</option>
                  <option value="30">30</option>
                  <option value="31">31</option>
                </select>
              </div>

            <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Month</label>
                <select class="form-control" name="set_month" id="set_month">
                   <option value="">Select</option>
                  <option value="Jan">January</option>
                  <option value="Feb">February</option>
                  <option value="Mar">March</option>
                  <option value="Apr">April</option>
                  <option value="May">May</option>
                  <option value="Jun">June</option>
                  <option value="Jul">July</option>
                  <option value="Aug">August</option>
                  <option value="Sep">September</option>
                  <option value="Oct">October</option>
                  <option value="Nov">November</option>
                  <option value="Dec">December</option>
                </select>
              </div>
             
              <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Day After</label>
              
                <select class="form-control" name="day_after" id="day_after">
                  <option value="0">Select</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                  <option value="13">13</option>
                  <option value="14">14</option>
                  <option value="15">15</option>
                </select>
              </div>

              <div  class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Set Time</label>
                <input value="00:00" id="set_time" name="set_time" type="time" class="form-control" >
              </div>
            </div>

          </div>

              <div style="padding-top: 20px;">
             
          <button type="submit"  class="btn btn-sm float-right btn-primary">Save Trigger</button>
            </div>

            
          </div>

                   
               
                     
                </div>
              </div>


</div>
            </div>
          </div>
        </div>
        
        <!-- End of Main Content -->
        <?php include_once '../inc/footer.php'; ?>

<script>
  $(document).ready(function (e) {
   $("#set_new_trigger").on('submit',(function(e) {
    e.preventDefault();
    $.ajax({
      url: "ajax_trigger_set.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
      cache: false,
      processData:false,
      beforeSend : function(){
      console.log('before call');
      $("#err").fadeOut();
      },
      success: function(data){
        console.log('success call',data);
        data=data.trim(); 
        if(data=='1'){
          $("#err").hide();         
          $("#success").html("User Created Successfully!").fadeIn();  
            alert('User Created Successfully');       
            $("#myBaseform")[0].reset();      
            document.location='thank-you';          
        }else{
          $("#success").hide();         
          $("#err").html("Something went wrong. Please try again!").fadeIn(); 
           alert('Something went wrong. Please try again!');        
        }
       },
       error: function(e){
          console.log('error call');
          $("#err").html(e).fadeIn();
      }          
    });
   }));
  });

</script>

 <script>
  
 
function getFormfields(val) {
 	$.ajax({
	type: "POST",
	url: "ajax_edit-custom-filterdata.php",
	data:'&tbl_name='+val,
	success: function(data){
		$("#getcount").html(data);
 	 }
	});
}



function getCount(val) {
		$("#count").val('10');
		$("#send_sms").submit();
		 
}
function getCountAll(val) {
  	$.ajax({
	type: "POST",
	url: "ajax_getcountall.php",
	data:'&tbl_name='+val,
	success: function(data){
		$("#getcount2").html(data);
 	 }
	});
		 
}

function setCount(val) {
		$("#count").val('20');
  }
</script>





        <!-- Show/hide CSV upload form -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/bootstrap-select.min.js"></script>


 
      </body>
    </html>