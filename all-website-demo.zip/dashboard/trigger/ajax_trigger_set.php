<?php
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
include_once '../lib/user.php';
$db = new user();
$User_id=$_SESSION['userid'];
 

$form_id_for_trigger=$_REQUEST['form_id'];
$form_id_for_trigger=explode("#",$form_id_for_trigger);
$form_id_for_trigger=$form_id_for_trigger[0];

$admin_mobile=isset($_POST['admin_mobile'])?$_POST['admin_mobile']:0; 
$admin_message=isset($_POST['admin_message'])?$_POST['admin_message']:0; 


$trigger_name=$_POST['trigger_name'];
$trigger_message=$_POST['trigger_message'];
$unicode=isset($_POST['unicode'])?$_POST['unicode']:0;
$form_option=$_POST['form_option'];

$channel=$_POST['channel'];
$sender_id=$_POST['sender_id'];
$event_date=$_POST['event_date'];
$on_date=isset($_POST['on_date'])?$_POST['on_date']:0;

$bef_day=$_POST['bef_day'];
$aft_day=$_POST['aft_day'];
$set_time_ev=$_POST['set_time_ev'];
$repeat=$_POST['is_repeat'];

$rep_aft_minute=$_POST['rep_aft_minute'];
$week_day=$_POST['week_day'];
 
$week_day=implode(",",$week_day);
$set_date=$_POST['set_date'];
$set_month=isset($_POST['set_month'])?$_POST['set_month']:0;
$day_after= isset($_POST['day_after'])?$_POST['day_after']:0;
$set_time=isset($_POST['set_time'])?$_POST['set_time']:0;

 
 

if(!empty($_SESSION['userid'])){
				$sql="SELECT * FROM set_trigger WHERE form_id_for_trigger='".$form_id_for_trigger."' and tigger_name='$trigger_name' and tigger_user_id='$User_id'";
				$result=$db->execute_query($sql);
				$numrows=$result->num_rows;
				
				if($numrows==0){
					 $query ="INSERT INTO set_trigger (tigger_user_id,form_id_for_trigger,tigger_name,trigger_message,form_option,channel,event_date_col,on_date,bef_day,aft_day,set_time_ev,is_repeat,rep_aft_minute,week_day,set_date,set_month,day_after,set_time,admin_mobile,admin_message,unicode,sender_id,status) VALUES ('$User_id','$form_id_for_trigger','$trigger_name','$trigger_message','$form_option','$channel','$event_date','$on_date','$bef_day','$aft_day','$set_time_ev','$repeat','$rep_aft_minute','$week_day','$set_date','$set_month','$day_after','$set_time','$admin_mobile','$admin_message','$unicode','$sender_id','1')";
						
						  //exit();
						$trigger_set = $db->execute_query($query);
						  echo 1;
				}else{
						  echo 5;// Triggen already created
				}
				 
}else{
	echo 2;	
}


?>