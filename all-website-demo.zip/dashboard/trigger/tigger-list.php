<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
//include_once 'lib/user.php';
include_once '../lib/db_config.php';
$User_id=$_SESSION['userid'];
$db = new database();

$query ="SELECT DISTINCT tf.name,tf.id as fid FROM set_trigger st,tbl_forms tf WHERE st.form_id_for_trigger=tf.id AND st.tigger_user_id=$User_id";
$triggerdata = $db->execute_query($query);



?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Coupon Dashboard</title>
    <?php include_once '../inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">  SMS Automation   </h1> <a href="create-server-form" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">Set New Trigger</a>
              
            </div>
            <div class="row">
              
              <div class="col-lg-12">
                <!-- Dropdown Card Example -->
                <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary"> Select One Form List: </h6>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                          <tr>
                            <th>ID</th>
                            <th>Form Name</th>
                            <th>No Of Set Trigger</th>
                            <th>Action</th>
                            
                          </tr>
                          <tfoot>
                          <tr>
                             <th>ID</th>
                            <th>Form Name</th>
                           <th>No Of Set Trigger</th>
                            <th>Action</th>
                            
                          </tr>
                          </tfoot>

                     <?php

                    if($triggerdata==false) {
                       echo "<div class='text-center alert alert-danger'> No Trigger </div>";
                      }else{

                     while($row = $triggerdata->fetch_array()): 
					 
					 ?>

                          <tr>
                            <td> 1 </td>
                            <td> <?php echo $row['name'];?> </td>
                            <td>1</td>
                            <td> <a href="view-set-trigger.php?formid=<?php echo base64_encode($row['fid']);?>"><button type="button" class="btn btn-sm btn-primary">View Trigger</button></a></td>
                          </tr>

                     <?php endwhile; } ?> 

                        </thead>
                        <tbody>
                        </table>
                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- End of Main Content -->
            <?php include_once '../inc/footer.php'; ?>
            <!-- Show/hide CSV upload form -->
            
          </body>
        </html>