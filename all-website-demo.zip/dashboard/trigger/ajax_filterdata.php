<?php
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$userid=$_SESSION['userid'];
$tbl_name=$_REQUEST['tbl_name'];
$tbl_name=explode("#",$tbl_name);
$tbl_name=$tbl_name[1];
$download="select * from $tbl_name limit 0";
if(!empty($_SESSION['userid'])){ 



?> 
 <div class="row" >
              
 
              <div class="col-lg-12">
                <!-- Dropdown Card Example -->
                <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                   
                  <!-- Card Body -->
                  <div class="card-body">
                        <div class="row justify-content-center">
                        
                 <div class="col-lg-8">
                <!-- Dropdown Card Example -->
              

        

         <div class="collapse show mt-2" id="newtrigger">
          <div style="background: #95e8f15c;" class="card card-body">

              

           

              <div class="form-group">
                <label>Select Predefined Trigger </label>

                 <select name="trigger_name" id="trigger_name" class="form-control">
                         <?php
					$pre_query ="select * from predefined_trigger";
					$all_pre_def_trigger = $db->execute_query($pre_query);
                    if($all_pre_def_trigger==false) {
                       echo "<div class='text-center alert alert-danger'> No Predefined Trigger </div>";
                      }
                      else{
                        echo"<option value=''> Select Predefined Trigger </option>";
                  while($row = $all_pre_def_trigger->fetch_array()): ?>

                     <option value="<?php echo $row['pre_tigger_name'];?>"> <?php echo $row['pre_tigger_name'];?>  </option>

                     <?php endwhile; } ?>

                      </select>
                
              </div>
                <div class="form-group">
                <label>Trigger Message</label>

                 <textarea id="trigger_message" name="trigger_message" required placeholder="Enter Message Here" class="form-control" rows="3"></textarea>
                
              </div>
               <div class="form-group">
                <label>Mobile Colom Name</label>

                 <select class="form-control" name="form_option" id="form_option" required="">
                                     <option value="">Select Mobile Colom</option> 
                                       <?php
						$result1 = $db->execute_query($download);
 					while ($fieldinfo1 = $result1 -> fetch_field()) {
							//$contents .= '"'.$fieldinfo -> name.'",';
							?>
                    <option value="<?php echo $fieldinfo1 -> name; ?>"><?php echo $fieldinfo1 -> name; ?></option> 
                            
					<?php   } ?>
                                    </select>
                 
              </div>
              
               <div class="form-group">
                <label>Event Colom Name</label>

                 <select class="form-control" name="form_option" id="form_option" required="">
                                     <option value="">Select Mobile Colom</option> 
                                       <?php
						$result1 = $db->execute_query($download);
 					while ($fieldinfo1 = $result1 -> fetch_field()) {
							//$contents .= '"'.$fieldinfo -> name.'",';
							?>
                    <option value="<?php echo $fieldinfo1 -> name; ?>"><?php echo $fieldinfo1 -> name; ?></option> 
                            
					<?php   } ?>
                                    </select>
                 
              </div>
                   <div class="form-group">
                <label for="exampleFormControlSelect1">Admin Mobile</label>
                <input placeholder="Admin Mobile Number" id="set_time" type="text" class="form-control" >
              </div>

             <div class="form-group">
                <label>Admin Message</label>

                 <textarea id="trigger_message" name="trigger_message" required placeholder="Enter Message Here" class="form-control" rows="3"></textarea>
                
              </div>
               
               <div class="row">
              <div class="form-group col-md-4">
                <label for="exampleFormControlSelect1">Send Message Type </label>
                <select class="form-control" id="send_option">
                  <option value="0">Select</option>
                  <option value="1">SMS</option>
                  <option value="2">Voice</option>
                  <option value="3">Both</option>
                </select>
              </div>

              <div class="form-group col-md-4">
                <label for="exampleFormControlSelect1">Send Message</label>
                <select class="form-control" id="send_day_wise_message">
                  <option value="0">Select Day</option>
                  <option value="all">All Day </option>
                  <option value="Sunday">Every Sunday</option>
                  <option value="Monday">Every Monday</option>
                  <option value="Tuesday">Every Tuesday</option>
                  <option value="Wednesday">Every Wednesday</option>
                  <option value="Thursday">Every Thursday</option>
                  <option value="Friday">Every Friday</option>
                  <option value="Saturday">Every Saturday</option>
                </select>
              </div>



          

              <div class="form-group col-md-12">
                  <div class="custome-check-box">
                  <p>Day of Message</p>
                  <div class="select-box">
                   <label for="one"><input type="checkbox" id="one[]" /> All Day </label>
                 </div>
                 <div class="select-box">
                   <label for="one"><input type="checkbox" id="one[]" /> Sunday </label>
                 </div>
                 <div class="select-box">
                   <label for="one"><input type="checkbox" id="one[]" /> Monday </label>
                 </div>
                  <div class="select-box">
                   <label for="one"><input type="checkbox" id="one[]" /> Wednesday </label>
                 </div>
                 <div class="select-box">
                   <label for="one"><input type="checkbox" id="one[]" /> Tuesday </label>
                 </div>
                 <div class="select-box">
                   <label for="one"><input type="checkbox" id="one[]" /> Friday </label>
                 </div>

                 <div class="select-box">
                   <label for="one"><input type="checkbox" id="one[]" /> Saturday </label>
                 </div>
               </div>
             </div>

             <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Day</label>
                <select class="form-control" id="set_date">
                  <option value="0">Select</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                  <option value="13">13</option>
                  <option value="14">14</option>
                  <option value="15">15</option>
                  <option value="16">16</option>
                  <option value="18">18</option>
                  <option value="19">19</option>
                  <option value="20">20</option>
                  <option value="21">21</option>
                  <option value="22">22</option>
                  <option value="23">23</option>
                  <option value="24">24</option>
                  <option value="25">25</option>
                  <option value="26">26</option>
                  <option value="27">27</option>
                  <option value="28">28</option>
                  <option value="29">29</option>
                  <option value="30">30</option>
                  <option value="31">31</option>
                </select>
              </div>

            <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Month</label>
                <select class="form-control" id="set_month">
                   <option value="0">Select</option>
                  <option value="Jan">January</option>
                  <option value="Feb">February</option>
                  <option value="Mar">March</option>
                  <option value="Apr">April</option>
                  <option value="May">May</option>
                  <option value="Jun">June</option>
                  <option value="Jul">July</option>
                  <option value="Aug">August</option>
                  <option value="Sep">September</option>
                  <option value="Oct">October</option>
                  <option value="Nov">November</option>
                  <option value="Dec">December</option>
                </select>
              </div>
             
              <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Day After</label>
               <input  type="text" id="day_after" name="day_after" placeholder="After 15 day " class="form-control" >
              </div>
              <div class="form-group col-md-3">
                <label for="exampleFormControlSelect1">Set Time</label>
                <input value="00:00" id="set_time" type="time" class="form-control" >
              </div>
            </div>

              <div style="padding-left: 20px;">
              <!-- <input type="checkbox" value="1" id="activate" class="form-check-input" checked="" id="exampleCheck1">
             <label class="form-check-label" for="exampleCheck1">Activate Trigger</label>-->
            </div>

          <button type="submit"  class="btn btn-sm float-right btn-primary">Save</button>
            
          </div>
        </div>

       


      </ul>
    </div>

                    </div>
                  </div>
                  </div>
                </div>
              </div>
            </div>
                        </div>
                  </div>
                  </div>
                </div>
              </div>
</div>
<script type="text/javascript">
  $('select').selectpicker();
</script>

<script type="text/javascript">
  $(".settag_field").on('click', function() {
    var caretPos = document.getElementById("txt").selectionStart;
    var textAreaTxt = $("#txt").val();
    var txtToAdd = $(this).closest('.settag_field').text();
      var txtToAdd = $.trim(txtToAdd);

    $("#txt").val(textAreaTxt.substring(0, caretPos) + "#"+txtToAdd+"#" + textAreaTxt.substring(caretPos) );
});
</script>


<?php } ?>