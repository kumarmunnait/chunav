<?php
include_once '../lib/session.php';
include_once '../lib/database.php';
//include_once 'lib/user.php';
include_once '../lib/db_config.php';
$User_id=$_SESSION['userid'];
$form_trigger_id=base64_decode($_GET['formid']);
$db = new database();
 $query ="select * from set_trigger where tigger_user_id=$User_id and form_id_for_trigger=$form_trigger_id";
$trigger_list = $db->execute_query($query);

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Coupon Dashboard</title>
    <?php include_once '../inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once '../inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once '../inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800"> Trigger </h1> 
              
            </div>
            <div class="row">

              <div class="col-lg-12">
                <!-- Dropdown Card Example -->
                <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary"> Select One Form List: </h6>
                  </div>
                  <div class="card-body">
                    <div style="" id="show-trigger" class="row justify-content-center">
           
                 <div class="col-lg-8">
                <!-- Dropdown Card Example -->
                <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Trigger Action </h6>
                  </div>
                  <!-- Card Body -->
                  <div class="card-body">
                       <div class="row">
                  
                    <div class="col-md-12">
                
                    <div class="">
                   <ul class="timeline">
                         <?php
                          if($trigger_list== false) {
                             echo "<div class='text-center alert alert-danger'> No Record </div>";
                            }
                            else{
                        while($row = $trigger_list->fetch_array()): ?>

                            <li>
                              <a class="trigger-title" href="#">  <?php echo $row['tigger_name'] ?></a>
                              <a href="edit-custom-trigger.php?formid=<?php echo base64_encode($row['id']);?>&&triggerid=<?php echo base64_encode($row['id'])?>" class="float-right">Edit </a>
                              <p> <?php echo $row['trigger_message'] ?></p>
                               <div class="footer-time-line">
                                <a href="#">
                                  Channel : <span> <?php echo $row['channel'] ?></span></a> <a href="#">
                                  </a>
                                 <a href="#">
                                  Date : <span> <?php echo $row['created_date'] ?></span></a> <a href="#">
                                  </a>

                                   <a href="#">
                                  Time : <span> <?php echo $row['set_time_ev'] ?></span></a> <a href="#">
                                  </a>
                                  <div class="">
                                  <a href="#"> Day : <?php echo $row['week_day'] ?> </a>
                                </div>
                              </div>
                            </li> 
                        <?php endwhile; } ?>

                      </ul>
                      
                    
              </div>

                    </div>
                  </div>
                  </div>
                </div>
              </div>
            </div>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
            
            
            
            
            <!-- End of Main Content -->
            <?php include_once '../inc/footer.php'; ?>
            <!-- Show/hide CSV upload form -->
            
          </body>
        </html>