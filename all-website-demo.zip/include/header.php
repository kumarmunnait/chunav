  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Libraries CSS Files -->
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="lib/magnific-popup/magnific-popup.css" rel="stylesheet">
  <link rel="icon" href="img/febicons.png" type="image/x-icon">
  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">
</head>

<body>

 <!--==========================
    Header
  ============================-->
  <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">
        <h1><a href="index" class="scrollto"><img src="img/logo.png"> </a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="#intro"><img src="img/logo.png" alt="" title=""></a> -->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="http://mybase.in/#intro">Home</a></li>
          <li><a href="http://mybase.in/#about">About Us</a></li>
          <li><a href="http://mybase.in/#features">Features</a></li>
          <li><a href="http://mybase.in/#pricing">Pricing</a></li>
          <li><a href="http://mybase.in/#contact">Contact Us</a></li>
          <li style="background: #fff;font-style: italic;" class="menu-has-children"><a style="color: #000" href="request-demo">Request For Demo</a></li>
          <?php if(empty($_SESSION['auser_name'])){ ?>
          <li class="menu-has-children"><a href="login">Login</a>
          <?php }else{ ?>
           <li class="menu-has-children"><a href="dashboard/home">Dashboard</a>
           <li class="menu-has-children"><a href="logout">Logout</a>
          <?php } ?>
          </li>
      
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->