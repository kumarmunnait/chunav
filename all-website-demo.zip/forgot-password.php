<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>MyBase - Reset Password </title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">
  <?php include('include/header.php')?>
  <main id="main">

    <!--==========================
      Call To Action Section
    ============================-->
    <section style="background: #4E73DF;" id="call-to-action">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center text-lg-center">
            <h3 class="cta-title mt-5">Forgot Your Password? </h3>
            <p class="cta-text"> We get it, stuff happens. Just enter your email address below and we'll send you a link to reset your password!</p>
          </div>
        </div>

      </div>
    </section><!-- #call-to-action -->

    <!--==========================
      More Features Section
    ============================-->
    <section id="more-features" class="section-bg">
      <div class="container">

        <div class="row justify-content-center">

          <div class="col-lg-5">
            <div class="box">
              <div class="login_title">
              <span>Forgot your username or password?</span>
              </div>
              <div class="text-center mb-2">
          <small>Enter your register  Phone No and we'll send you a link to reset your password.</small>
            </div>
              <form id="reset_password" action="" method="post" role="form" class="contactForm">
              
                  <div class="form-group">
                    <i class='fa fa-id-card'></i>
                    <input type="tel" name="name" required="" id="reset_password_mobile" class="form-control" id="name" placeholder="Enter Your Registered Mobile No">
                  </div>

               <div class="form-group">
                   <div id="msgbox" style="display:none;margin-top:5px;text-align: center;"></div>
               </div>

                <div class="text-center mt-3">
                  <button class="contact-custome btn" type="submit" title="Send Message">Send</button>
                </div>
              </form>

              <div class="mt-2" id="messagerest" style="text-align: center;display: none;">
                 <small> A password reset link was sent to your register mobile no. Click the link in the meaage to create a new password.</small>
                </div>

            </div>
          </div>
        </div>
      </div>
    </section><!-- #more-features -->

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/magnific-popup/magnific-popup.min.js"></script>
  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

<script>
 $(document).ready(function(){
    $("#reset_password").submit(function(){
        $("#msgbox").removeClass().addClass('alert alert-info').text('Reset Link Sending...').fadeIn(1000);
        $.post("ajax/ajax_reset_password.php",{ 
          reset_password_mobile:$('#reset_password_mobile').val(),
          key:Math.random() } 
          ,function(data){
          var data=data.trim();
          console.log(data);
          if(data=='sendlink') //if correct login detail
          {
            $("#msgbox").fadeTo(200,0.1,function()  //start fading the messagebox
            { 
              $(this).html('Reset Link Sent Successfully').addClass('alert alert-info').fadeTo(900,1,
              function()
              { 

               $("#loginbtn").hide();
               $("#messagerest").show();

              });
              
            });
          }else if(data=='error') //if correct login detail
          {
            $("#msgbox").fadeTo(200,0.1,function()  //start fading the messagebox
            { 
              $(this).html('Something is wrong please call to customer care no').addClass('alert alert-danger').fadeTo(900,1,
              function()
              { 
                 exit();
              });
              
            });
          }else{
            
              $("#msgbox").removeClass().text('').fadeIn(1000);
      }
                
        });
        return false; //not to post the  form physically
    });
});
 
 </script>



</body>
</html>
