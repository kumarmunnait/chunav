<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Login</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">
  <?php include('include/header.php')?>
<style type="text/css">
  body{
    background:#4e73dd;
  }
</style>
  <main id="main">

    <!--==========================
      Call To Action Section
    ============================-->
    <section style="background: #4c71dde0;" id="call-to-action">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center text-lg-center">
            <h3 class="cta-title mt-5">Welcome Back!  </h3>
            <p class="cta-text"> Login here to access.</p>
          </div>
        </div>

      </div>
   

        <div class="row justify-content-center">

          <div class="col-lg-4">
            <div class="box">
              <div class="text-center mb-3">
         
            </div>
               
              
                <form id="login_form" name="login_form" role="form" action="#" class="contactForm">
              
                  <div class="form-group">
                    <input type="text" name="username" class="form-control" id="username" placeholder="Please enter User Id or Mobile No">
                    <div class="validation"></div>
                  </div>
                  <div class="form-group">
                    <input type="password" class="form-control" name="email" id="password" placeholder="Enter Your Password">
                    <div class="validation"></div>
                  </div>
                  <div class="form-group" id="otpdiv" style="display:none;">
                    <input type="number" class="form-control" name="otp" id="otp" placeholder="Enter 6 Digit OTP">
                    <div class="validation"></div>
                  </div>
               <div class="form-group">
                   <div id="msgbox" style="display:none;margin-top:5px;text-align: center;"></div>
               </div>
            
                <div class="text-center" id="loginbtn"><button class="contact-custome btn" type="submit" title="Send Message">Login</button></div>
                </form>
                 <div class="text-center" id="otpbtn" style="display:none;"><button class="contact-custome btn" onclick="submit_otp();" title="Send Message">Submit</button></div>
              

            </div>
          </div>
        </div>
      </div>
    </section><!-- #more-features -->

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/magnific-popup/magnific-popup.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>


<script>
 $(document).ready(function(){
    $("#login_form").submit(function(){
        $("#msgbox").removeClass().addClass('alert alert-info').text('Checking Login Credential').fadeIn(1000);
        $.post("ajax/ajax_login.php",{ user_name:$('#username').val(),password:$('#password').val(),rand:Math.random() } ,function        (data){
          var data=data.trim();
          console.log(data);
          if(data=='yes') //if correct login detail
          {
            $("#msgbox").fadeTo(200,0.1,function()  //start fading the messagebox
            { 
              $(this).html('<i class="fa fa-circle-o-notch fa-spin" style="font-size:24px"></i> Wating For OTP ').addClass('alert alert-info').fadeTo(900,1,
              function()
              { 
                 //document.location='otp-verify.html';
				 
				 $("#otpdiv").show();
				 $("#loginbtn").hide();
				 $("#otpbtn").show();
              });
              
            });
          }else if(data=='yes1') //if correct login detail
          {
            $("#msgbox").fadeTo(200,0.1,function()  //start fading the messagebox
            { 
              $(this).html('Success Login').addClass('alert alert-success').fadeTo(900,1,
              function()
              { 
                 document.location='dashboard/home';
              });
              
            });
          }else if(data=='no'){
            $("#msgbox").fadeTo(200,0.1,function() //start fading the messagebox
            { 
              $(this).html('Your Userid or Password is Wrong').addClass('alert alert-danger').fadeTo(900,1);
            });     
          }else{
             // alert(data);
           	  $("#msgbox").removeClass().text('').fadeIn(1000);
		  }
                
        });
        return false; //not to post the  form physically
    });
    /*$("#password").blur(function()
    {
        $("#login_form").trigger('submit');
    });*/
});
 
 // otp check
 
  function submit_otp(){
        $("#msgbox").removeClass().addClass('messagebox').text('Validating....').fadeIn(1000);
        $.post("ajax/ajax_login_verifyotp.php",{ otp:$('#otp').val(),rand:Math.random() } ,function(data){
          var data=data.trim();
          console.log(data);
          if(data=='yes') //if correct login detail
          {
            $("#msgbox").fadeTo(200,0.1,function()  //start fading the messagebox
            { 
              $(this).html('OTP Success').addClass('alert alert-success').fadeTo(900,1,
              function()
              { 
                 document.location='dashboard/home';
              });
              
            });
          }else if(data=='no'){
            $("#msgbox").fadeTo(200,0.1,function() //start fading the messagebox
            { 
              $(this).html(' Invalid OTP , Retry Again ').addClass('alert alert-danger').fadeTo(900,1);
            });     
          }else{
              alert(data);
           	  $("#msgbox").removeClass().text('').fadeIn(1000);
		  }
                
        });
        return false; //not to post the  form physically
    } 
 
 
</script>
</body>
</html>
