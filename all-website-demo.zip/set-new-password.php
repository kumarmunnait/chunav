<?php
include_once './dashboard/lib/database.php';
include_once './dashboard/lib/db_config.php';
$db = new database();
$userid=$_GET['userid'];
$userid=base64_decode($userid);
$sql="SELECT * FROM users WHERE id='".$userid."' and status='1'";
$result=$db->execute_query($sql);
$numrows=$result->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>MyBase - Reset New Password </title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">
  <?php include('include/header.php')?>
  <main id="main">
    <section style="background: #4E73DF;" id="call-to-action">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center text-lg-center">
            <h3 class="cta-title mt-5">Rest Your Password? </h3>
            <p class="cta-text"> You can change your password for security reasons or reset it if you forget it. Your MyBase Account password is used to access many marketing Automation tools,  products and services.</p>
          </div>
        </div>

      </div>
    </section><!-- #call-to-action -->

    <!--==========================
      More Features Section
    ============================-->
    <section id="more-features" class="section-bg">
      <div class="container">

        <div class="row justify-content-center">

          <div class="col-lg-5">
            <div class="box">
                <?php
                    if($numrows>0) {
                    $row=$result->fetch_assoc();
                    $rest_password_status=$row['rest_password_status'];
                    if($rest_password_status==0){
                      echo "<div class='alert alert-danger' role='alert'>
                        Invalid URL, Somthing Is Wrong 
                      </div>";
                    }
                    }else{
                      echo "<div class='alert alert-warning' role='alert'>
                            Somthing Is Wrong call To Customer Care
                    </div>";
                    }
                ?>

              <div class="login_title">
              <span>Create New Password</span>
              </div>
             
              <form id="new_reset_password" action="" method="post" role="form" class="contactForm">
               <input type="hidden" name="key" id="key" value="<?php echo $_GET['key']?>" />
               <input type="hidden" name="userid" id="userid" value="<?php echo $_GET['userid']?>" />

                  <div class="form-group">
                    <i class='fa fa-lock'></i>
                    <input type="text" name="name" required="" id="newpassword" class="form-control" id="name" placeholder="Enter Your New Password">
                  </div>

                 <div class="form-group">
                    <i class='fa fa-lock'></i>
                    <input type="text" name="name" required="" id="newpassword_confirm" class="form-control" id="name" placeholder="Confirm New Password">
                  </div>

               <div class="form-group">
                   <div id="msgbox" style="display:none;margin-top:5px;text-align: center;"></div>
               </div>

                <div class="text-center mt-3">
                  <button class="contact-custome btn" type="submit" title="Send Message">Send</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section><!-- #more-features -->

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/magnific-popup/magnific-popup.min.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>
<script>
 $(document).ready(function(){
    $("#new_reset_password").submit(function(){
        $("#msgbox").removeClass().addClass('alert alert-info').text('Reseting Your Password...').fadeIn(1000);
        $.post("ajax/ajax_new_reset_set.php",{ 
          newpassword:$('#newpassword').val(),
          userid:$('#userid').val(),
          key:$('#key').val(),
          newpassword_confirm:$('#newpassword_confirm').val()
           } 
          ,function(data){
          var data=data.trim();
          console.log(data);
          if(data=='passwordError') //if correct login detail
          {
            $("#msgbox").fadeTo(200,0.1,function()  //start fading the messagebox
            { 
              $(this).html('The new password and confirmation password do not match.').addClass('alert alert-danger').fadeTo(900,1,
              function()
              { 

               $("#loginbtn").hide();
               $("#messagerest").show();

              });
              
            });
          }else if(data=='error') //if correct login detail
          {
            $("#msgbox").fadeTo(200,0.1,function()  //start fading the messagebox
            { 
              $(this).html('Something is wrong please call to customer care no').addClass('alert alert-danger').fadeTo(900,1,
              function()
              { 
                 exit();
              });
              
            });
          }else{
            
              $("#msgbox").removeClass().text('').fadeIn(1000);
      }
                
        });
        return false; //not to post the  form physically
    });
});
 
 </script>



</body>
</html>
