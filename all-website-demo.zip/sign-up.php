<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Best Political Campaign Software | Datagen</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">
  <?php include('include/header.php')?>
  <main id="main">
    <section style="background: #4E73DF;" id="call-to-action">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center text-lg-center">
            <h3 class="cta-title mt-5">Sign Up</h3>
            <p class="cta-text"> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
          </div>
        </div>

      </div>
    </section><!-- #call-to-action -->

    <!--==========================
      More Features Section
    ============================-->
    <section id="more-features" class="section-bg">
      <div class="container">

        <div class="row justify-content-center">

          <div class="col-lg-6">
            <div class="box">
              <div class="text-center mb-5">
          <small>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua. </small>
            </div>
              <form action="" method="post" role="form" class="contactForm">
                <div class="form-row">
                  <div class="form-group col-lg-6">
                    <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
                    <div class="validation"></div>
                  </div>
                  <div class="form-group col-lg-6">
                    <input type="text" class="form-control" name="email" id="email" placeholder="Your Last Name" data-rule="email" data-msg="Your Last Name">
                    <div class="validation"></div>
                  </div>
                </div>
                 <div class="form-group">
                  <input type="text" class="form-control" name="subject" id="subject" placeholder="Enter Phone No" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject">
                  <div class="validation"></div>
                </div>
                 <div class="form-group">
                  <input type="email" class="form-control" name="subject" id="subject" placeholder="Email Address" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject">
                  <div class="validation"></div>
                </div>
                 <div class="form-group">
                  <input type="text" class="form-control" name="subject" id="subject" placeholder="Company Name" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject">
                  <div class="validation"></div>
                </div>


                    
                  <div class="form-group">
                   <select class="form-control">
                     <option>Call Time and Slot</option>
                     <option>Call Me Any Time </option>
                     <option>Call Me after 10 o'clock </option>
                     <option>Call Me After Noon </option>
                     <option>Call Me In Evening </option>
                   </select>
                  </div>
                
                <div class="form-group mt-2">
                  <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message" spellcheck="false"></textarea>
                  <div class="validation"></div>
                </div>

                <div class="text-center mt-5"><button class="contact-custome btn" type="submit" title="Send Message">Send</button></div>
              </form>

            </div>
          </div>
        </div>
      </div>
    </section><!-- #more-features -->

 

 <?php include('include/footer.php')?>

</body>
</html>
