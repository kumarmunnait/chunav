<?php
include_once '../dashboard/lib/database.php';
include_once '../dashboard/lib/db_config.php';

$key=$_POST['key'];
$userid=$_POST['userid'];
$userid=base64_decode($userid);
$newpassword=$_POST['newpassword'];
$newpassword_confirm=$_POST['newpassword_confirm'];
$db = new database();
if($newpassword==$newpassword_confirm){
	$update_password="UPDATE users SET password='".$newpassword_confirm."', rest_password_status='0' WHERE id=".$userid."";
	$reset_query_result=$db->execute_query($update_password);


}else{
 	echo "passwordError";
}



?>