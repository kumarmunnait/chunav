<?php
include_once '../dashboard/lib/database.php';
include_once '../dashboard/lib/db_config.php';
 
$reset_password_mobile=$_POST['reset_password_mobile'];
$key=$_POST['key'];
$key=base64_encode($key);
$db = new database();

$sql="SELECT * FROM users WHERE mobile='".$reset_password_mobile."' and status='1'";
$result=$db->execute_query($sql);
$numrows=$result->num_rows;
if($numrows>0) {
	echo "sendlink";
	$reset_query="UPDATE users SET reset_key='".$key."', rest_password_status='1' WHERE mobile=".$reset_password_mobile."";
	$reset_query_result=$db->execute_query($reset_query);
	$row=$result->fetch_assoc();
    $suer_id=$row['id'];
    $suer_id=base64_encode($suer_id);
    $name=$row['name'];
    $resrt_url="http://mybase.in/set-new-password.php?key=$key&&userid=$suer_id";
	$msg="Dear ".$name.", We have received a password reset request. Click link to reset password ".$resrt_url."";
	$resetMessage = urlencode($msg);
	$resetlink = SendResetLink($reset_password_mobile,$resetMessage); 


}
else{
	echo "error";
}

// send reset link 
function SendResetLink($mobile,$message_staff){
$sender ='ACCOTP';
$auth='D!~1988aJRF9l2ZcJ';
$hostUrl = 'https://global.datagenit.com/API/sms-api.php?auth='.$auth.'&msisdn='.$mobile.'&senderid='.$sender.'&message='.$message_staff.'';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $hostUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_POST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0); // change to 1 to verify cert
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
//curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
$resetlink = curl_exec($ch);
return $resetlink;
}	

// send reset link 




?>