<?php
include_once 'lib/session.php';
include_once 'lib/user.php';
include_once 'lib/db_config.php';
$User_id=$_SESSION['userid'];
$db = new user();
$query ="select * from users where id=$User_id";
$profile = $db->profile($query);


?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Coupon Dashboard</title>
    <?php include_once 'inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once 'inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once 'inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">  Profile Details   </h1> <a href="create-server-form" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">Edit Details</a>
              
            </div>
            <div class="row">
              
              <div class="col-lg-6">
                <!-- Dropdown Card Example -->
                <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Personal Detail </h6>
                  </div>
                  <!-- Card Body -->
                  <div class="card-body">
                  <div class="row">
                    <div class="col-md-3">
                      
                      <img class="img-fluid" src="img/profilepic.png">

                    </div>
                    <div class="col-md-9">
                      <ul class="list-group profile-details">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                           Name : <strong><?php echo $profile['name'];?></strong>
                         
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                          Joining Date : <strong><?php echo $profile['created_date'];?></strong>
                         
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                         Status : <?php if($profile['status']==1) 
                          echo "<span class='badge badge-primary badge-pill'>Active</span>";
                          else{
                            echo "<span class='badge badge-danger badge-pill'>Inactive</span>";
                          }
                         ?>

                
                         
                        </li>
                      </ul>

                    </div>
                  </div>
                    
                  </div>
                </div>
              </div>
              <div class="col-lg-6">
                <!-- Dropdown Card Example -->
                <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Contact Detail</h6>
                    
                  </div>
                  <!-- Card Body -->
                  <div class="card-body">
                    
                     <div class="row">
                    <div class="col-md-12">
                     <ul class="list-group profile-details">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                           Mobile : <strong><?php echo $profile['mobile'];?></strong>
                         
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                          Email : <strong><?php echo $profile['email'];?></strong>
                         
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                          Orgination : <strong><?php echo $profile['organization'];?></strong>
                         
                        </li>
                      </ul>

                    </div>
                   
                  </div>
                    
                  </div>
                </div>
              </div>
              <div class="col-lg-12">
                <!-- Dropdown Card Example -->
                <div class="card shadow mb-4">
                  <!-- Card Header - Dropdown -->
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Bank Detail </h6>
                    <span class="edit-title"><i class="fas fa-plus-square"></i>  Add Bank Details</span>
                  </div>
                  <!-- Card Body -->
                  <div class="card-body">
                       <div class="row">
                  
                    <div class="col-md-12">
                      <ul class="list-group profile-details">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                           Bank Name : <strong>NA</strong>
                         
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                          Account Name : <strong>NA</strong>
                         
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                          IFSC Code : <strong>NA</strong>
                      
                      </ul>

                    </div>
                  </div>
                 
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        
        
        
        <!-- End of Main Content -->
        <?php include_once 'inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
        
      </body>
    </html>