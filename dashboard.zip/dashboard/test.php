<?php
header( "refresh:5;url=wherever.php" );
?>