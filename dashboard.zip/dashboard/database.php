<?php 

class database {

	public $host =DB_SERVER;
	public $user =DB_USERNAME;
	public $password =DB_PASSWORD;
	public $db_name =DB_DATABASE;

	public $link;
	public $error;


	public function __construct(){
		$this->connect();
	}

	private function connect() {

		$this->link = new mysqli($this->host,$this->user,$this->password,$this->db_name);



	}


}


?>