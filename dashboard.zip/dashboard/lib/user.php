<?php 



class user {

	public $host =DB_SERVER;
	public $user =DB_USERNAME;
	public $password =DB_PASSWORD;
	public $db_name =DB_DATABASE;

	public $link;
	public $error;

	public function __construct(){
		$this->connect();
	}

	private function connect() {

		$this->link = new mysqli($this->host,$this->user,$this->password,$this->db_name);

		if(!$this->link){
			$this->error ="coonection Faild".$this->link->connect_error;
		}



	}




	public function profile ($query) {
		$result = $this->link->query($query);
		if($result->num_rows > 0){
				$row = $result->fetch_assoc();
			return $row ;
		}
		else{
			return false;
		}
	}

	



    	

	
	

	




}


?>