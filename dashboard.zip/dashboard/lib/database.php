<?php 



class database {

	public $host =DB_SERVER;
	public $user =DB_USERNAME;
	public $password =DB_PASSWORD;
	public $db_name =DB_DATABASE;

	public $link;
	public $error;

	public function __construct(){
		$this->connect();
	}

	private function connect() {

		$this->link = new mysqli($this->host,$this->user,$this->password,$this->db_name);

		if(!$this->link){
			$this->error ="coonection Faild".$this->link->connect_error;
		}



	}




	public function form_title ($query) {
		$result = $this->link->query($query);
		if($result->num_rows > 0){
			return $result;
		}
		else{
			return false;
		}
	}

	public function create_table ($query) {
		$result = $this->link->query($query);
		if($result){
			return true;
		}
		else{
			return false;
		}
	}



	public function form_list ($query) {
		$result = $this->link->query($query);
		if($result->num_rows > 0){
			return $result;
		}
		else{
			return false;
		}
	}



	public function select ($query) {
		$result = $this->link->query($query);
		if($result->num_rows > 0){
			return $result;
		}
		else{
			return false;
		}
	}


	public function ftch_new_table_details ($query) {
		$result = $this->link->query($query);
		if($result->num_rows > 0){
			return $result;
		}
		else{
			return false;
		}
	}



	public function insert ($query) {
		$result = $this->link->query($query);
		if($result){
			return "Record Inserted";
		}
		else{
			return false;
		}
	}


	public function getfullname ($query) {
		$result = $this->link->query($query);
		if($result->num_rows > 0){

			$row = $result->fetch_assoc();
            $name= $row['name'];

			return $name;
		}
		else{
			return false;
		}
	}


	public function get_table_name ($query) {
		$result = $this->link->query($query);
		if($result->num_rows > 0){
			return $result;
		}
		else{
			return false;
		}
	}

	



    	

	
	

	




}


?>