<?php
include_once '../lib/session.php';
include_once '../lib/db_config.php';
include_once '../lib/database.php';
$db = new database();
$User_id=$_SESSION['userid'];
$formname=$_POST['form_name'];
$formdata=$_POST['form_data'];
$formfileds=$_POST['form_fileds'];
$formfiled = implode(",", $formfileds);
$date = date('Y-m-d H:i:s');
$form_date=date('YmdHis');
$data ="";

foreach( $formfileds  as $value ) {
           $data .= "`".trim($value)."` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,";

         }

          $data;
          $table_name ="form_uid".$User_id."_".$form_date;
			$datahtml = $data;

			  $create_table=" CREATE TABLE `$table_name`(
			  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
			   $datahtml
				  `created_date` timestamp NULL DEFAULT current_timestamp(),
  				`updated_date` timestamp NOT NULL DEFAULT current_timestamp()
			 
			)";


   $create_table = $db->create_table($create_table);


	if($create_table==true) {
			 $query="INSERT INTO tbl_forms (name, form_fields, user_id, form_html, form_table_name, 	form_url,created_date)
		VALUES ('$formname','$formfiled','$User_id', '$formdata', '$table_name', 'NA', '$date');";

		   $insert = $db->insert($query);
		 	if($insert){
		 		echo 1;
		 	} 
		 	else{
		 		echo 2;
		 	}


	}
	else{
		 echo "tabel already Exist";
	}



?>