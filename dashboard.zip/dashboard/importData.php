<?php
// Load the database configuration file
include_once 'dbConfig.php';

if(isset($_POST['importSubmit'])){
    
    // Allowed mime types
    $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
    
    // Validate whether selected file is a CSV file
    if(!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'], $csvMimes)){
        
        // If the file is uploaded
        if(is_uploaded_file($_FILES['file']['tmp_name'])){
            
            // Open uploaded CSV file with read-only mode
            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
            
            // Skip the first line
            fgetcsv($csvFile);
            
            // Parse data from CSV file line by line
            while(($line = fgetcsv($csvFile)) !== FALSE){
                // Get row data
                $Title   = $line[0];
                $Merchant  = $line[1];
                $Categories  = $line[2];
                $Description = $line[3];
                $Coupon_Code =$line[4];
                $URL = $line[5];
                $Deal_Status = $line[6];
                $Start_Date = $line[7];
                $End_Date = $line[8];
                $Offer_Added_At = $line[9];
                $Image_URL = $line[10];
                $Campaign_Name = $line[11];
                $Status =$line[12];


                // Check whether member already exists in the database with the same email
                $prevQuery = "SELECT id FROM deals_and_coupon  WHERE Title = '".$line[0]."'";
                $prevResult = $db->query($prevQuery);
                
                if($prevResult->num_rows > 0) {
                    // Update member data in the database
                    $db->query("UPDATE deals_and_coupon SET Title = '".$Title."', Merchant = '".$Merchant."', Categories = '".$Categories."',  Description = '".$Description."',  Coupon_Code = '".$Coupon_Code."', URL = '".$URL."', Deal_Status = '".$Deal_Status."', Start_Date = '".$Start_Date."', End_Date = '".$End_Date."', Offer_Added_At = '".$Offer_Added_At."', Image_URL = '".$Image_URL."', Campaign_Name = '".$Campaign_Name."', status = '".$Status."', modified = NOW() WHERE Title = '".$Title."'");
                } else {
                    // Insert member data in the database
                    $db->query("INSERT INTO deals_and_coupon (Title,   Merchant,    Categories,  Description, Coupon_Code, URL, Deal_Status, Start_Date,  End_Date,   Offer_Added_At,  Image_URL,   Campaign_Name ,  created, modified,   status) VALUES ('".$Title."', '".$Merchant."', '".$Categories."','".$Description."','".$Coupon_Code."','".$URL."','".$Deal_Status."','".$Start_Date."','".$End_Date."','".$Offer_Added_At."','".$Image_URL."', '".$Campaign_Name."', NOW(), NOW(), '".$Status."')");
                }
            }



            
            // Close opened CSV file
            fclose($csvFile);
            
            $qstring = '?status=succ';
        }else{
            $qstring = '?status=err';
        }
    }else{
        $qstring = '?status=invalid_file';
    }
}

// Redirect to the listing page
header("Location: deals-and-coupon".$qstring);