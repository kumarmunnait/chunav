<?php
include_once 'lib/session.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Coupon Dashboard</title>
    <?php include_once 'inc/style.php'; ?>
  </head>
  <body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
      <!-- Sidebar -->
      <?php include_once 'inc/side_menu.php'; ?>
      <!-- End of Sidebar -->
      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
          <!-- Topbar -->
          <?php include_once 'inc/header.php'; ?>
          <!-- End of Topbar -->
          <!-- Begin Page Content -->
          <div class="container-fluid">
            <!-- Page Heading -->

            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">  Edit Agent   </h1> <a href="create-server-form" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">Add New Agent</a>
             
            </div>

          <div class="row">

          

          
            <div class="col-lg-12">

      


              <!-- Progress Small -->
              <div class="card mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">List Of Agents</h6>
                </div>
                <div class="card-body">

                  <div class="row">
                      <div class="col-md-9">
                         <div class="mb-1 ">Normal Progress Bar</div>
              
                 
                      </div>                    
                      <div class="col-md-3">
                        <a href="#" class="btn mt-2 btn-primary btn-block btn-icon-split btn-sm">
                   
                    <span class="text">Edit Agent</span>
                  </a>
                      </div>                    

                  </div>
                  <hr>
               

                          <div class="row">
                      <div class="col-md-9">
                         <div class="mb-1 ">Normal Progress Bar</div>
               
                 
                      </div>                    
                      <div class="col-md-3">
                        <a href="#" class="btn mt-2 btn-success btn-block btn-icon-split btn-sm">
                   
                    <span class="text">Edit Agent</span>
                  </a>
                      </div>                    

                  </div>
<hr>
                          <div class="row">
                      <div class="col-md-9">
                         <div class="mb-1 ">Normal Progress Bar</div>
                
                 
                      </div>                    
                      <div class="col-md-3">
                        <a href="#" class="btn mt-2 btn-info btn-block btn-icon-split btn-sm">
                   
                    <span class="text">Edit Agent</span>
                  </a>
                      </div>                    

                  </div>

                          

                </div>
              </div>


            </div>


          </div>
           
           
          </div>
        </div>
        <!-- End of Main Content -->
        <?php include_once 'inc/footer.php'; ?>
        <!-- Show/hide CSV upload form -->
    
      </body>
    </html>