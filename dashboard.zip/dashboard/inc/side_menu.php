<?php $active = $_SERVER["PHP_SELF"]; ?>
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
<!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="home">
  
    <div class="sidebar-brand-text mx-3"><img src="img/logo-white.png"></div>
    </a>
    <!-- Divider -->
    <hr class="sidebar-divider my-0">
<!-- Nav Item - Dashboard -->

    <li <?php if (strpos($active, 'home.php') !== false){echo 'class="nav-item active"';}else {
      echo 'class="nav-item"';}?>> 
    <a class="nav-link" href="home">
    <i class="fas fa-fw fa-tachometer-alt"></i>
    <span>Dashboard</span></a>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
    Create and Add
    </div>
    <!-- Nav Item - Pages Collapse Menu -->
    <li <?php if (strpos($active, 'create-server-form.php') !== false){echo 'class="nav-item active"';} else {
      echo 'class="nav-item"';

    }?>>
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
    <i class="fas fa-fw fa-folder"></i>
    <span>Survey Form</span>
    </a>
    <div id="collapsePages" <?php if (strpos($active, 'create-server-form.php') !== false or strpos($active, 'survey-form-list.php') !== false){echo 'class="collapse show"';} else {
      echo 'class="collapse"';

    }?> aria-labelledby="headingPages" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Create Server Form</h6>
      <a class="collapse-item" href="create-server-form">New Survey Form</a>
      <a class="collapse-item" href="survey-form-list">Survey List</a>
    </div>
    </li>
    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages1" aria-expanded="true" aria-controls="collapsePages1">
      <i class="fas fa-fw fa-folder"></i>
      <span>Agent</span>
    </a>
    <div id="collapsePages1" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
      <div class="bg-white py-2 collapse-inner rounded">
        <h6 class="collapse-header">Agent Add / Edit </h6>
        <a class="collapse-item" href="add-server">New Agent</a>
        <a class="collapse-item" href="edit-agent">Edit Agent</a>
        
      </div>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">
    <!-- Heading -->
    <div class="sidebar-heading">
      View Collected data
    </div>
      <!-- Nav Item - Charts -->

    <!-- Nav Item - Charts -->
    <li class="nav-item">
      <a class="nav-link" href="list-of-server">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>   List Of Server </span></a>
      </li>
    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages2" aria-expanded="true" aria-controls="collapsePages2">
        <i class="fas fa-fw fa-folder"></i>
        <span>SMS Setting</span>
      </a>
      <div id="collapsePages2" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
          <h6 class="collapse-header"> SMS Setting / Trigger </h6>
          <a class="collapse-item" href="add-server"> SMS Trigger </a>
          <a class="collapse-item" href="edit-agent"> Send Bulk SMS </a>
          <a class="collapse-item" href="edit-agent"> Add More Phone </a>
          
        </div>
      </li>



 <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">
    <!-- Heading -->
    <div class="sidebar-heading">
      My Account
    </div>
      <!-- Nav Item - Charts -->
    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages4" aria-expanded="true" aria-controls="collapsePages3">
        <i class="fas fa-fw fa-folder"></i>
        <span>Account Setting</span>
      </a>
      <div id="collapsePages4" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
          <h6 class="collapse-header"> Profile </h6>
          <a class="collapse-item" href="profile-details">Profile Details </a>  
          <a class="collapse-item" href="change-password">Change Password </a>  
        </div>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">
      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>
</ul>