<?php session_start();
if(empty($_SESSION['auser_name']))
    header("Location:index.php");   
if(isset($_GET['logout']))
{
    unset($_SESSION['auser_name']);
    header("Location:login.html");
}
include 'dbc_config.php';
$userid=$_SESSION['userid'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Dashboard</title>
    <?php include 'header-links.php';?>
 
    
</head>
<body class="hold-transition fixed sidebar-mini">

    <!-- Preloader -->
    <div class="preloader"></div>
    <!-- Site wrapper -->
    <div class="wrapper">
      <?php include 'body-header.php'; $conn=dbConnect();?>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
        <!-- Main content -->
        <div class="content">
            <div class="content-header">
                <div class="header-icon">
                    <i class="glyphicon glyphicon-envelope"></i>
                </div>
                <div class="header-title">
                    <h1>Send SMS</h1>
                    <small>A simple and user-friendly Basic form</small>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="pe-7s-home"></i> Home</a></li>
                        <li class="active">Send SMS</li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12" style="margin-top:20px;">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="error-header">
                                <div class="row"> 
                                <div id="success"></div> 
                                <div id="err"></div> 
                                    <div class="col-lg-12">
                                    <h4 class="font-size-smal" style="margin:0px; line-height:30px; padding:0px;"> <i class="glyphicon glyphicon-envelope" aria-hidden="true"></i> &nbsp; Send SMS</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">  
                            <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">
                               <form role="form" name="frm" id="frm" method="post" enctype="multipart/form-data">
                               
                                
                              <!--  <div class="form-group">
                                    <label class="col-xs-12 col-sm-6 col-md-6 col-lg-3 control-label">Campaign Name</label>
                                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-9">
                                    <input class="form-control" type="text"  name="camp_name" placeholder="Campaign Name" required>
                                    </div>
                                </div>
                                <p>&nbsp;</p>-->
                                <div class="form-group">
                                    <label class="col-xs-12 col-sm-6 col-md-6 col-lg-3 control-label">Destination Country</label>
                                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-9">
                                
             <select class="form-control"  name="seldestcountry" id="country">
              <?php 
                                                        $selgroup=mysqli_query($conn,"select * from  country_master") or die(mysqli_error($conn));
                                                        if(mysqli_num_rows($selgroup)>0){
                                                            //echo "<option value=\"\">Select Group</option>";
                                                            while($rowgroup=mysqli_fetch_assoc($selgroup)){
                                                                ?><option value="<?php echo $rowgroup['country_code']?>" <?php if($rowgroup['id']=='115'){echo 'selected';}?>><?php echo '+'.$rowgroup['country_code'].'  '.$rowgroup['country_name']?></option><?php
                                                            }
                                                        }else{
                                                            echo "<option value=\"\">Please create you first group</option>";
                                                        }?>
             </select>
                                    </div>
                                </div>
                                <p>&nbsp;</p>
                                
                                
                             
                                
                               
                                <div class="form-group">
                                    <label class="col-xs-12 col-sm-6 col-md-6 col-lg-3 control-label" for="textareaAutosize">Recipients: 
                                    
                                    </label>
                                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-9">
                                    <ul class="nav nav-tabs">
                                        <li class="active"><a href="#tabnum1" data-toggle="tab">Enter Numbers</a></li>
                                        <li><a href="#tabnum2" data-toggle="tab">Upload Numbers</a></li>
                                        <!--<li><a href="#tabnum3" data-toggle="tab">Use Phonebook</a></li>-->
                                    </ul>
                                    <!-- Tab panels -->
                                    <div class="tab-content">
                                        <div class="tab-pane fade in active" id="tabnum1">
                                            <div class="panel-body">
                                              <textarea class="form-control" id="word_count" name="txtnumbers" rows="3" placeholder="Type or paste a line separated list of your recipient phone numbers."></textarea>
                                            </div>
                                            <span style="font-size: 12px; font-weight: bold;" id="display_count">0</span>
<span style="font-size: 12px; font-weight: bold;">Total Recipients</span>
                                        </div>
                                        <div class="tab-pane fade" id="tabnum2">
                                            <div class="panel-body">
                                                <label>Upload Numbers </label>
                                                <input class="form-control" type="file" name="uploadcsv"> 
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tabnum3">
                                            <div class="panel-body">
                                                <label>Use Phonebook </label>
                                                <select class="form-control" id="selectgroup" name="selectgroup[]" multiple>
                                                <?php 
                                                        $selgroup=mysqli_query($conn,"select id,group_name from group_master where user_id=$userid and status=1") or die(mysqli_error($conn));
                                                        if(mysqli_num_rows($selgroup)>0){
                                                            //echo "<option value=\"\">Select Group</option>";
                                                            while($rowgroup=mysqli_fetch_assoc($selgroup)){
                                                                ?><option value="<?php echo $rowgroup['id']?>"><?php echo $rowgroup['group_name']?></option><?php
                                                            }
                                                        }else{
                                                            echo "<option value=\"\">Please create you first group</option>";
                                                        }?>
                                            </select>
                                            </div>
                                        </div>
                                        
                                        
                                    </div>
                                    </div>
                                </div>
                                
                                <p>&nbsp;</p>
                                <div class="form-group">
                                    <label class="col-xs-12 col-sm-6 col-md-6 col-lg-3 control-label" for="textareaAutosize">Message:<br> 
                                   
                                    		<div id='translControl'  >
     Enable Unicode: <input type="checkbox" name="unicode" value="1" id="checkboxId" onClick="javascript:checkboxClickHandler()" ></input>
     
    </div>     <input type='hidden' id="transl1"/>
                                  <!--  <select name="sellanguage" id="sellanguage" class="langusgedrop" onchange="javascript:changeLanguage(this.options[this.selectedIndex].value);" title="Choose Language">
				<option value="pramukhindic:assamese">Assamese</option><option value="pramukhindic:bengali">Bengali</option><option value="pramukhindic:bodo">Bodo</option><option value="pramukhindic:dogri">Dogri</option><option value="pramukhindic:gujarati">Gujarati</option><option value="pramukhindic:hindi">Hindi</option><option value="pramukhindic:kannada">Kannada</option><option value="pramukhindic:konkani">Konkani</option><option value="pramukhindic:maithili">Maithili</option><option value="pramukhindic:malayalam">Malayalam</option><option value="pramukhindic:manipuri">Manipuri</option><option value="pramukhindic:marathi">Marathi</option><option value="pramukhindic:nepali">Nepali</option><option value="pramukhindic:oriya">Oriya</option><option value="pramukhindic:punjabi">Punjabi</option><option value="pramukhindic:sanskrit">Sanskrit</option><option value="pramukhindic:santali">Santali</option><option value="pramukhindic:sindhi">Sindhi</option><option value="pramukhindic:tamil">Tamil</option><option value="pramukhindic:telugu">Telugu</option><option value=":english" selected="selected">English</option>			</select>-->
                <select id="languageDropDown" name="selected_language" onChange="javascript:languageChangeHandler()" class="langusgedrop" style="display:none; "> 
                </select>
                                    </label>
                                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-9">
                                      <!--  <textarea class="form-control" id="inputDisabled"  rows="8" placeholder="Type message here"></textarea>-->
                                      	<textarea name="message" maxlength="2000" id="textarea" onkeyup="funCounter();" onblur="funCounter();" onfocus="funCounter();" rows="4" class="form-control" placeholder="Message" rows="3"   ></textarea>				
                                        	 
                                        <div class="messageextra"><i class="fa fa-paperclip" aria-hidden="true"  data-toggle="modal" data-target="#modal-lg-file" title="Attachment"></i> &nbsp;&nbsp;&nbsp;&nbsp;<!--<i class="fa fa-link" data-toggle="modal" data-target="#modal-lg-url" aria-hidden="true" title="URL Shorter"></i> &nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-smile-o" data-toggle="modal" data-target="#modal-lg-url" aria-hidden="true" title="URL Shorter"></i>--></div>
                                        
                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                        <span style="font-size: 12px; font-weight: bold;" id="wcount">0</span>
    <span style="font-size: 12px; font-weight: bold;">Character Used</span>
    
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                            
                                             <!--<span id="msg">0</span> Credits-->
                                            <!-- <span id="msg1" style="display:none"> Credits</span> -->
                                             <input type="hidden" name="credit" id="credit" value=""/>
                                             <input type="hidden" name="msg_count" id="msg_count" value=""/>
                                             
                                              <input type="hidden" name="url" id="url" value=""/>
                                               <input type="hidden" name="key" id="key" value=""/>
                                               <input type="hidden" name="file_path" id="file_path" value=""/>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="form-group">
                               
                                <div class="col-xs-12 col-sm-8 col-md-12 col-lg-9">
                                    <input type="checkbox" name="remove_duplicate"  value="1"><span>&nbsp;<b>Remove Duplicate Numbers</b></span>
                                </div> 
                               
                                </div>
                                
                               <p>&nbsp;</p>
                                <div class="form-group">
                               		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" >
                                	<button type="submit" class="btn btn-cap m-r-5" id="send_sms">Send </button>&nbsp;&nbsp;&nbsp;
                                   
                                    </div>
                                  <!--  
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="sch_sms" style="display:none">
                                	<button type="submit" class="btn btn-cap m-r-5" id="sendnou">Schedule </button>&nbsp;&nbsp;&nbsp;
                                    <button class="btn btn-warning" id="btnSubmit"  data-toggle="modal" data-target="#modal-lg">Preview SMS</button>
                                    </div>-->
                                </div>
                                <img src="template/assets/dist/img/loader.gif" id="loader" style="display:none"/>
                                </form>
                           </div> 
                           
                           
                 
                           	<div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                            	<!--<div class="form-group">
                                    
                                    <ul class="nav nav-tabs">
                                        <li class="active"><a href="#tabr1" data-toggle="tab">Sample Message</a></li>
                                        <li><a href="#tabr2" data-toggle="tab">Templates</a></li>
                                        <li><a href="#tabr3" data-toggle="tab">Group</a></li>
                                    </ul>
                                    
                                    <div class="tab-content">
                                        <div class="tab-pane fade in active" id="tabr1">
                                            <div class="panel-body">
                                               samplesamplesamplesample samplesamplesample 
                                              
                                            </div>
                                            
                                        </div>
                                        <div class="tab-pane fade" id="tabr2">
                                            <div class="panel-body">
                                               template here samplesamplesamplesample samplesamplesample 
                                                
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tabr3">
                                            <div class="panel-body">
                                                group here samplesamplesamplesample samplesamplesample 
                                              
                                            </div>
                                        </div>
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>                
                </div>
            </div>
        </div><!-- end of Main content -->
    </div>
    
    <!--   Modal start Preview  -->
    <div class="modal fade" id="modal-lg" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                        <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h1 class="modal-title">SMS Preview</h1>
                        </div>
                        <div class="modal-body">
                        
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Country Code</th>
                                                    <th>Sender Id</th>
                                                    
                                                    <th>Character Count</th>
                                                    <th>Credit Count</th>
                                                </tr>
                                            </thead>
                                             <tbody>
                          <tr><td> <p id="preview-country"> </p></td><td> <p id="preview-senderid"> </p></td><td><p id="preview-count"> </p></td><td><p id="preview-credit"> </p></td></tr>
                                             </tbody>
                                             <thead>
                                                <tr>
                                                    <th colspan="4" class="text-center">Message</th>
                                                    
                                                     
                                                </tr>
                                            </thead>
                                             <tbody>
                          <tr><td colspan="4"> <p id="preview-sms" style="word-wrap: break-word;"> </p> </td></tr>
                                             </tbody>
                                        </table>
                                      
                                     
                       
                        </div>
                        <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <!--<button type="button" class="btn btn-base">Save changes</button>-->
                        </div>
                  </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
     </div>
    
     <!--   modal end-->


   
   
    
    

    <?php include 'footer.php';?>
     <!--   Modal start choose file  -->
    <div class="modal fade" id="modal-lg-file" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                
                        <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h1 class="modal-title">File Manager</h1>
                        </div>
                        <div class="modal-body"> 
                        <div class="row" id="searchresult">
                       
                         <?php
						$i=1;
$selectdata=mysqli_query($conn,"select * from message_files where user_id = '$userid' and status='1'") or die(mysqli_error($conn));
dbClose($conn);
	 while($row = mysqli_fetch_array($selectdata)){?>
                       
                            <div class="col-md-2" align="center">
                                    <a href="#" class="btn btn-base" id="addLink<?php echo $i; ?>">Insert Files</a>
                                    <div class="column">
                                    <img style="height:100px;width:50px;" src="<?php echo $row['file_path']; ?>"/><br>
                                    <?php echo $row['file_name']; ?>
                                    
                                    <input type="hidden" name="link" id="link<?php echo $i; ?>" value="<?php echo $row['url']; ?>"/>
                                     <input type="hidden" name="key1" id="key1<?php echo $i; ?>" value="<?php echo $row['key_value']; ?>"/>
                                      <input type="hidden" name="file_path1" id="file_path1<?php echo $i; ?>" value="<?php echo $row['file_path']; ?>"/>
                                    </div>
                            </div>
			<script>
			$('#addLink<?php echo $i; ?>').click(function(){
					console.log('click');
					//var link = $('#link<?php echo $i; ?>').val();
					//alert(link);
					// $("#textarea").append($('#link<?php echo $i; ?>').val());
					var txt = $.trim($('#link<?php echo $i; ?>').val());
					var txt2 = $.trim($('#key1<?php echo $i; ?>').val());
					var txt3 = $.trim($('#file_path1<?php echo $i; ?>').val());
					
					$("#url").val(txt);
					$("#key").val(txt2);
					$("#file_path").val(txt3);
					
					
					$("#textarea").val($("#textarea").val() + txt);
					
					
					
					// $("#modal-lg-file").hide();
					console.log('click append',$('#link<?php echo $i; ?>').val());
					funCounter();
					$("#modal-lg-file .close").click()
            
            });
            </script>
                         <?php  $i++; } ?>
                                            
                         </div>
                                     <!--      <table class="table table-bordered">
                                         <thead>
                                                <tr>
                                                    <th>Country Code</th>
                                                    <th>Sender Id</th>
                                                    
                                                    <th>Character Count</th>
                                                    <th>Credit Count</th>
                                                </tr>
                                            </thead>
                                             <tbody>
                          <tr><td> <p id="preview-country"> </p></td><td> <p id="preview-senderid"> </p></td><td><p id="preview-count"> </p></td><td><p id="preview-credit"> </p></td></tr>
                                             </tbody>
                                             
                                              
                                        </table>-->
                                      
                                     
                       
                        </div>
                        <div class="modal-footer">
                          <form role="form" name="frm1" id="frm1" method="post" enctype="multipart/form-data">
                        <label class="btn btn-primary" for="my-file-selector">
    <input id="my-file-selector" type="file" name="file-message" style="display:none" 
   >
   Add / Upload File
</label></form>
<!--<span class='label label-info' id="upload-file-info"></span>-->
                         <!--<button type="button" class="btn btn-base">Choose File</button> -->
                       <!-- <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>-->
                       
                        </div>
                  </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
     </div>
     
          <!--   modal end-->
  <!--   Modal start Insert URL  -->
    <div class="modal fade" id="modal-lg-url" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                
                        <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h1 class="modal-title">Insert Link</h1>
                        </div>
                        <div class="modal-body"> 
                        <div class="panel-body" id="">
                                    
                                 
                                        <div class="form-group">
                                            <label for="exampleName">Enter Your URL</label>
                                            <input type="text" name="url"  id="url_value" class="form-control" id="exampleName" aria-describedby="emailHelp" placeholder="Enter Your Name">
                                        </div>
                                       
                                        
                                         
                                         
                                        <button type="submit" class="btn btn-base pull-right" id="addUrl">Insert</button>
                                     
                                </div>
                                     <!--      <table class="table table-bordered">
                                         <thead>
                                                <tr>
                                                    <th>Country Code</th>
                                                    <th>Sender Id</th>
                                                    
                                                    <th>Character Count</th>
                                                    <th>Credit Count</th>
                                                </tr>
                                            </thead>
                                             <tbody>
                          <tr><td> <p id="preview-country"> </p></td><td> <p id="preview-senderid"> </p></td><td><p id="preview-count"> </p></td><td><p id="preview-credit"> </p></td></tr>
                                             </tbody>
                                             
                                              
                                        </table>-->
                                      
                                     
                       
                        </div>
                        <div class="modal-footer">
                          
<!--<span class='label label-info' id="upload-file-info"></span>-->
                         <!--<button type="button" class="btn btn-base">Choose File</button> -->
                       <!-- <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>-->
                       
                        </div>
                  </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
     </div>
     
          <!--   modal end-->
          
            <link rel="stylesheet" type="text/css" href="dist/emojionearea.min.css" media="screen">
    <script type="text/javascript" src="http://mervick.github.io/lib/google-code-prettify/prettify.js"></script>
 
  <script type="text/javascript" src="dist/emojionearea.js"></script>
   <!-- <script type="text/javascript">
    $(document).ready(function() {
      $("#textarea").emojioneArea({
        template: "<filters/><tabs/><editor/>"
      });
    });
  </script>-->
  
  
 <script src="template/assets/plugins/modals/classie.js"></script>
        <script src="template/assets/plugins/modals/modalEffects.js"></script>
        <script>
		 $('#addUrl').click(function(){
            
            var linkv = $('#url_value').val();
            //alert(link);
            //$('#textarea').append($('#url').val());
			var txt1 = $.trim($('#url_value').val());
		//	alert(linkv)
					$("#textarea").val($("#textarea").val() + txt1);
            // $("#modal-lg-file").hide();
			funCounter();
            $("#modal-lg-url .close").click()
            
            }); 

 
		//  for message upload file
$('input[name=file-message]').change(function(ev) {

    // your code
	console.log('click');
	  
	$.ajax({ 
					url: "ajax/ajax_upload_message_file.php",
					type: 'POST',
					data:  new FormData($('#frm1')[0]),
			        contentType: false,
			        cache: false,
					processData:false,
					beforeSend: function() {				 
					},
					success: function(data, textStatus, xhr) {
					//console.log('data',data);
					$('#loading').hide();
					$('#searchresult').html(data);
					
					},  
					error: function(xhr, textStatus, errorThrown) {
					$('#loading').hide();
					$('#searchresult').html(textStatus);
					}					
					});		
			return false;
			
	  
});
		
		//  for Message Preview
        $('#btnSubmit').click(function () {

        var textFieldVal = document.getElementById('textarea').value;
		 var senderid = document.getElementById('senderid').value;
		  var wcount = document.getElementById('wcount').value;
		   var country = document.getElementById('country').value;
		   //var credit = document.getElementById('credit').value;
	//	alert(textFieldVal);
        $('#preview-sms').html(textFieldVal);
		 $('#preview-senderid').html(senderid);
		 var credit=$('#msg').html();
		 //$('#msg').val()
		 //alert(credit);
		  $('#preview-credit').html(credit);
		   $('#preview-country').html(country);


    });
        </script>
<script>
    function toggleschedule()
	{
		if($('#schedule').css('display') == 'none'){
			$('#schedule').css('display','block');
		}else{
			$('#schedule').css('display','none');
		}
	}
	$(document).ready(function (e) {
	 $("#frm").on('submit',(function(e) {
		 console.log('click');
	 	e.preventDefault();
		$.ajax({
			url: "ajax/ajax_composesms.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
			cache: false,
			processData:false,
			beforeSend : function(){
			//$("#preview").fadeOut();
			console.log('before call');
			$("#err").fadeOut();
			 $('#loader').show();
			}, complete: function(){
        $('#loader').hide();
    },
			success: function(data){
				console.log('success call',data);	
							
				
			  if(data=='errordata'){
				  $("#success").hide();
				  $("#err").html("Please enter number or select your file!").fadeIn();					
			  }
			  else if(data !=''){
					 $("#success").hide();
				  $("#err").html(data).fadeIn();	
				  alert(data);
					  }
			  else{
				 // view uploaded file.				 
				  $("#err").hide();			
				  console.log('insert  call',data);		  
				  $("#success").html("Saved!").fadeIn();				
				  //$("#loadtable").load('loadUploadNumaber.php');		
				   alert('Message Sended Successfully');		 			 
				$("#frm")[0].reset(); 
				window.location='WEB-SMS.php';
				}
			 },
			 error: function(e){
				  console.log('error call');
					$("#err").html(e).fadeIn();
			}          
		});
	 }));
	});
	
	
	
	function block(){
		$('#selectaudio').get(0).selectedIndex = 0;
		}
    </script>
 
  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/3.2/select2.min.js"></script>
    <!-- datetime picker -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.14/jquery.datetimepicker.full.js"></script>
    <!-- end datatime-->
    <script>
	/*
	   $( function() {
    	$( "#datepicker" ).datepicker({minDate: 0});
		
 		} );*/
     $("#selectgroup").select2();
	 $(".select2-input").css('width','150px');
	 
		
		$('#datepicker').datetimepicker({
			minDate: 0,
  			//format:"Y-m-d h:i a",
			format:"Y-m-d H:i",
  			step:15
		});
		
		
		
		
		$(document).ready(function() {
  $("#word_count").on('keyup', function() {
    var words = this.value.match(/[\w\d\’\'-]+/gi).length;
	 //var words = this.value.split('/\W+/').length;

    if (words > 50000) {
      // Split the string on first 200 words and rejoin on spaces
      var trimmed = $(this).val().split(/\s+/, 200).join(" ");
      // Add a space at the end to make sure more typing creates new words
      $(this).val(trimmed + " ");
    }
    else {
      $('#display_count').text(words);
      $('#word_left').text(200-words);
    }
  });
}); 
    </script>
    
    <script type="text/javascript">
 
function placeTxtIntoBox(val)
{
	$("#textarea").val(''+val);
}
str = '';
function placeTxtIntoContacts(val)
{
	$('#groups_tags').show();
	if(val.length > 0)
	{
		if(str.indexOf(val+',') != -1)
		{
			//str='';
		}
		else
		{
			str+= val+',';
		}
		$("#textfield").val(str);
	}
	
}
function checkunicode() {
    var str = $('#textarea').val();
	// [^\w \xC0-\xFF]
	// [^\x00-\x7F]  for hindi
    var patt = new RegExp("[^\x00-\x7F]");
    var res = patt.test(str);
  //  document.getElementById("demo").innerHTML = res;
	return res;
}

$(document).ready(function(e) {
    $('#line-checkbox-1').click(function() {
		if($("#line-checkbox-1").prop('checked') == true){
			console.log('schedule');
			$('#send_sms').hide();
			$('#sch_sms').show();
		}
		else {
			console.log('send');
			$('#send_sms').show();
			$('#sch_sms').hide();
		}
	});
});
function funCounter()
{	
	//alert();//"{", "}","[","]","^","|","\\"
	//$('#wcount').html(($('#textarea').val()).length);
	//alert('as');
	var val=checkunicode();
	if($("#checkboxId").prop('checked') == false && val==false){
    //do something
	//alert('allow');
	console.log('allow english');
    }
	if($("#checkboxId").prop('checked') == false && val==true){
    //do something
	//alert('allow');
	//console.log('hindi not allow only english');
	
													swal({
													  title: "Unicode not allow?",
												      text: "To enable please click on enable unicode.!",
													  type: "warning",
													  showCancelButton: true,
													  confirmButtonClass: "btn-danger",
													  confirmButtonText: "Enable Unicode",
													  cancelButtonText: "Close",
													  closeOnConfirm: true,
													  closeOnCancel: true
													},
													function(isConfirm) {
													  if (isConfirm) {
														  console.log('check');
														
																$('#checkboxId').prop('checked', true);
																 document.getElementById('languageDropDown').style.display='block';
																//document.getElementById('checkboxId').checked = e.transliterationEnabled;
																//document.getElementById('languageDropDown').style.display='block';
				 										     transliterationControl.toggleTransliteration();
													  } else {
														$('#textarea').val("");
														 
													  }
													});
				
						                 
    }
	if($("#checkboxId").prop('checked') == true && val==true){
    //do something
	//alert('allow');
	console.log('allow hindi');
    }
	 
	console.log(val); 
	//alert(val);
	
 
	var res = ($('#textarea').val()).replace(/{|}|\[|\]|~|\^|\||\\/g,"  ");
	//alert(res);
	$('#wcount').html(res.length);
	$('#preview-count').html(res.length);
	val = res.length;
	if(val == 0)
	{
		$('#msg').html(0).css('color','#000').css('font-size','18');
		$('#preview-credit').html(0).css('color','#000').css('font-size','18');
	} else {
		
		
 				var checkBox = document.getElementById("checkboxId");
				//alert('ash');
				
				// FOR UNICODE 
				if (checkBox.checked == true){
							if(val < 1000)
							$('#msg').html(1).css('color','#000').css('font-size','18');		
							else if(val/1000 == 1)
							$('#msg').html(Math.round(val/1000)).css('color','#000').css('font-size','18');
							else {
							         $('#msg').html(Math.ceil(val/960)).css('color','#F00').css('font-size','24');
									 if (document.getElementById("long").checked){
							
							          } else {
													swal({
													  title: "Do you want to allow?",
												      text: "For messages more then 70 chars.!",
													  type: "warning",
													  showCancelButton: true,
													  confirmButtonClass: "btn-danger",
													  confirmButtonText: "Yes",
													  cancelButtonText: "No",
													  closeOnConfirm: true,
													  closeOnCancel: true
													},
													function(isConfirm) {
													  if (isConfirm) {
														  console.log('check');
														
														//swal("Deleted!", "Your imaginary file has been deleted.", "success");
																//$('#long').attr('checked','checked');  //swal.close(); 
																$('#long').prop('checked', true);
													  } else {
														 
													  }
													});
				
						                 } // end else
							}
		//$msg_count =ceil((strlen($msg)/153) > 1?(strlen($msg)/153):1);
	            } else {
							if(val < 1500)
							$('#msg').html(1).css('color','#000').css('font-size','18');
							else if(val/1500 == 1)
							$('#msg').html(Math.round(val/1500)).css('color','#000').css('font-size','18');
							else{ 
							$('#msg').html(Math.ceil(val/1450)).css('color','#F00').css('font-size','24');
							//$msg_count =ceil((strlen($msg)/153) > 1?(strlen($msg)/153):1);
							if (document.getElementById("long").checked){
							
							} else {
													swal({
													  title: "Do you want to allow?",
												      text: "For messages more then 160 chars.!",
													  type: "warning",
													  showCancelButton: true,
													  confirmButtonClass: "btn-danger",
													  confirmButtonText: "Yes",
													  cancelButtonText: "No",
													  closeOnConfirm: true,
													  closeOnCancel: true
													},
													function(isConfirm) {
													  if (isConfirm) {
														//swal("Deleted!", "Your imaginary file has been deleted.", "success");
																$('#long').prop('checked', true); 
															   
													  } else {
														//swal("Cancelled", "Your imaginary file is safe :)", "error");
													  }
													});
				
						     } // end else
			    }

	     }
		

	}
	 var credit1=$('#msg').html();
	  var wcount=$('#wcount').html();
	  $('#credit').val(credit1);
	  $('#msg_count').val(wcount);
}

function funSchedule()
{
	if($('#counter').val() == 0)
	{
		$('#counter').val('1');//Opended
		$("html, body").animate({ scrollTop: $(document).height()-$(window).height() });
	}
	else
	{
		$('#counter').val('0');//Closed
	}
	$('#datePick1').toggle('slow');
}
</script>
<!--unicode sms start -->
<script type="text/javascript" src="http://www.google.com/jsapi"> </script>

    <script type="text/javascript">

      // Load the Google Transliteration API
	  
 
	  
	  function languageChangeHandler() {
		  
        var dropdown = document.getElementById('languageDropDown');
	 transliterationControl.setLanguagePair(
            google.elements.transliteration.LanguageCode.ENGLISH,
            dropdown.options[dropdown.selectedIndex].value);
	 
	  }
	  
       	 
			  google.load("elements", "1", {
            packages: "transliteration"
          });
 
      var transliterationControl;
      function onLoad() {
        var options = {
            sourceLanguage: 'en',
            destinationLanguage: ['hi','ar','te','kn','ml','ta'],
           transliterationEnabled: true,
            shortcutKey: 'ctrl+g'
        };
		
		
        // Create an instance on TransliterationControl with the required
        // options.
        transliterationControl =
          new google.elements.transliteration.TransliterationControl(options);

        // Enable transliteration in the textfields with the given ids.
        var ids = [ "transl1", "textarea" ];
        transliterationControl.makeTransliteratable(ids);

        // Add the STATE_CHANGED event handler to correcly maintain the state
        // of the checkbox.
        transliterationControl.addEventListener(
            google.elements.transliteration.TransliterationControl.EventType.STATE_CHANGED,
            transliterateStateChangeHandler);

        // Add the SERVER_UNREACHABLE event handler to display an error message
        // if unable to reach the server.
        transliterationControl.addEventListener(
            google.elements.transliteration.TransliterationControl.EventType.SERVER_UNREACHABLE,
            serverUnreachableHandler);

        // Add the SERVER_REACHABLE event handler to remove the error message
        // once the server becomes reachable.
        transliterationControl.addEventListener(
            google.elements.transliteration.TransliterationControl.EventType.SERVER_REACHABLE,
            serverReachableHandler);

        // Set the checkbox to the correct state.
        document.getElementById('checkboxId').checked =
          transliterationControl.isTransliterationEnabled();

        // Populate the language dropdown
        var destinationLanguage =
          transliterationControl.getLanguagePair().destinationLanguage;
        var languageSelect = document.getElementById('languageDropDown');
        var supportedDestinationLanguages =
          google.elements.transliteration.getDestinationLanguages(
            google.elements.transliteration.LanguageCode.ENGLISH);
        for (var lang in supportedDestinationLanguages) {
          var opt = document.createElement('option');
          opt.text = lang;
          opt.value = supportedDestinationLanguages[lang];
          if (destinationLanguage == opt.value) {
            opt.selected = true;
          }
          try {
            languageSelect.add(opt, null);
          } catch (ex) {
            languageSelect.add(opt);
          }
        }
      }

      // Handler for STATE_CHANGED event which makes sure checkbox status
      // reflects the transliteration enabled or disabled status.
      function transliterateStateChangeHandler(e) {
        document.getElementById('checkboxId').checked = e.transliterationEnabled;
      }

      // Handler for checkbox's click event.  Calls toggleTransliteration to toggle
      // the transliteration state.
      function checkboxClickHandler() {
		  
 				var checkBox = document.getElementById("checkboxId");
				//alert('ash');
				if (checkBox.checked == true){
				document.getElementById('languageDropDown').style.display='block';
				} else {
				document.getElementById('languageDropDown').style.display='none';
				}

        transliterationControl.toggleTransliteration();
      }

      // Handler for dropdown option change event.  Calls setLanguagePair to
      // set the new language.
      
	  /* function languageChangeHandler1() {
		  
       var dropdown1 = document.getElementById('languageDropDown').value;
	   alert(dropdown1);
		 if(dropdown1=='en')
		 {
			  var options = {
						  sourceLanguage: 'en',
						  destinationLanguage: ['en'],
						  transliterationEnabled: true,
						  shortcutKey: 'ctrl+g'
                  };
		 } else {
			 var options = {
						  sourceLanguage: 'en',
						  destinationLanguage: ['hi','ar','te','kn','ml','ta'],
						  transliterationEnabled: true,
						  shortcutKey: 'ctrl+g'
                  };
			  
		 } 
		//alert(dropdown);
 
			 
      }*/

      // SERVER_UNREACHABLE event handler which displays the error message.
      function serverUnreachableHandler(e) {
        document.getElementById("errorDiv").innerHTML =
            "Transliteration Server unreachable";
      }

      // SERVER_UNREACHABLE event handler which clears the error message.
      function serverReachableHandler(e) {
        document.getElementById("errorDiv").innerHTML = "";
      }
      google.setOnLoadCallback(onLoad);

          function charcount()
          {
             var msg=document.unicodesmsform.textarea.value;
                 document.getElementById("charactercount").innerHTML=msg.length;
                 document.unicodesmsform.char_count.value=msg.length;
          }

window.onload = function () {
		
		document.getElementById('checkboxId').checked='';
		checkboxClickHandler();
	}
    </script>