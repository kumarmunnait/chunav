<?php
include "./db_config.php";
    	class Form{

    	public function get_form_list($uid) {
    		echo $listform="SELECT form_name FROM form_generate WHERE uid = $uid";
    		 $result = mysqli_query($this->db,$listform);
	        $user_data = mysqli_fetch_array($result);
	        echo $user_data['fullname'];
    	}
    }
	
?>